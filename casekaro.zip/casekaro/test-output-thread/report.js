$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b4977790-7825-4c7e-9eb0-c201bbfd11c9","feature":"Redirect to Mobile Covers Page","scenario":"Redirect to mobile covers page by clicking a button and verify the new URL","start":1692875953606,"group":1,"content":"","tags":"","end":1692875962441,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});