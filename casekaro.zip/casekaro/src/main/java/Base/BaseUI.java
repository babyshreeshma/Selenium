package Base;


import java.io.File;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Utilities.DateUtils;
import Utilities.FileIO;


public class BaseUI {
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	public BaseUI() {
		prop = FileIO.initProperties();
	}

	/***************** invoke browser **************/
	public static WebDriver invokebrowser() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = browserConfig.getchromeBrowser();
		}
		return driver;
	}

	/***************** open website url **************/
	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty(websiteurl));
	}

	/************* check if the element is present ********/
	public static boolean isElementPresent(By locator, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/************** Get text of element ****************/
	// Above is the previous code if you are using page factory we can change like
	// this
	public static String getText(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	/************ send text to element ***************/
	// Above is the previous code if you are using page factory we can change like
	// this
	public static void sendtext(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**************** click element *****************/

	// Above is the previous code if you are using page factory we can change like
	// this
	public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**************** drop down handling *****************/
	public static void dropDownHandling(WebElement element, String value) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			Select s = new Select(element);
			s.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**************** get locator *******************/
	public static By getlocator(String locatorKey) {
		if (locatorKey.endsWith("_id")) {
			return By.id(prop.getProperty(locatorKey));
		}
		if (locatorKey.endsWith("_name")) {
			return By.name(prop.getProperty(locatorKey));
		}
		if (locatorKey.endsWith("_className")) {
			return (By.className(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_xpath")) {
			return (By.xpath(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_css")) {
			return (By.cssSelector(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_linkText")) {
			return (By.linkText(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_partialLinkText")) {
			return (By.partialLinkText(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_tagName")) {
			return (By.tagName(prop.getProperty(locatorKey)));
		}
		return null;
	}

	public static void takeScreenShot(String filePath) {
		try {
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/******************** alertbox ***********************/
	public void switchToAlertAccept() {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************ switch to alert and extract text ***************/
	public String getTextfromAlertandAccept() {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	public static void mouseOver2(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			Actions actions = new Actions(driver);
			actions.moveToElement(element).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
