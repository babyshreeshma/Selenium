package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;

public class MainFile extends BaseUI{
	WebDriver driver;

	public MainFile(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}
	//login
	@FindBy(id="CustomerEmail")
	WebElement lgnemail;
	
	@FindBy(id="CustomerPassword")
	WebElement lgnpswd;
	
	@FindBy(xpath="//input[@class='btn']")
	WebElement signin;
	
	//create account
	@FindBy(xpath="//a[@href='/account/login']")
	WebElement clckacnt;

	@FindBy(id="customer_register_link")
	WebElement cstmrrgstrlnk;
	
	@FindBy(id="FirstName")
	WebElement firstname;
	
	@FindBy(id="LastName")
	WebElement lastname;
	
	@FindBy(id="Email")
	WebElement email;
	
	@FindBy(id="CreatePassword")
	WebElement crtpswd;
	
	@FindBy(xpath="//input[@class='btn']")
	WebElement crtbtn;
	
	@FindBy(xpath="//div[@class='site-header__icons-wrapper']//button[contains(@class,'site-header__search-toggle')]")
	WebElement srchbtn;
	
	@FindBy(name="q")
	WebElement srchbar;
	
	@FindBy(xpath="//form[@class='search search-bar__form']//button[contains(@class,search-bar__submit)]")
	WebElement search;
	
	
	@FindBy(linkText="Mobile Covers")
	WebElement cover;
	
	@FindBy(linkText="Mouse Pad")
	WebElement mousepad;
	
	@FindBy(linkText="Track Order")
	WebElement trackOrder;
	
	@FindBy(xpath="//div[@class=\"errors\"]//ul//li")
	WebElement LogError;
	
	public void clickMobileCover() {
		clickOn(cover);
	}
	public void clickMousePad() {
		clickOn(mousepad);
	}
	
	public void clickTrackOrder() {
		clickOn(trackOrder);
	}
	
	public void clicksearchBtn() {
		clickOn(srchbtn);
	}
	
	public void sendSearchText(String text) {
		sendtext(srchbar,text);
		System.out.println("text");
	}
	
	public void clicksearch() {
		clickOn(search);
	}
	
	public void clickAcnt() {
		clickOn(clckacnt);
	}
	
	public String clickLogError() {
		return getText(LogError) ;
	}
	
	
	public void sendemail(String loginEmail) {
		sendtext(lgnemail,loginEmail);
	}
	
	public void sendlgnpswd(String loginpswd) {
		sendtext(lgnpswd,loginpswd);
	}
	
	public void clickLogin() {
		clickOn(signin);
	}
	
//	public void clickLoginBtn() {
//		clickOn(LoginBtn);
//	}
	
	public void clickCrtAct() {
		clickOn(cstmrrgstrlnk);
	}
	
	public void sendFirstname(String fname) {
		sendtext(firstname,fname);
	}
	
	public void sendLastname(String lname) {
		sendtext(lastname,lname);
	}
	
	public void sendEmail(String mail) {
		sendtext(email,mail);
	}
	
	public void sendpswd(String pswd) {
		sendtext(crtpswd,pswd);
	}
	
	public void clickcreate() {
		clickOn(crtbtn);
	}

}
