package stepDefinitions;


import org.testng.Assert;

import Base.BaseUI;
import POM.MainFile;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class testcase extends BaseUI {
	MainFile mainfile;

	@Given("The user is on a page")
	public void the_user_is_on_a_page() {
		driver = invokebrowser();
		openBrowser("applicationURL");
		mainfile = new MainFile(driver);
	}

	@When("the user clicks a button for mobile covers")
	public void the_user_clicks_a_button_for_mobile_covers() {
		mainfile.clickMobileCover();
	}

	@Then("the user is redirected to a new page")
	public void the_user_is_redirected_to_a_new_page() {
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		String expectedURL = "https://casekaro.com/pages/mobile-back-covers";
		// Assert.assertEquals(actualURL, expectedURL, "URLs are not the same");
		Assert.assertEquals(actualURL, expectedURL);
	}

}
