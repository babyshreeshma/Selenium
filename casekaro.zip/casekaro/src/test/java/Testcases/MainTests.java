package Testcases;

import java.time.Duration;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Utilities.ExceUtilities;
import Base.BaseUI;
import POM.MainFile;

@Listeners(Utilities.SampleListener.class)
public class MainTests extends BaseUI{
	WebDriver driver;
	MainFile mainfile;
	
	@BeforeMethod
	public void setup() {
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	
//	public void createAccount() {
//		MainFile mainfile=new MainFile(driver);
//		mainfile.clickAcnt();
//		mainfile.clickCrtAct();
//		mainfile.sendFirstname("Sreee");
//		mainfile.sendLastname("sreeshma");
//		mainfile.sendEmail("Sreeshma@gmail.com");
//		mainfile.sendpswd("sree@123");
//		mainfile.clickcreate();
//	}
//	
//
	@DataProvider(name = "testData")
	public Object[][] testData() {
		return ExceUtilities.testdata();
	}


				
	@Test(priority = 1)
	public void mobilecoverspage() {
		MainFile mainfile=new MainFile(driver);
				
				// Click on the account
				System.out.println("Clicking on the account button...");
				mainfile.clickAcnt();
				// Verify that the user is redirected to the cart page
				String expectedUrl = "https://casekaro.com/account/login";
				String actualUrl = driver.getCurrentUrl();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
				});
				logger.log(Status.INFO, "successfull");
	}
	
	@Test(priority = 2)
	public void searchTest() {
		MainFile mainfile=new MainFile(driver);
		String text="flower";
		mainfile.clicksearchBtn();
		mainfile.sendSearchText(text);
		mainfile.clicksearch();
		String expectedUrl="https://casekaro.com/search?q=flower";
		String actualUrl=driver.getCurrentUrl();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		Boolean element=wait.until(ExpectedConditions.urlContains(text));
		//WebElement element=wait.until(ExpectedConditions.urlToBe("")))
		SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});	
		logger.log(Status.INFO, "successfull");
	}
	
	@Test(priority = 3)
	public void testmobilecovers() {
		MainFile mainfile=new MainFile(driver);
				
				// Click on the account
				System.out.println("Clicking on the account button...");
				mainfile.clickMobileCover();
				// Verify that the user is redirected to the cart page
				String expectedUrl = "https://casekaro.com/pages/mobile-back-covers";
				String actualUrl = driver.getCurrentUrl();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
				});
				logger.log(Status.INFO, "successfull");
	}
	
	
		@Test(priority = 5)
		public void testmousepad() {
		MainFile mainfile=new MainFile(driver);
				
				// Click on the account
				System.out.println("Clicking on the account button...");
				mainfile.clickMousePad();
				// Verify that the user is redirected to the cart page
				String expectedUrl = "https://casekaro.com/collections/mouse-pad";
				String actualUrl = driver.getCurrentUrl();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
				});
				logger.log(Status.INFO, "successfull");
	}
	
		@Test(priority = 6)
		public void testTrackorder() {
		MainFile mainfile=new MainFile(driver);
				
				// Click on the account
				System.out.println("Clicking on the account button...");
				mainfile.clickTrackOrder();
				// Verify that the user is redirected to the cart page
				String expectedUrl = "https://casekaro.com/pages/track-order-1";
				String actualUrl = driver.getCurrentUrl();
				SoftAssertions.assertSoftly(softAssertions -> {
					softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
				});
				logger.log(Status.INFO, "successfull");
	}
/*	
	//captcha error
	@Test(priority = 7, dataProvider = "testData")
	public void loginTest(String mail, String password) throws InterruptedException {
		MainFile mainfile = new MainFile(driver);
		mainfile.clickAcnt();
		mainfile.sendemail(mail);
		mainfile.sendlgnpswd(password);
		mainfile.clickLogin();
		String exp=mainfile.clickLogError();
		
		if(mail.equals(null) || password.equals(null)) {
			SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(exp.equalsIgnoreCase("Incorrect email or password.")).isTrue();
			});
			}
			else if(mail.equals("incorrectUsername") && password.equals("anu@123")) {
			SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(exp.equalsIgnoreCase("Incorrect email or password."));
			});
			}
			else if(password.equals("incorrectPassword") && mail.equals("anuthomas@gmail.com")) {
			SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(exp.equalsIgnoreCase("Incorrect email or password."));
			});
			}
			else if(mail.equals("anuthomas@gmail.com") && password.equals("anu@123")) {
			SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(driver.findElement(By.id("WelcomeContent")).isDisplayed());
			});
			}

		}
	*/
	@AfterMethod
    public void tearDown() {
        // Close the browser after each test method
        driver.quit();
    }

}
