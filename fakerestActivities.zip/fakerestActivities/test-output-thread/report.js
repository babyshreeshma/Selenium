$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"e7d4897e-9351-489d-8416-f66fedfc6a64","feature":"Login page feature","scenario":"Login with correct credentials","start":1691574339928,"group":1,"content":"","tags":"","end":1691574347941,"className":"passed"},{"id":"d2a43170-5381-495b-a981-e9f8dc687f17","feature":"Login page feature","scenario":"Login page title","start":1691574326655,"group":1,"content":"","tags":"","end":1691574339909,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});