package com.example.endpoints;

public class Routes {
	public static String baseuri="https://fakerestapi.azurewebsites.net/api/v1";
	public static String post_basePath="/Activities";
	public static String get_basePath="/Activities/{id}";
	public static String get_basePath1="/Activities";
	public static String delete_basePath="/Activities/{id}";
	public static String put_basePath="/Activities/{id}";


}
