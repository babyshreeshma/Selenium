package com.example.APItestcases;


import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.example.endpoints.UserEndPoints;
import com.example.payload.UserModel;
import com.example.utilities.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;
//@Listeners(com.example.utilities.ExtentReportManager.class)

public class DataDrivenTest {
	
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String userID,String title,String duedate) {
		
		UserModel user=new UserModel();
		
		user.setId(Integer.parseInt(userID));
		user.setTitle(title);
		user.setDueDate(duedate);
		
		
		Response response=UserEndPoints.createUser(user);

		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
		
		
	}
	
	@Test(priority=2,dataProvider="ids",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id)   // bcoz we are reading data from excel
	{
		
	Response response=UserEndPoints.deleteUser(Integer.parseInt(id));  //converted string to int
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
}
