package base;

import java.util.Collections;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.CapabilityType;

public class BrowserConfig {
	static WebDriver driver;

	public static WebDriver getBrowser() {
		// System.getProperty("webdriver.chrome.driver","C:\\Users\\249185\\Downloads\\chromedriver-win32\\chromedriver.exe");
		// WebDriverManager.chromedriver().setup();
		// ChromeOptions op=new ChromeOptions();
		// op.addArguments("--remote-allow-origins=*");
		// driver=new ChromeDriver(op);
		EdgeOptions edgeOptions = new EdgeOptions();
		edgeOptions.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		edgeOptions.addArguments("--guest");
		edgeOptions.setExperimentalOption("useAutomationExtension", false);
		edgeOptions.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		WebDriver driver = new EdgeDriver(edgeOptions);
		driver.manage().window().maximize();
		return driver;
		// driver=new EdgeDriver();
		// //for maximize the edge
		// driver.manage().window().maximize();
		// return driver;
	}
}
