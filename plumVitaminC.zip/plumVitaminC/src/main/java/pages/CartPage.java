package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class CartPage extends DriverUtils {
	WebDriver driver;

	public CartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/****************To View and Remove From Cart***************/	
	
	
	//@FindBy(xpath="//*[@id=\"dropdown-cart\"]/div[5]/div[2]/div[1]/a")
	//@FindBy(xpath="//div[@class=\"button\"]//div[@class=\"a-button\"]//a[@class=\"btn btn-view-cart\"]")
	
	@FindBy(xpath="//div[@class=\"actions\"]//div[@class=\"button\"]//div[@class=\"a-button\"]//a[@class=\"btn btn-view-cart\"]")
	public WebElement viewCartButton;
	
	@FindBy(xpath="//div[@class=\"cart-remove-btn\"]//a[@class=\"remove\"]//span")
	public WebElement rmvItem;
	
	@FindBy(xpath="//div[@id=\"shopify-section-cart-template\"]//p[1]")
	public WebElement checkaftrrmvItem;
	
	
	public void clickViewCartsButton() {
		clickOn(viewCartButton);
		
	}
	
	public void clickRemoveFromCartsButton() {
		clickOn(rmvItem);
		
	}
	
}