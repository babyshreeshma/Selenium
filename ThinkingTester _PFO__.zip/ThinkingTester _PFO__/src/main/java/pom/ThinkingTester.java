package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class ThinkingTester extends BaseUI {
	public ThinkingTester(WebDriver driver) {
		// Pass WebDriver as an input to constructor
		super();
		this.driver = driver;
		// Call init Elements() method by using PageFactory reference and pass driver
		PageFactory.initElements(driver, this);
	}
    WebDriver driver;
    
    @FindBy(id = "signup")
	public WebElement signup;

    @FindBy(id = "firstName")
	public WebElement firstname;

    @FindBy(id = "lastName")
	public WebElement lastname;

    @FindBy(id = "email")
	public WebElement email;

    @FindBy(id = "password")
	public WebElement password;

    @FindBy(id = "submit")
    private WebElement button;

    @FindBy(id = "cancel")
    private WebElement cancel;

    @FindBy(xpath = "//*[@id='error']")
    private WebElement alreadyInUse;


    public void signUpOption() {
        clickOn(signup);
    }

    public WebElement enterFirstName(String firstName) {
        sendtext(firstname, firstName);
		return alreadyInUse;
    }

    public void enterLastName(String lastName) {
        sendtext(lastname, lastName);
    }

    public void enterEmail(String Email) {
        sendtext(email, Email);
    }

    public void enterPassword(String Password) {
        sendtext(password, Password);
    }

    public void clickSubmit() {
        clickOn(button);
    }

    public void clickCancel() {
        clickOn(cancel);
    }

    public String getAlreadyInUseErrorMessage() {
        return getText(alreadyInUse);
    }
    
	// Method to log in to the application with given username and password
	public void login(String email, String password) {
		By emailLocator = By.id("email");
		By passwordLocator = By.id("password");

		// Enter the credentials into the input fields
		driver.findElement(emailLocator).sendKeys(email);
		driver.findElement(passwordLocator).sendKeys(password);
	}

	public WebElement getSignUpElement() {
		clickOn(signup);
		return signup;
	}
}
