package base;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import utilities.DateUtils;
import utilities.FileIO;

public class BaseUI {
	public static WebDriver driver;
	public static Properties prop;
	public static String browserChoice;

	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String timestamp = DateUtils.getTimeStamp();

	public BaseUI() {
		prop = FileIO.initProperties();
	}

	public static WebDriver invokeBrowser() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("chrome")) {
			driver = BrowserConfig.getBrowser();
		}
		return driver;
	}

	public static void openBrowser(String websiteurl) {
		driver.get(prop.getProperty("applicationURL"));
	}

	/************* check if the element is present ********/
	public static boolean isElementPresent(By locator, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions.presenceOfElementLocated(locator));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

//	// Add a method to initialize Page Factory elements
//	public static <T> T initPageElements(WebDriver driver, Class<T> pageClass) {
//		T page = PageFactory.initElements(driver, pageClass);
//		return page;
//	}

	/************* check if the element is present ********/
	public static boolean isElementPresent(WebElement element, Duration timeout) {
		try {
			new WebDriverWait(driver, timeout).until(ExpectedConditions.visibilityOf(element));
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// Click on a WebElement
	public static void clickOn(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/************send text to element***************/
	public static void sendtext(WebElement element, String text) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/************** Get text of element ****************/
	public static String getText(WebElement element) {
		String text = null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
			text = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	public static void SubmitBtn(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			element.submit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To retrieve the "value" attribute of an element after waiting for its
	// presence
	public static String getAttributeValueWithWait(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			return element.getAttribute("value");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**************** get locator *******************/
	public static WebElement getWebElement(String locatorKey) {
		By byLocator = getlocator(locatorKey);
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15))
					.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			return driver.findElement(byLocator);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**************** get locator *******************/
	public static By getlocator(String locatorKey) {
		if (locatorKey.endsWith("_id")) {
			return By.id(prop.getProperty(locatorKey));
		}
		if (locatorKey.endsWith("_name")) {
			return By.name(prop.getProperty(locatorKey));
		}
		if (locatorKey.endsWith("_className")) {
			return (By.className(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_xpath")) {
			return (By.xpath(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_css")) {
			return (By.cssSelector(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_linkText")) {
			return (By.linkText(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_partialLinkText")) {
			return (By.partialLinkText(prop.getProperty(locatorKey)));
		}
		if (locatorKey.endsWith("_tagName")) {
			return (By.tagName(prop.getProperty(locatorKey)));
		}
		return null;
	}

	public static String getlocatorvalue(String locatorKey) {

		return prop.getProperty(locatorKey);

	}

	public static void takeScreenShot(String filePath) {
		try {
			File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/***************************drop down handling**********************************/
	

	// Select option from dropdown by visible text
	public static void selectFromDropdownByVisibleText(WebElement element, String visibleText) {
	    try {
	        new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
	        Select dropdown = new Select(element);
	        dropdown.selectByVisibleText(visibleText);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	// Select option from dropdown by index
	public static void selectFromDropdownByIndex(WebElement element, int index) {
	    try {
	        new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
	        Select dropdown = new Select(element);
	        dropdown.selectByIndex(index);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	// Get all options from a dropdown
	public static List<String> getAllDropdownOptions(WebElement element) {
	    try {
	        new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
	        Select dropdown = new Select(element);
	        List<WebElement> options = dropdown.getOptions();
	        List<String> optionTexts = new ArrayList<>();
	        for (WebElement option : options) {
	            optionTexts.add(option.getText());
	        }
	        return optionTexts;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	/*********** Select option from dropdown ***********/
	public static String getSelectedOptionFromDropdown(WebElement element) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			Select dropdown = new Select(element);
			return dropdown.getFirstSelectedOption().getText();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/*********** Select option from dropdown by value ***********/
	public static void selectFromDropdownByValue(WebElement element, String value) {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.visibilityOf(element));
			Select dropdown = new Select(element);
			dropdown.selectByValue(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*********** Switch to Alert ***********/
	public void switchToAlertandAccept()
	{
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/*********** Switch to Alert and extract Text ***********/
	public void getTextFromAlertandAccept()
	{
		String text= null;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			text=alert.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
}
	public String getTextFromAlertandAcceptString() {
	    String text = null;
	    try {
	        new WebDriverWait(driver, Duration.ofSeconds(15)).until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        text = alert.getText();
	        alert.accept();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return text; // Add this line to return the extracted text
	}
 




}
