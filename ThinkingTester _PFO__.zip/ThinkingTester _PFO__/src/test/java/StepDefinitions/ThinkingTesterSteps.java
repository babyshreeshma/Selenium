package StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.ThinkingTester;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.BaseUI;


public class ThinkingTesterSteps extends BaseUI{
    WebDriver driver = BaseUI.invokeBrowser();
    public ThinkingTester tt = new ThinkingTester(driver);
    
	@Given("the user is on the {string} page")
	public void the_user_is_on_the_page(String string) {
		 driver.get("https://thinking-tester-contact-list.herokuapp.com/");
	}

	@When("the user enters their email as {string} and password as {string}")
	public void the_user_enters_their_email_as_and_password_as(String string, String string2) {
		tt.login("john@gmail.com", "Selenium123");
	}

	@When("the user clicks the submit button")
	public void the_user_clicks_the_submit_button() {
	    tt.clickSubmit();
	}

	@Then("the user should be redirected to the contact list page {string}")
	public void the_user_should_be_redirected_to_the_contact_list_page(String string) {
		String expectedURL = "https://thinking-tester-contact-list.herokuapp.com/contactList" ;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Wait for up to 10 seconds
        wait.until(ExpectedConditions.urlToBe(expectedURL));

        String currentURL = driver.getCurrentUrl();
        assert currentURL.equals(expectedURL) : "URL mismatch. Expected: " + expectedURL + ", Actual: " + currentURL;
	}



}
