package org.ust.Testcases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.ThinkingTester;

public class ThinkingTesterTestcases extends BaseUI {
	WebDriver driver;
	ThinkingTester thinking;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser();
		openBrowser(prop.getProperty("applicationURL")); // Using property from BaseUI
		thinking = new ThinkingTester(driver); // Initialize
		thinking = PageFactory.initElements(driver, ThinkingTester.class);
	}

	@Test(priority = 0)
	public void testClickSignUp() {
		// Actions actions = new Actions(driver); // Create an instance of Actions

		// Move to the sign-up option and click using Actions
		// actions.moveToElement(thinking.getSignUpElement()).click().perform();

		thinking.getSignUpElement();
		String expectedURL = "https://thinking-tester-contact-list.herokuapp.com/addUser";
		String actualURL = driver.getCurrentUrl();

		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualURL).isEqualTo(expectedURL);
		softAssertions.assertAll();
	}

	@Test(priority = 1)
	public void testEnterFirstName() {
		// Test data
		String firstName = "John";
		 //Wait for the first name field to be visible
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.visibilityOf(thinking.firstname));
		
		Actions actions = new Actions(driver); // Create an instance of Actions
		//Move to the sign-up option and click using Actions
		actions.moveToElement(thinking.enterFirstName(firstName)).click().perform();
		// Fill in the first name
		//thinking.enterFirstName(firstName);
		// Click on the "Submit" button
		thinking.clickSubmit();
		
		// Verify First Name
		// Wait for the first name value to be updated
	    String actualFirstName = getAttributeValueWithWait(thinking.firstname);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualFirstName).isEqualTo(firstName).as("First name is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 2)
	public void testEnterLastName() {
		// Test data
		String lastName = "Doe";
		// Fill in the last name
		thinking.enterLastName(lastName);
		// Click on the "Submit" button
		thinking.clickSubmit();

		// Verify Last Name
		 String actualLastName = getAttributeValueWithWait(thinking.lastname);
		//String actualLastName = getText(thinking.lastname);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualLastName).isEqualTo(lastName).as("Last name is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 3)
	public void testEnterEmail() {
		// Test data
		String email = "john@gmail.com";
		// Fill in email
		thinking.enterEmail(email);
		// Click on the "Submit" button
		thinking.clickSubmit();

		// Verify Email
		String actualEmail = getAttributeValueWithWait(thinking.email);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualEmail).isEqualTo(email).as("Email is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 4)
	public void testEnterPassword() {
		// Test data
		String password = "Selenium123";
		// Fill in password
		thinking.enterPassword(password);
		// Click on the "Submit" button
		thinking.clickSubmit();

		// Verify Password
		String actualPassword = getAttributeValueWithWait(thinking.password);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualPassword).isEqualTo(password).as("Password is incorrect");
		softAssertions.assertAll();
	}

	@Test(priority = 5)
	public void testClickCancel() {
		thinking.clickCancel();
		String expectedURL = "https://thinking-tester-contact-list.herokuapp.com/login";
		String actualURL = driver.getCurrentUrl();
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(actualURL).isEqualTo(expectedURL);
		softAssertions.assertAll();
	}
}
