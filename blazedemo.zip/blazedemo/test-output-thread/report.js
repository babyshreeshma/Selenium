$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"7e436517-4070-4541-8069-23dfc35f3273","feature":"Dessert Page feature","scenario":"Dessert Page link","start":1691572468943,"group":1,"content":"","tags":"","end":1691572487774,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});