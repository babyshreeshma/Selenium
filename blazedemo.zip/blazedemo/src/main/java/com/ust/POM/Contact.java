package com.ust.POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Base.BaseUI;

public class Contact extends BaseUI{
	WebDriver driver;
	
	public Contact(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
	@FindBy(xpath="//button[@id=\"navbarExample\"]//ul//li[2]")
	WebElement contact;
	
	@FindBy(id="recipient-email")
	WebElement recipientEmail;
	
	@FindBy(id="recipient-name")
	WebElement recipientName;
	
	@FindBy(id="message-text")
	WebElement messageText;
	
	@FindBy(xpath ="//div[@id=\"exampleModal\"]//div//div//div[3]//button[2]")
	public WebElement sendMessageBtn;
	
	public void clickContact() {
		clickOn(contact);
		//logger.log(Status.INFO, "Clicked on Submit button");
	}

	public void sendRecipientEmail(String email) {
		sendtext(recipientEmail, email);
//		String logMessage = "Entered username: " + user;
//		logger.log(Status.INFO, logMessage);
	}

	public void sendRecipientName(String name) {
		sendtext(recipientName, name);
//		String logMessage = "Entered password";
//		logger.log(Status.INFO, logMessage);
	}
	public void sendMessageText(String msg) {
		sendtext(messageText, msg);
//		String logMessage = "Entered password";
//		logger.log(Status.INFO, logMessage);
	}
	public void clickSendMessageButton() {
		clickOn(sendMessageBtn);
		//logger.log(Status.INFO, "Clicked on Submit button");
	}

	

	
	
}

