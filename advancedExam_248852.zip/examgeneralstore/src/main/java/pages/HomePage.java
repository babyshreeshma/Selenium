package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class HomePage extends AndroidActions {
	AndroidDriver driver;

	public HomePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// locators in homepage

	@AndroidFindBy(id = "com.androidsample.generalstore:id/spinnerCountry")
	private WebElement country;

	@AndroidFindBy(id = "android:id/text1")
	private WebElement countryCheck;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/nameField")
	private WebElement name;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioFemale")
	private WebElement female;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement letsShop;

	// methods to perform particular operations in different locators
	public void clickCountry() {
		country.click();
	}

	// to scroll to the particular country
	public void scrollCountry(String cn) {
		scrollToText(cn);
	}

	// to fetch the country name
	public String getCountryName() {
		return countryCheck.getText();
	}

	// to send the name
	public void sendName(String name1) {
		name.sendKeys(name1);
	}

	public String getName() {
		return name.getText();
	}

	public void clickFemale() {
		female.click();
	}

	public void clickLetsShop() {
		letsShop.click();
	}

}
