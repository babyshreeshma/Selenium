package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class AddToCartPage extends AndroidActions {
	AndroidDriver driver;

	public AddToCartPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	//locators in add to cart page
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView")
	private WebElement priceOfProduct1;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/totalAmountLbl")
	private WebElement totalAmount;

	// methods to perform particular operations in different locators
	public String getPrice1() {
		return priceOfProduct1.getText();
	}

	public boolean prodInCartIsDisplayed() {
		return priceOfProduct1.isDisplayed();
	}

	public String getTotal() {
		return totalAmount.getText();
	}

	public boolean totalAmountIsDisplayed() {
		return totalAmount.isDisplayed();
	}

}
