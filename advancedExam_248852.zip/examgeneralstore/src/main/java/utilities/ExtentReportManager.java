package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.android.AndroidDriver;

//for the extent report generation
public class ExtentReportManager extends AndroidActions {

	public ExtentReportManager(AndroidDriver driver) {
		super(driver);
	}

	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + AndroidActions.timestamp + ".html";
		// path of the report need to be generated
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Sreeshma");
		spark.config().setDocumentTitle("General Store Report");
		// Name of the report
		spark.config().setReportName("General Store Report");
		// Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}

}
