package utilities;

import java.text.SimpleDateFormat;
import java.util.Date;

//for getting current date and time
public class DateUtilities {
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

}
