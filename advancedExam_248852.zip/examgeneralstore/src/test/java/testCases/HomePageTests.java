package testCases;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.AddToCartPage;
import pages.HomePage;
import pages.ShoppingPage;

@Listeners(utilities.SampleListener.class)
public class HomePageTests extends BaseTest {

	/**
	 * Provides test data for filling form in first page from a JSON file.
	 */
	@DataProvider(name = "formData")
	public Object[][] provideData() throws IOException {
		// Load name data from a JSON file
		List<HashMap<String, String>> data = getJsonData(System.getProperty("user.dir") + "\\TestData\\formData.json");
		// Prepare the test data array
		Object[][] testData = new Object[data.size()][2];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("country");
			testData[i][1] = row.get("name");

		}
		return testData;
	}

	// testcase
	@Test(priority = 0, dataProvider = "formData")
	public void formTests(String country, String name) {
		HomePage hmpg = new HomePage(driver);
		ShoppingPage spg = new ShoppingPage(driver);
		AddToCartPage apg = new AddToCartPage(driver);
		hmpg.clickCountry();
		hmpg.scrollCountry(country);
		hmpg.sendName(name);
		hmpg.clickFemale();

		// Checking correct country is selected or not
		String expectedCountryName = country;
		String actualCountryName = hmpg.getCountryName();
		System.out.println(actualCountryName);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedCountryName.equalsIgnoreCase(actualCountryName)).isTrue();
		});

		// Checking correct name is given or not
		String expectedName = name;
		String actualName = hmpg.getName();
		System.out.println(actualName);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedName.equalsIgnoreCase(actualName)).isTrue();
		});

		hmpg.clickLetsShop();

		spg.clickAddToCartProduct1();
		spg.clickAddToCartProduct2();

		spg.clickButtonCart();

		// Checking the product is added to the cart
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(apg.prodInCartIsDisplayed()).isTrue();
		});

		// Checking the product 1's price is displayed correctly
		String expectedPrice = "$160.97";
		String actualPrice = apg.getPrice1();
		System.out.println(actualPrice);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedPrice.equalsIgnoreCase(actualPrice)).isTrue();
		});

		// Checking the total price of the product is correct
		String expectedTotalPrice = "$ 280.97";
		String actualTotalPrice = apg.getTotal();
		System.out.println(actualTotalPrice);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expectedTotalPrice.equalsIgnoreCase(actualTotalPrice)).isTrue();
		});

		// Checking the total amount is displayed or not
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(apg.totalAmountIsDisplayed()).isTrue();
		});

	}
}
