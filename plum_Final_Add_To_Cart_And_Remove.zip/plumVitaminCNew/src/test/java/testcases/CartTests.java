package testcases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import base.BaseTest;
import pages.CartPage;
import pages.ProductPage;
import pages.SearchPage;
import utilities.Excelutilits;

@Listeners(utilities.SampleListener.class)
public class CartTests extends BaseTest {

	private SearchPage srchpg;
	ProductPage prdctpg;
	CartPage crtpg;
	String[][] data;

	/************
	 * Data provider method for test data.
	 * 
	 * @return 2D array of test data.
	 *************/

	@Test
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = Excelutilits.testdata();
		return data;
	}

	@BeforeClass
	public void MainTest() {
		SearchPage srchpg = new SearchPage(driver);
		ProductPage prdctpg = new ProductPage(driver);
		CartPage crtpg = new CartPage(driver);
	}

	/*********** Test case to search for a product. ************/

	@Test(priority = 1)
	public void searchTest() {
		srchpg = goToSearchPage();
		srchpg.clickSearchBar();
		String text = "vitamin C";
		srchpg.sendSearchData(text);
		srchpg.srch.sendKeys(Keys.ENTER);

		String expectedUrl = "https://plumgoodness.com/search?q=vitamin%20C";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl);

		// logger.log(Status.INFO, "Search Test is successfull");
	}

	/************** Test case to handle checkbox. ***************/

	@Test(priority = 2)
	public void checkboxTest() {
		srchpg.clickCheckBox();
		srchpg.clickClearCheckBox();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		boolean btnclr = wait.until(ExpectedConditions.invisibilityOf(srchpg.clearCheckBox));
		Assert.assertTrue(btnclr, "View cart is displayed");

		// logger.log(Status.INFO, "Checkbox Test is successfull");
	}

	/******************* Test case to handle Dropdown *******************/

	@Test(priority = 3)
	public void chooseDropdownTest() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		srchpg.clickDropdownBtn();

		srchpg.clickDrpdnPriceHighToLow();
	
		boolean isHigh_LowDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_price_hightolow))
				.isDisplayed();
		Assert.assertTrue(isHigh_LowDisplayed, "Dropdown with high to low is displayed");

		// logger.log(Status.INFO, "Dropdown Test is successfull");
	}

	/*******************
	 * Test case to choose a product from the search results.
	 *****************/

	@Test(priority = 4)
	public void chooseProductTest() {
		srchpg.clickFirstProduct();
		String expectedUrl = "https://plumgoodness.com/products/vitamin-c-glow-boosting-ctsm-combo-foaming-face-wash-toner-serum-moisturizer-boosts-glow-fights-hyperpigmentation-dark-spots-all-skin-types-100-vegan";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
		// logger.log(Status.INFO, "Choose a product from the search results is
		// successfull");
	}

	/***************
	 * Test case to change the product quantity by the text box
	 ********************/

	@Test(priority = 5)
	public void changeProductQuantityTest() {
		ProductPage prdctpg = new ProductPage(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement quantityField = prdctpg.clickQuantity();
		wait.until(ExpectedConditions.elementToBeClickable(quantityField));
		quantityField.clear();

		String qty = "2";
		prdctpg.clickAndSendQunatity(qty);
		Assert.assertNotEquals(prdctpg.prodQuantity, 1, "Product quantity is not as expected");

		// logger.log(Status.INFO, "Change the product quantity by the text box is
		// successfull");
	}

	/***************
	 * Test cases to change the product quantity by the buttons
	 ********************/

	@Test(priority = 6)
	public void changeProductQuantityByMinusTest() {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.clickDecreaseQuantity();
		Assert.assertNotEquals(prdctpg.prodQuantity, 2, "Product quantity is not as expected");

		// logger.log(Status.INFO, "Change the product quantity by minus button is
		// successfull");
	}

	@Test(priority = 7)
	public void changeProductQuantityByPlusTest() {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.clickIncreaseQuantity();
		Assert.assertNotEquals(prdctpg.prodQuantity, 1, "Product quantity is not as expected");

		// logger.log(Status.INFO, "Change the product quantity by plus button is
		// successfull");
	}

	/***************** Test case to validate a pincode. ******************/

	@Test(priority = 8)
	public void pincodeValidationTest() {
		ProductPage prdctpg = new ProductPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		String pinno = "123456";
		prdctpg.clickPin(pinno);
		prdctpg.clickCheckPin();
		String invalid = prdctpg.invalidMsg();
		String expectedMessage = "Shipping is not available.";
		Assert.assertTrue(invalid.equalsIgnoreCase(expectedMessage), "Invalid message does not match expected message");

		// logger.log(Status.INFO, "Pincode validation is successfull");

	}

	/*****************
	 * Test case to validate a pincode by Excel Sheet
	 ******************/

	@Test(dataProvider = "testData", priority = 9)
	public void pincodeByExcelTest(String pincode) throws InterruptedException {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.pin.clear();
		prdctpg.clickPin(pincode);

		prdctpg.clickCheckPin();
		String invalid = prdctpg.invalidMsg();

		if (pincode.equals("12345")) {
			Assert.assertTrue(invalid.equalsIgnoreCase("Invalid pincode"),
					"Invalid message does not match expected message");
		} else if (pincode.equals("123456")) {
			Assert.assertTrue(invalid.equalsIgnoreCase("Shipping is not available."),
					"Invalid message does not match expected message");
		} else {
			Assert.assertTrue(invalid.equalsIgnoreCase("Shipping Available!"),
					"Invalid message does not match expected message");
		}

		// logger.log(Status.INFO, "Validation a pincode by Excel Sheet is
		// successfull");
	}

	/**********************
	 * Test case to add a product to the cart.
	 ********************/

	@Test(priority = 10)
	public void addToCartTest() {
		ProductPage prdctpg = new ProductPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", prdctpg.clickCart);
		prdctpg.clickViewCarts();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

		boolean titlebar = wait.until(ExpectedConditions.visibilityOf(prdctpg.viewCartSidebar)).isDisplayed();
		Assert.assertTrue(titlebar, "View cart is not displayed");

		// logger.log(Status.INFO, "Add to cart operation is successfull");

	}

	/************************
	 * Test case to view and remove items from the cart.
	 ************************/

	@Test(priority = 11)
	public void viewCartTest() {
		CartPage crtpg = new CartPage(driver);
		crtpg.clickViewCartsButton();
		crtpg.clickRemoveFromCartsButton();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		boolean check = wait.until(ExpectedConditions.visibilityOf(crtpg.checkaftrrmvItem)).isDisplayed();
		Assert.assertTrue(check, "Empty cart is not displayed");

		// logger.log(Status.INFO, "View cart and remove the product in cart operation
		// is successfull");

	}

	/****************
	 * Tear-down method to close the WebDriver after all test methods.
	 ***************/

	@AfterTest
	public void tearDown() {
		// Close the browser after each test method
		driver.quit();
	}

}