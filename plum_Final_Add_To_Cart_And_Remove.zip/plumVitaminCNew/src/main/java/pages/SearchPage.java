package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class SearchPage extends DriverUtils {
	WebDriver driver;

	public SearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**************** Search Product ***************/

	@FindBy(id = "searchfeild")
	public WebElement srch;

	/***************** Check Box ***************/

	@FindBy(xpath = "(//div[@class=\"st-sidebar-content\"]//div[contains(@class,\"st-filter-open\")]//ul[contains(@class,\" st-filter-items\")]//li//div[@class=\"outer-checkbox\"]//label[@class=\"st-flex\"]//span[@class=\"st-checkbox\"])[1]")
	public WebElement checkbox;

	@FindBy(xpath = "(//div[contains(@class,\" st-filter-open\")]//span[@class=\"filter-clear\"])[1]")
	public WebElement clearCheckBox;

	/************ drpdwn working in demobuyproduct ***************/

	@FindBy(xpath = "(//div[@class=\"st-sort-dropdown\"]//span[@class=\"st-sort-box\"])[2]")
	public WebElement dropdownBtn;

	@FindBy(xpath = "(//div[contains(@class,\"st-toolbox-right\")]//div[@class=\"st-sort-dropdown\"]//span)[17]")
	public WebElement dropdown_relevance;

	@FindBy(xpath = "(//div[contains(@class,\"st-toolbox-right\")]//div[@class=\"st-sort-dropdown\"]//span)[18]")
	public WebElement dropdown_new_arrivals;

	@FindBy(xpath = "(//div[contains(@class,\"st-toolbox-right\")]//div[@class=\"st-sort-dropdown\"]//span)[19]")
	public WebElement dropdown_A_To_Z;

	@FindBy(xpath = "(//div[contains(@class,\"st-toolbox-right\")]//div[@class=\"st-sort-dropdown\"]//span)[21]")
	public WebElement dropdown_price_lowtohigh;

	@FindBy(xpath = "(//div[contains(@class,\"st-toolbox-right\")]//div[@class=\"st-sort-dropdown\"]//span)[22]")
	public WebElement dropdown_price_hightolow;

	/**************** Choose the product ***************/

	@FindBy(xpath = "//*[@id=\"searchModal\"]/div/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/figure")
	public WebElement firstProduct;

	/**************** Search Product ***************/

	public WebElement getSrch() {
		return srch;
	}

	public void clickSearchBar() {
		clickOn(srch);

	}

	public void sendSearchData(String text) {
		sendtext(srch, text);

	}

	/***************** Check Box ***************/

	public void clickCheckBox() {
		clickOn(checkbox);
	}

	public void clickClearCheckBox() {
		clickOn(clearCheckBox);
	}

	/**************** DropDown ***************/

	public void clickDropdownBtn() {
		// clickOn(dropdownBtn);
		mouseOver2(dropdownBtn);
	}

	public void clickDrpdnRelevance() {
		clickOn(dropdown_relevance);
	}

	public void clickDrpdnNewArivals() {
		clickOn(dropdown_new_arrivals);
	}

	public void clickDrpdnA_Z() {
		clickOn(dropdown_A_To_Z);
	}

	public void clickDrpdnPriceLowToHigh() {
		clickOn(dropdown_price_lowtohigh);
	}

	public void clickDrpdnPriceHighToLow() {
		clickOn(dropdown_price_hightolow);
	}

	/**************** Choose the product ***************/

	public ProductPage clickFirstProduct() {
		clickOn(firstProduct);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.urlToBe(
				"https://plumgoodness.com/products/vitamin-c-glow-boosting-ctsm-combo-foaming-face-wash-toner-serum-moisturizer-boosts-glow-fights-hyperpigmentation-dark-spots-all-skin-types-100-vegan"));
		return PageFactory.initElements(driver, ProductPage.class);
	}

}