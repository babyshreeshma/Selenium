$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b6a92c94-82b8-43c5-b472-c958f6170a89","feature":"redirect to OFFERS page","scenario":"redirect to OFFERS page and verify the url","start":1691683016163,"group":1,"content":"","tags":"","end":1691683026901,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});