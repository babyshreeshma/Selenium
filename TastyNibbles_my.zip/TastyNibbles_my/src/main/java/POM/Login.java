package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class Login extends BaseUI{
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}
	
	//create account webelements

	@FindBy(xpath="//div[@class='site-nav__icons']//a[@class='site-nav__link site-nav__link--icon small--hide']")
	WebElement account;
	
	@FindBy(id="customer_register_link")
	WebElement create_account;
	
	@FindBy(id="FirstName")
	WebElement first_name;
	
	@FindBy(id="LastName")
	WebElement last_name;
	
	@FindBy(id="Email")
	WebElement email;
	
	@FindBy(id="CreatePassword")
	WebElement createpswd;
	
	@FindBy(xpath="//input[@class='btn btn--full']")
	WebElement create_btn;
	
	
	//login webelements
	
	@FindBy(id="CustomerEmail")
	WebElement cstemail;
	
	@FindBy(id="CustomerPassword")
	WebElement cstpswd;
	
	@FindBy(xpath="//button[@class='btn btn--full']")
	WebElement signInBtn;
	
	//create account methods
	public void clickAccount() {
		clickOn(account);
	}
	
	public void clickcreateAccount() {
		clickOn(create_account);
	}
	
	public void inputFirstname(String acntfirstname) {
		sendtext(first_name,acntfirstname);
	}
	
	public void inputLastname(String acntlastname) {
		sendtext(last_name,acntlastname);
	}
	
	public void inputEmail(String acntemail) {
		sendtext(email,acntemail);
	}
	
	public void inputPassword(String acntpswd) {
		sendtext(createpswd,acntpswd);
	}
	
	public void clickCreateButton() {
		clickOn(create_btn);
	}
	
	//Login webelements
	public void lgnEmail(String email) {
		sendtext(cstemail,email);
	}
	
	public void lgnPassword(String pswd) {
		sendtext(cstpswd,pswd);
	}
	
	public void clickLogin() {
		clickOn(signInBtn);
	}
	
	
	
}