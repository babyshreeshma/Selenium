package testAutomate;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import POM.Login;
import base.BaseUI;

public class loginTestCases extends BaseUI{
	WebDriver driver;
	Login login;
	
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	
	@Test(priority=0)
	public void userSignIn() {
		Login login = new Login(driver);
		login.clickAccount();
		login.clickcreateAccount();
		login.inputFirstname("sreeee");
		login.inputLastname("sreeshmaa");
		login.inputEmail("Sree@gmail.com");
		login.inputPassword("Sreee@123");
//		
//		String expectedURL = "https://supertails.com/";
//	    driver.get(expectedURL);
//	    String actualURL = driver.getCurrentUrl();
//	    Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
//	    SoftAssertions.assertSoftly(softAssertions -> {
//	    	softAssertions.assertThat(driver.findElement(By.id("nav--Dogs")).isDisplayed());
//	    	});
		
		String expectedurl= "https://www.tastynibbles.in/";
		String actualurl= driver.getCurrentUrl();
		Assert.assertEquals(actualurl, expectedurl, "URLs do match!");
		
	}
	

	@Test(priority=1)
	public void loginTest(String username,String password) {
		Login login = new Login(driver);
		login.clickcreateAccount();
		login.lgnEmail(username);
		login.lgnPassword(password);
		login.clickLogin();
		
	
		
		
	}
	
	
}