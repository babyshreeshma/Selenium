package stepDefinitions;

import org.junit.Assert;

import POM.offer;
import base.BaseUI;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class offerTest extends BaseUI{
	offer off;
	@Given("user is on home page")
	public void user_is_on_home_page() {
	    // Write code here that turns the phrase above into concrete actions
		driver = invokebrowser();
		openBrowser("applicationURL");
		off = new offer(driver);
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
	    // Write code here that turns the phrase above into concrete actions
		off.clickDirectoffer();
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
	    // Write code here that turns the phrase above into concrete actions
		String actualURL =driver.getCurrentUrl();
		System.out.println(actualURL);
		String expectedURL="https://www.tastynibbles.in/";
		//Assert.assertEquals(actualURL, expectedURL, "URLs are not the same");
		Assert.assertEquals(actualURL, expectedURL);
	}



}
