package com.example.APItestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.example.endpoints.UserEndPoints;
import com.example.payload.UserModel;
import com.example.utilities.DataProviders;
import io.restassured.response.Response;

public class DataDrivenTest {
	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPostUser(String name, String id, String age, String salary) {
	    UserModel user = new UserModel();
	    user.setUsername(name);
	    user.setId(Integer.parseInt(id));
	    user.setAge(age);
	    user.setSalary(salary);
	    String userStatus = null;
	    user.setUserStatus(userStatus);

	    Response response = UserEndPoints.createUser(user);
	    response.then().log().all();
	    
	    String actualStatus = response.jsonPath().getString("status");
	    Assert.assertEquals(actualStatus, "success");
	}



	@Test(priority = 2, dataProvider = "ID", dataProviderClass = DataProviders.class)
    public void testDeleteByUserID(int id) {
        Response response = UserEndPoints.deleteUser(id);
        response.then().log().all();
        
        // Assuming the status is returned in the response
        String actualStatus = response.jsonPath().getString("status");
        Assert.assertEquals(actualStatus, "success");
       
    }

}