package com.example.APItestcases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import com.example.endpoints.UserEndPoints;
import com.example.payload.UserModel;
import io.restassured.response.Response;

public class UserTests {
    UserModel userPayload;

    @BeforeClass
    public void setup() {
        userPayload = new UserModel();
        userPayload.setUsername("Anna");
        userPayload.setId(12);
        userPayload.setAge("23");
        userPayload.setSalary("20000");
    }

    @Test(priority = 1)
    public void testPostUser() {
        Response response = UserEndPoints.createUser(this.userPayload);
        response.then().log().all();
        AssertJUnit.assertEquals(response.jsonPath().getString("status"), "success");
    }
//    @Test(priority = 2)
//    public void testGetUserById() {
//        int userId = this.userPayload.getId(); // Get the user ID from the payload
//        Response response = UserEndPoints.getUser(userId);
//        response.then().log().all();
//        
//        AssertJUnit.assertEquals(response.jsonPath().getString("status"), "success");
//    }

    @Test(priority = 2)
    public void testGetUserById() {
        Response response = UserEndPoints.getUser(this.userPayload.getId());
        response.then().log().all();
        System.out.println(response.getBody().asString());
        AssertJUnit.assertEquals(response.jsonPath().getString("status"), "success");
    }

   @Test(priority = 3)
   public void testUpdateUserById() {
       // Update data using payload
        userPayload.setUsername("Anna");
        userPayload.setAge("23");
        userPayload.setSalary("40000");
        Response response = UserEndPoints.updateUser(this.userPayload.getId(), userPayload);
        response.then().log().all();
        AssertJUnit.assertEquals(response.jsonPath().getString("status"), "success");
        // Checking data after updation
        Response responseAfterUpdate = UserEndPoints.getUser(this.userPayload.getId());
        responseAfterUpdate.then().log().all();
        AssertJUnit.assertEquals(responseAfterUpdate.jsonPath().getString("status"), "success");
   }

   @Test(priority = 4)
    public void testDeleteUserById() {
      Response response = UserEndPoints.deleteUser(this.userPayload.getId());
    response.then().log().all();
      AssertJUnit.assertEquals(response.jsonPath().getString("status"), "success");
   }
}
