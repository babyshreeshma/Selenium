package com.example.payload;

public class UserModel {
    private String username;
    private int id;
    private String age;
    private String salary;
    private String userStatus = null;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getUserStatus() {
        return userStatus;
    }

	public void setUserStatus(String userstatus) {
		this.userStatus=userstatus;
	}

}

