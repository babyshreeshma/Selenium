package com.example.endpoints;

public class Routes {
	public static String baseuri = "https://dummy.restapiexample.com/api/v1";
	public static String post_basePath = "/create";
	public static String get_basePath = "/employee/{id}";
	public static String delete_basePath = "/delete/{id}";
	public static String update_basePath = "/update/{id}";
}