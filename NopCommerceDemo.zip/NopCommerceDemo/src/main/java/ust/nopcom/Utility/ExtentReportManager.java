package ust.nopcom.Utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import ust.nopcom.Base.UIbase;




public class ExtentReportManager extends UIbase {
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent=new ExtentReports();
		String repName="TestReport-"+UIbase.timestamp+".html";
		spark=new ExtentSparkReporter(System.getProperty("user.dir")
				+"/TestOutput/"+repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment","Production");
		extent.setSystemInfo("User Name","Anjali");
		spark.config().setDocumentTitle("NopCommerce Report");
		//Name of the report
		spark.config().setReportName("NopCommerceDemo Report");
		//Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}
}
