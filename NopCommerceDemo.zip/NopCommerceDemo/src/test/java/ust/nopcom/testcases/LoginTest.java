package ust.nopcom.testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;


import ust.nopcom.Base.UIbase;
import ust.nopcom.POM.Login;
import ust.nopcom.Utility.Excelutilits;
import ust.nopcom.Utility.Excelutils2;

@Listeners(ust.nopcom.Utility.SampleListener.class)
public class LoginTest extends UIbase{
	WebDriver driver;
	Login cont;
	String[][] data;

	
	//Method for calling the broswer
	@BeforeMethod
	public void setup()
	{
		driver=invokebrowser();
		openBrowser("applicationURL");
	}
	//Method to get the value from excel
	@DataProvider(name = "testData")
	public Object[][] testdata()
	{
		data= Excelutilits.testdata();
		return data;

	}
	@DataProvider(name = "testdata1")
	public Object[][] testdata1()
	{
		data= Excelutils2.testdata();
		return data;

	}
	@Test(priority=1,dataProvider="testdata1")
	public void register(String firstname,String lastname,String mail,String password,String confPass) {
		Login cont=new Login(driver);
		cont.Register1();
		cont.FirstName(firstname);
		cont.LastName(lastname);
		cont.Email1(mail);
		cont.Password1(password);
		cont.confirmPas(confPass);
		cont.Register();
		
	}
	//Method to perform login and corresponding assertions
	@Test(priority=2,dataProvider="testData")
	public void loginTest(String email,String password)
	{
		String a="https://demo.nopcommerce.com/";
		driver.get(a);
		
		Login cont=new Login(driver);
		cont.login();
		cont.Email(email);
		cont.password(password);
		cont.submit();	
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
		});	
		
		String j=cont.errorm();
		if((email.equals("IncorrectUser")))
		{
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
						+ "No customer account found"));
			});
		}
		else if(password.equals(" "))
		{
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(j.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
						+ "No customer account found"));
			});
		}
		else
		{
			
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
			});	
			
			
	}
			
	}
	@Test(priority=3)
	public void productSelect() {
		
		Login cont=new Login(driver);
		cont.Electronics();
		cont.cellPhoneClick();
		cont.phoneClick();
		cont.cartClick();
	}

}

