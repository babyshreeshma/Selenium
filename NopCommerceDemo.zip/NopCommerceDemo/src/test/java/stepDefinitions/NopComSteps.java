package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ust.nopcom.Base.BrowserConfig;
import ust.nopcom.POM.Login;

public class NopComSteps {

	public static String title;
	public WebDriver driver1=BrowserConfig.getBrowser();
	public Login c1=new Login(driver1);
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver1.get("https://demo.nopcommerce.com/");
	}

	@When("user gets the title of  page")
	public void user_gets_the_title_of_page() {
		title=c1.getTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		title=c1.getTitle();
		Assert.assertEquals(title,string);
	}
	@When("user clicks login")
	public void user_clicks_login() {
	    c1.login();
	}

	@When("user enters email {string}")
	public void user_enters_email(String string) {
	    c1.Email(string);
	}

	@When("user enters username {string}")
	public void user_enters_username(String string) {
		c1.password(string);
	    
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
	    c1.submit();
	}
}
