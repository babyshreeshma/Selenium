$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"52636995-5062-4d70-a1ca-ff5fa83eced9","feature":"Login page feature","scenario":"Login page title","start":1692868938617,"group":1,"content":"","tags":"","end":1692868946435,"className":"passed"},{"id":"70cf4be6-aca1-4a7f-8b02-8cdadc21bb42","feature":"Login page feature","scenario":"Login with correct credentials","start":1692868946456,"group":1,"content":"","tags":"","end":1692868954782,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});