package testCases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Base.DriverUtils;
import Pages.demoBuyProduct;
import Utility.Excelutilits;

@Listeners(Utility.SampleListener.class)
public class demoTest extends DriverUtils {
	WebDriver driver;
	demoBuyProduct buyproduct;
	String[][] data;

	/*** Setup method to initialize the WebDriver and open the application. ***/

	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
		buyproduct = new demoBuyProduct(driver);// Initialize

	}

	/************
	 * Data provider method for test data.
	 * 
	 * @return 2D array of test data.
	 *************/

	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = Excelutilits.testdata();
		return data;
	}

	/*********** Test case to search for a product. ************/

	@Test(priority = 0)
	public void searchTest() {
		demoBuyProduct buyproduct = new demoBuyProduct(driver);
		String text = "charcoal";
		buyproduct.clickSearchBar(text);
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.ENTER).perform();

		String expectedUrl = "https://plumgoodness.com/search?q=charcoal";
		String actualUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});

		logger.log(Status.INFO, "Search Test is successfull");
	}

	/************** Test case to handle checkbox. ***************/

	@Test(priority = 1)
	public void checkboxTest() {
		buyproduct.clickCheckBox();
		buyproduct.clickClearCheckBox();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean btnclr = wait.until(ExpectedConditions.invisibilityOf(buyproduct.clearCheckBox));
		softAssertions.assertThat(btnclr).as("View cart is displayed").isTrue();

		logger.log(Status.INFO, "Checkbox Test is successfull");
	}

	/******************* Test case to handle Dropdown *******************/

	@Test(priority = 2)
	public void chooseDropdownTest() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		buyproduct.clickDropdown();

		buyproduct.clickDrpdnRelevance();
		boolean isPrice_high_lowDisplayed = wait.until(ExpectedConditions.visibilityOf(buyproduct.dropdown_relevance))
				.isDisplayed();
		Assert.assertTrue(isPrice_high_lowDisplayed, "Dropdown with relevance is displayed");

		buyproduct.clickDrpdnNewArivals();
		boolean isNew_ArivalsDisplayed = wait.until(ExpectedConditions.visibilityOf(buyproduct.dropdown_new_arrivals))
				.isDisplayed();
		Assert.assertTrue(isNew_ArivalsDisplayed, "Dropdown with high to low is displayed");

		buyproduct.clickDrpdnA_Z();
		boolean isA_ZDisplayed = wait.until(ExpectedConditions.visibilityOf(buyproduct.dropdown_A_To_Z)).isDisplayed();
		Assert.assertTrue(isA_ZDisplayed, "Dropdown with A to Z is displayed");

		buyproduct.clickDrpdnPriceLowToHigh();
		boolean isLow_To_HighDisplayed = wait
				.until(ExpectedConditions.visibilityOf(buyproduct.dropdown_price_lowtohigh)).isDisplayed();
		Assert.assertTrue(isLow_To_HighDisplayed, "Dropdown with low to high is displayed");

		buyproduct.clickDrpdnPriceHighToLow();
		boolean isHigh_LowDisplayed = wait.until(ExpectedConditions.visibilityOf(buyproduct.dropdown_price_hightolow))
				.isDisplayed();
		Assert.assertTrue(isHigh_LowDisplayed, "Dropdown with high to low is displayed");

		logger.log(Status.INFO, "Dropdown Test is successfull");
	}

	/*******************
	 * Test case to choose a product from the search results.
	 *****************/

	@Test(priority = 3)
	public void chooseProductTest() {
		buyproduct.clickFirstProduct();
		String expectedUrl = "https://plumgoodness.com/products/phy-charcoal-deep-cleansing-face-wash";
		String actualUrl = driver.getCurrentUrl();
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});

		logger.log(Status.INFO, "Choose a product from the search results is successfull");
	}

	/***************
	 * Test case to change the product quantity by the text box
	 ********************/

	@Test(priority = 4)
	public void changeProductQuantityTest() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement quantityField = buyproduct.clickQuantity();
		wait.until(ExpectedConditions.elementToBeClickable(quantityField));
		quantityField.clear();

		String qty = "2";
		buyproduct.clickAndSendQunatity(qty);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat((buyproduct.prodQuantity).equals(2));

		});

		logger.log(Status.INFO, "Change the product quantity by the text box is successfull");

	}

	/***************
	 * Test cases to change the product quantity by the buttons
	 ********************/

	@Test(priority = 5)
	public void changeProductQuantityByMinusTest() {
		buyproduct.clickDecreaseQuantity();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat((buyproduct.prodQuantity).equals(1));

		});

		logger.log(Status.INFO, "Change the product quantity by minus button is successfull");

	}

	@Test(priority = 6)
	public void changeProductQuantityByPlusTest() {
		buyproduct.clickIncreaseQuantity();

		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat((buyproduct.prodQuantity).equals(2));

		});

		logger.log(Status.INFO, "Change the product quantity by plus button is successfull");

	}

	/***************** Test case to validate a pincode. ******************/

	@Test(priority = 7)
	public void pincodeValidationTest() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		String pinno = "123456";
		buyproduct.clickPin(pinno);
		buyproduct.clickCheckPin();
		String invalid = buyproduct.invalidMsg();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping is not available."));
		});

		logger.log(Status.INFO, "Pincode validation is successfull");

	}

	/*****************
	 * Test case to validate a pincode by Excel Sheet
	 ******************/

	@Test(dataProvider = "testData", priority = 8)
	public void pincodeByExcelTest(String pincode) throws InterruptedException {
		buyproduct.clickPin(pincode);
		buyproduct.clickCheckPin();
		String invalid = buyproduct.invalidMsg();
		if (pincode.equals("12345")) {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Invalid pincode"));
			});

		} else if (pincode.equals("123456")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping is not available."));
			});
		} else {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping Available!"));
			});
		}

		logger.log(Status.INFO, "Validation a pincode by Excel Sheet is successfull");

	}

	/**********************
	 * Test case to add a product to the cart.
	 ********************/

	@Test(priority = 9)
	public void addToCartTest() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", buyproduct.clickCart);
		buyproduct.clickViewCarts();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean titlebar = wait.until(ExpectedConditions.visibilityOf(buyproduct.viewCartSidebar)).isDisplayed();
		softAssertions.assertThat(titlebar).as("View cart is displayed").isTrue();

		logger.log(Status.INFO, "Add to cart operation is successfull");

	}

	/************************
	 * Test case to view and remove items from the cart.
	 ************************/

	@Test(priority = 10)
	public void viewCartAndRemoveFromTest() {
		buyproduct.clickViewCartsButton();
		buyproduct.clickRemoveFromCartsButton();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean check = wait.until(ExpectedConditions.visibilityOf(buyproduct.checkaftrrmvItem)).isDisplayed();
		softAssertions.assertThat(check).as("Empty cart is displayed").isTrue();

		logger.log(Status.INFO, "View cart and remove the product in cart operation is successfull");

	}

	/****************
	 * Tear-down method to close the WebDriver after all test methods.
	 ***************/

	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}