package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.DriverUtils;

public class demoBuyProduct extends DriverUtils {
	WebDriver driver;

	public demoBuyProduct(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}

	/**************** Search Product ***************/

	@FindBy(id = "searchfeild")
	public WebElement srch;

	/**************** Choose the product ***************/

//	@FindBy(xpath="//img[@class=\"main-img\"]")
//	@FindBy(xpath="((//div[@class=\"st-product\"]//figure[@class=\"st-product-media\"]//a)[1]")
	// @FindBy(className="st-product-wrap")
//	@FindBy(linkText="Phy Charcoal 2-In-1 Face Mask")
	// @FindBy(xpath="(//div[contains(@class,
	// st-product-wrap)]//div[@class=\"st-product\"]//a)[1]")
//	@FindBy(xpath="//*[contains(@id, 'searchModal')]/div/div[2]/div[1]/div[2]/div[1]/div/div[1]/div[1]\r\n")
	@FindBy(xpath = "//*[@id=\"searchModal\"]/div/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/figure/a/img[1]")
	public WebElement firstProduct;

	/***************** Change Product Quantity **************/

	@FindBy(name = "quantity")
	public WebElement prodQuantity;
	@FindBy(xpath = "//div[@id=\"product-variants\"]//div[2]//div//a[1]")
	public WebElement minus;
	@FindBy(xpath = "//div[@id=\"product-variants\"]//div[2]//div//a[2]")
	public WebElement plus;

	/*************** Pincode Operations ****************/

	@FindBy(id = "pincode_input")
	public WebElement pin;
	@FindBy(id = "check-delivery-submit")
	public WebElement checkPin;
	@FindBy(xpath = "//form[@id=\"add-to-cart-form\"]/div[5]/div/ul/li[2]")
	public WebElement errormsg;

	/***************** Check Box ***************/

	@FindBy(xpath = "(//div[@class=\"outer-checkbox\"]//span[@class=\"st-checkbox\"])[1]")
	public WebElement checkbox;

	@FindBy(xpath = "(//div[contains(@class,\" st-filter-open\")]//span[@class=\"filter-clear\"])[1]")
	public WebElement clearCheckBox;

	/**************** DropDown ***************/

	// @FindBy(xpath = "(//div[@class=\"st-sort-dropdown\"]//span)[15]")
	@FindBy(xpath = "(//div[@class=\"st-sort-dropdown\"]//span[@class=\"st-sort-box\"])[2]")
	public WebElement dropdown;
	// @FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//span)[5]")
	// @FindBy(xpath="(//div[contains(@class,\"st-hidden-sm\")]//div[@class=\"st-sort-dropdown\"]//span)[5]")
	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[1]/span")

	// @FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li//span)[1]")
	public WebElement dropdown_relevance;
	// @FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//span)[6]")
	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[2]/span")
	public WebElement dropdown_new_arrivals;

//	@FindBy(xpath="/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/span[2]")
//	public WebElement dropdown;
//	//@FindBy(xpath="((//span[@class=\"active-sort\"])[2]")
//	//@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li[1]//span[@class=\"active-sort\"])[1]")
//	
//	@FindBy(xpath="/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[1]/span")
//	public WebElement dropdown_relevance;
//	@FindBy(xpath="(//ul[@class=\"st-sorting\"]/li[2]/span)[2]")
//	public WebElement dropdown_new_arrivals;
//	@FindBy(xpath="/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[6]/span")
//	public WebElement dropdown_price_hightolow;
//	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//span)[22]")
//	@FindBy(xpath="(//div[contains(@class,\\\"st-hidden-sm\\\")]//div[@class=\\\"st-sort-dropdown\\\"]//span)[22]\")")

	// @FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li)[6]")

	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[3]/span")
	public WebElement dropdown_A_To_Z;

	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[5]/span")
	public WebElement dropdown_price_lowtohigh;

	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[6]/span")
	// @FindBy(linkText="Price, High to Low")
	public WebElement dropdown_price_hightolow;

	/*************** cart operations **************/

	@FindBy(name = "add")
	public WebElement clickCart;

	@FindBy(xpath = "//div[contains(@class,\"header-mb-right\")]//div[contains(@class,\"cart-icon\")]")
	public WebElement viewCart;

	@FindBy(xpath = "//*[@id=\"cart-item-40504810078268\"]/div/div[2]/a")
	public WebElement remove;
	@FindBy(xpath = "//div[@id=\"dropdown-cart\"]//div[3]//p[@class=\"cart_empty\"]")
	public WebElement emptyCart;

	@FindBy(xpath = "//div[@class=\"cart-title\"]")
	public WebElement viewCartSidebar;
	@FindBy(xpath = "//*[@id=\"dropdown-cart\"]/div[5]/div[2]/div[1]/a")
	public WebElement viewCartButton;

	@FindBy(xpath = "//div[@class=\"cart-remove-btn\"]//a[@class=\"remove\"]//span")
	public WebElement rmvItem;

	@FindBy(xpath = "//div[@id=\"shopify-section-cart-template\"]//p[1]")
	public WebElement checkaftrrmvItem;

	/**************** Search Product ***************/

	public void clickSearchBar(String text) {
		clickOn(srch);
		sendtext(srch, text);
	}

	/**************** DropDown ***************/

	public void clickDropdown() {
		clickOn(dropdown);
	}

	public void clickDrpdnRelevance() {
		clickOn(dropdown_relevance);
	}

	public void clickDrpdnNewArivals() {
		clickOn(dropdown_new_arrivals);
	}

	public void clickDrpdnA_Z() {
		clickOn(dropdown_A_To_Z);
	}

	public void clickDrpdnPriceLowToHigh() {
		clickOn(dropdown_price_lowtohigh);
	}

	public void clickDrpdnPriceHighToLow() {
		clickOn(dropdown_price_hightolow);
	}

	/***************** Check Box ***************/

	public void clickCheckBox() {
		clickOn(checkbox);
	}

	public void clickClearCheckBox() {
		clickOn(clearCheckBox);
	}

	/************** Choose First Product **************/

	public void clickFirstProduct() {
		clickOn(firstProduct);
	}

	/***************** Change Product Quantity **************/

	public WebElement clickQuantity() {
		clickOn(prodQuantity);
		return prodQuantity;

	}

	public void clickAndSendQunatity(String text) {
		sendtext(prodQuantity, text);
	}

	public void clickIncreaseQuantity() {
		clickOn(plus);
	}

	public void clickDecreaseQuantity() {
		clickOn(minus);
	}

	/*************** Pincode Operations ****************/

	public void clickPin(String pinnumber) {
		clickOn(pin);
		sendtext(pin, pinnumber);
	}

	public void clickCheckPin() {
		clickOn(checkPin);
	}

	public String invalidMsg() {
		return getText(errormsg);
	}

	/************** Cart Operations ******************/

	public void clickAddToCarts() {
		clickOn(clickCart);

	}

	public void clickViewCarts() {
		clickOn(viewCart);

	}

	public void clickRemoveProducts() {
		clickOn(remove);

	}

	public void clickViewCartsButton() {
		clickOn(viewCartButton);

	}

	public void clickRemoveFromCartsButton() {
		clickOn(rmvItem);

	}

}
