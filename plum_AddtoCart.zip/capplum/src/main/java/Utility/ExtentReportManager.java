package Utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import Base.DriverUtils;

public class ExtentReportManager extends DriverUtils {
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + DriverUtils.timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Sreeshma");
		spark.config().setDocumentTitle("Himalaya Report");
		// Name of the report
		spark.config().setReportName("HimalayaReport");
		// Dark Theme
		spark.config().setTheme(Theme.DARK);
		return extent;
	}
}
