$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"8ada160b-16c6-4eda-984e-a608d3d77a60","feature":"Contact Us page feature","scenario":"Home page title","start":1692873737315,"group":1,"content":"","tags":"","end":1692873750129,"className":"passed"},{"id":"750a9404-a056-4b3a-8861-8ac7d8b0deb3","feature":"Contact Us page feature","scenario":"Login with correct credentials","start":1692873750146,"group":1,"content":"","tags":"","end":1692873761649,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});