//Used to  Set Up a Browser//

package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfig {


	static WebDriver driver;
	
	public static WebDriver getBrowser() {
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		return driver;
}
}
