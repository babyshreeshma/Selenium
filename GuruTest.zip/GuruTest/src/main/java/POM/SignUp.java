package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;


public class SignUp extends BaseUI{
	
	WebDriver driver;
	
	public SignUp(WebDriver driver) {
		
	this.driver = driver;
	PageFactory.initElements(driver, this);
	
	}
	
	@FindBy(linkText = "REGISTER")
	WebElement reg;
	
	@FindBy(name = "lastName")
	WebElement lname;
	
	@FindBy(name = "firstName")
	WebElement fname;
	
	@FindBy(name = "phone")
	WebElement phn;
	
	@FindBy(id = "userName")
	WebElement email;
	
	@FindBy(name = "address1")
	WebElement address;
	
	@FindBy(name = "city")
	WebElement city;
	
	@FindBy(name = "state")
	WebElement state;
	
	@FindBy(name = "postalCode")
	WebElement p_code;
	
	@FindBy(name = "country")
	WebElement country;
	
	@FindBy(id = "email")
	WebElement u_name;
	
	@FindBy(name = "password")
	WebElement pass;
	
	@FindBy(name = "confirmPassword")
	WebElement confirmpass;
	
	@FindBy(name = "submit")
	WebElement submitbtn;
	
	public void clickregister() {
	clickOn(reg);
	}
	
	public void enterfirst(String f_name) {
	sendtext(fname,f_name);
	}
	
	public void enterlast(String l_name) {
	sendtext(lname,l_name);
	}
	
	public void enterphone(String p_h) {
	sendtext(phn,p_h);
	}
	
	public void enteremail(String e_mail) {
	sendtext(email,e_mail);
	}
	
	public void enteraddress(String addr) {
	sendtext(address,addr);
	}
	
	public void entercity(String c_ity) {
	sendtext(city,c_ity);
	}
	
	public void enterstate(String s_tate) {
	sendtext(state,s_tate);
	}
	
	public void enterp_code(String pcode) {
	sendtext(p_code,pcode);
	}
	
	public void enteruname(String uname) {
	sendtext(u_name,uname);
	}
	
	public void enterpass(String p_word) {
	sendtext(pass,p_word);
	}
	
	public void confirmpass(String c_pass) {
	sendtext(confirmpass,c_pass);
	}
	
	public void selectcountry(String country_name) {
	dropDownHandling(country, country_name);
	}
	
	public void clickSubmit() {
	clickOn(submitbtn);
	}
	
}









