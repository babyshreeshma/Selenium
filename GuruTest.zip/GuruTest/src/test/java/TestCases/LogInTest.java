package TestCases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.LogIn;
import Utilities.ExcelUtils;

@Listeners(Utilities.SampleListener.class)
public class LogInTest extends BaseUI{
	WebDriver driver;
	String data[][];
	
	@BeforeMethod
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	
	@DataProvider(name = "TestData")
	public Object[][] testdata(){
		data= ExcelUtils.testdata();
		return data;
	}
	
	//Test To Check If the User is able to Successfully Log-In
	@Test(priority=0, dataProvider="TestData")
	public void loginCheck(String name, String pass) {
		LogIn l1 = new LogIn(driver);
		l1.username(name);
		l1.password(pass);
		l1.loginsubmit();
	}
	
	//To Check if it is being redirected to the correct URL.
	@Test(priority=1)
	public void chechUrl() {
	String expectedURL = "https://demo.guru99.com/test/newtours/";
	driver.get(expectedURL);
	String actualURL = driver.getCurrentUrl();
	//Assertion is Used to check if The Expected URL and Actual URl is the Same
	Assert.assertEquals(actualURL, expectedURL, "URLs do match!");
	}
	
	@Test(priority=2)
	public void flightclick() {
		LogIn guru =new LogIn(driver);
		guru.Flightclick();
		guru.roundway();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//input[@value='roundtrip']")).isSelected());
        	});
		guru.passengerCount();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"passCount\"] /option[3]")).isSelected());
        	});
		guru.departingfrom();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"fromPort\"] /option[4]")).isSelected());
        	});
		guru.onMonth();
		guru.onDay();
		guru.arrive();
		guru.returnMonth();
		guru.returnDay();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name='toDay']/option[10]")).isSelected());
        	});
		guru.airline();
		guru.Continuebutton();
		guru.backtohome();
	}

	
	//To Automatically Close the Browser After The Test is Completed
	@AfterTest
	public void teardown() {
		driver.close();
		}
		
}