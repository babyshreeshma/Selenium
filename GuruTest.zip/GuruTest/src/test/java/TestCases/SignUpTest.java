package TestCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseUI;
import POM.SignUp;

@Listeners(Utilities.SampleListener.class)
public class SignUpTest extends BaseUI{

	WebDriver driver;
	public SignUp s1=new SignUp(driver);
	
	@BeforeTest
	//// used to set up the WebDriver and open the browser before executing the tests
	public void setup(){
		driver=invokebrowser();
		openBrowser("applicationURL");
		
	}
	
	
	//for checking if the Register Button is Working
	@Test(priority=0)
	public void siginClick() {
		SignUp s1=new SignUp(driver);
		s1.clickregister();
	
	}
	
	
	//For Checking if The User is able to Successfully SignUp 
	@Test(priority=1)
	public void userget() {
		SignUp s1=new SignUp(driver);
		
		//Feeds the Data into SignUp Page Using the Following Methods
		s1.enterfirst("Sreyas");
		s1.enterlast("S");
		s1.enterphone("1234567890");
		s1.enteremail("sreyas@gmail.com");
		s1.enteraddress("My Home");
		s1.entercity("Kottayam");
		s1.enterstate("Kerala");
		s1.enterp_code("686001");
		s1.enteruname("sreyas@gmail.com");
		s1.enterpass("abcd1234");
		s1.confirmpass("abcd1234");
		s1.clickSubmit();
	}
	
	//To Automatically Close the Browser After The Test is Completed
	@AfterTest
	public void teardown() {
		driver.close();
	}
}
