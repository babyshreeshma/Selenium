package stepDefinitions;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.BaseUI;
import POM.MainFile;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class blogDefinitions extends BaseUI{
	MainFile mainfile;

@Given("User is on home page")
public void user_is_on_home_page() {
    driver=invokeBrowser();
    openBrowser("applicationURL");
    mainfile=new MainFile();
}

@When("User clicks the blog button")
public void user_clicks_the_blog_button() {
   clickOn(mainfile.blog);
}

@Then("Blog page should displayed")
public void blog_page_should_displayed() {
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
	wait.until(ExpectedConditions.urlToBe("\"https://www.theitdepot.com/blog"));
    String actualUrl=driver.getCurrentUrl();
    String expectedUrl="https://www.theitdepot.com/blog";
    Assert.assertEquals("Current URL should match expected URL",expectedUrl, actualUrl);
    driver.quit();
}

}

