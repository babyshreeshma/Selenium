package TestCases;

import org.testng.annotations.Test;
import java.time.Duration;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import Base.BaseUI;
import POM.MainFile;

@Listeners(Utilities.SampleListener.class)
public class MainFileTest extends BaseUI{
	WebDriver driver;
	MainFile mainfile;
	
	
	//method for opening the browser and the URL of the website
	@BeforeMethod
	public void setup() {
		driver=invokeBrowser();
		openBrowser("applicationURL");//applixcationURL is defined in the configuration.properties
		mainfile=new MainFile(); 	
	}
	
	
	//Testing is the correct home page is displaying,is the url is displayed is correct
	@Test
	public void correctHomePageTest() {
		String expectedURL = "https://www.theitdepot.com/";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    logger.log(Status.INFO, "Correct home page displays");
		
	}
	

	//working-Testing is the shopping cart button is redirecting to cat page 
	@Test
	public void shopingCartTest() {
		mainfile.openCart();
		String expectedURL = "https://www.theitdepot.com/shopping-cart.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	   logger.log(Status.INFO, "Shopping cart is clickable");
		
	}
	
	//working-Testing is the egift button is redirecting to egift page 
	@Test
	public void egiftTest() {
		mainfile.openCart();
		String expectedURL = "https://www.theitdepot.com/egift-voucher.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	    logger.log(Status.INFO, "Shopping cart is clickable");	
	}
	
	//working-Testing is the customize your PC  is redirecting to customize your PC page 
	@Test
	public void openCustomizePCTest() {
		mainfile.openCart();
		String expectedURL = "https://www.theitdepot.com/build_your_own_desktop_pc.html";
	    String actualURL = driver.getCurrentUrl();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(actualURL.equals(expectedURL));
	   logger.log(Status.INFO, "Shopping cart is clickable");
		
	}
	//Testing is the button leads to next page-it searches for the keyboard and searchresults gives
		//speakers in next page
		@Test
		public void searchTest() {
			String text="Speaker";
			//Actions actions = new Actions(driver);
			//actions.moveToElement(mainfile.srchbar).click().build().perform();
			mainfile.clickSearchBar(text);
			mainfile.clickSearchBtn();
			String expectedUrl="https://www.theitdepot.com/search.html?keywords=Speaker";
			String actualUrl=driver.getCurrentUrl();
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			Boolean element=wait.until(ExpectedConditions.urlContains(text));
			SoftAssertions.assertSoftly(softAssertions->{
				softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
			});	
			logger.log(Status.INFO, "Searching is successfull");
		}
		
	
	//Testing is the dropdown of brand:a to z option is clickable or not
	@Test
	public void atozdropdownTest() {
		mainfile.openDropdown();
		String text="Speaker";
		mainfile.clickSearchBar(text);
		mainfile.clickSearchBtn();
		SoftAssertions.assertSoftly(softAssertions -> {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			// Check whether the dropdown with A to Z option is displayed
			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.visibilityOf(mainfile.atoz)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with A to Z option is displayed").isTrue();
		});
		logger.log(Status.INFO, "A to Z dropdown is successfull");
	}
	
	//Testing is the dropdown of brand:z to a option is clickable or not
		@Test
		public void zotadropdownTest() {
			mainfile.openDropdown();
			String text="Speaker";
			mainfile.clickSearchBar(text);
			mainfile.clickSearchBtn();
			SoftAssertions.assertSoftly(softAssertions -> {
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
				// Check whether the dropdown with Z to A option is displayed
				boolean isDropdownDisplayed = wait
						.until(ExpectedConditions.visibilityOf(mainfile.atoz)).isDisplayed();
				softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with Z to A option is displayed").isTrue();
			});
			logger.log(Status.INFO, "Z to A dropdown is successfull");
		}
		
		
	//for quiting the website after every execution of the methods
	@AfterMethod
	public void teardown() {
		driver.quit();
	}

}

