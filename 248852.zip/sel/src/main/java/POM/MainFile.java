package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.BaseUI;


public class MainFile extends BaseUI{
	WebDriver driver;
	
	//constructor of the class
	public void MainFile(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	//Setting the webelements with thiere respective id's and xpaths
	@FindBy(xpath = "//input[@id=\"keywords\"]")
	public WebElement srchbar;
	@FindBy(xpath = "//form[@id=\"search\"]//div[@class='input-group']//div[@class='input-group-append']//button[@class='btn btn-danger']")
	public WebElement srchbtn;
	@FindBy(id = "search_sort_dropdown")
	public WebElement dropdown;
	@FindBy(xpath = "//select[@id=\"search_sort_dropdown\"]/option[@value='brand_asc']")
	public WebElement atoz;
	@FindBy(xpath = "=//select[@id=\"search_sort_dropdown\"]/option[@value='brand_desc']")
	public WebElement ztoa;
	@FindBy(xpath = "//select[@id=\"search_sort_dropdown\"]/option[@value='price_desc']")
	public WebElement lowtohigh;
	@FindBy(xpath = "//select[@id=\"search_sort_dropdown\"]/option[@value='price_asc']")
	public WebElement hightolow;
	@FindBy(xpath = "//section[@id=\"home-banner\"]//div[@class='container']//div[@class='row pt-5']//div[@class='col-md-3']//p[@class='my-3 text-right']//a[@class='text-dark px-2']//span[@class='icon-shopping-bag font-weight-bold font-size11']")
	public WebElement cart;
	@FindBy(xpath = "//section[@id=\"home-banner\"]//div[@class='container']//div[@class='row pt-5']//div[@class='col-md-3']//p[@class='my-3 text-right']//a[@class='text-dark px-2']//span[@class='icon-shopping-bag font-weight-bold font-size11']")
	public WebElement blog;
	
	
	
	//Creating method for searching process in the website
	public void clickSearchBar(String text) {
		clickOn(srchbar);
		sendtext(srchbar,text);
	}

	//to click search button
	public void clickSearchBtn() {
		clickOn(srchbtn);
	}
	//method for opening dropdown
	public void openDropdown() {
		clickOn(dropdown);
	}
	//method for choosing atoz option in dropdown
	public void clickatoz() {
		clickOn(atoz);
	}
	//method for choosing ztoa option in dropdown
	public void clickztoa() {
		clickOn(ztoa);
	}
	//method for opening cart
	public void openCart() {
		clickOn(cart);
	}
	//method for opening blogpage
	public boolean isBlogPageIsOpen() {
		return blog.isDisplayed();
	}
}

