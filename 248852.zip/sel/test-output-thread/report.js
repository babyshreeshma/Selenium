$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"2dc5011c-ff84-4c4f-8f27-8aa47e363710","feature":"Blog Page feature","scenario":"Blog Page link","start":1691649981822,"group":1,"content":"","tags":"","end":1691650024394,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});