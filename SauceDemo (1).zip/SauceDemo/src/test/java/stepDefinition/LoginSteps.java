package stepDefinition;

import org.testng.Assert;

import com.ust.Base.BaseUI;
import com.ust.Base.BrowserConfig;
import com.ust.POM.Login;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseUI{
	@Given("Open chrome and go to Swaglabs application")
	public void open_chrome_and_go_to_swaglabs_application() {
	    // Write code here that turns the phrase above into concrete actions
		driver=BrowserConfig.getBrowser();
		invokeBrowser();
	}

	@When("I login with valid credentials")
	public void i_login_with_valid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
		Login login=new Login(driver);
		login.userName("admin");
		login.passWord("admin");
	}
	@Then("I should be able to login successfully")
	public void i_should_be_able_to_login_successfully() {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(true);
	}
	@When("I login with invalid credentials")
	public void i_login_with_invalid_credentials() {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(true);
	}
	@Then("I should not be able to login")
	public void i_should_not_be_able_to_login() {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(false);
	}
}
