package org.ust.Testcases;

import org.assertj.core.api.Assertions;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.POM.Login;
import com.ust.Utilities.ExcelUtils;

public class LoginTestCase extends BaseUI {
	WebDriver driver;
	Login login;

	@BeforeMethod
	public void setup() {
		driver = invokeBrowser();
		openBrowser("applicationURL");
	}

	@DataProvider(name = "testData")
	public Object[][] testData() {
		return ExcelUtils.testdata();
	}

	@Test(dataProvider = "testData")
	public void loginTest(String username, String password, String expected) throws InterruptedException {
		Login login = new Login(driver);
		login.userName(username);
		login.passWord(password);
		login.submit();
		//Thread.sleep(3000);
		 //login.Menu();
		 //Thread.sleep(3000);
		 //login.Logout();
		if ((username.equals("incorrectUser")) || (password.equals("incorrectPassword"))) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div/form/div[3]/h3")).isDisplayed());
			});
			Assertions.assertThat(driver.findElement(By.xpath("//div/form/div[3]/h3")).getText())
					.isEqualTo("Epic sadface: Username and password do not match any user in this service");
		} else if (username.equals("locked_out_user") && (password.equals("secret_sauce"))) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.findElement(By.xpath("//div/form/div[3]/h3")).isDisplayed());
			});
			Assertions.assertThat(driver.findElement(By.xpath("//div/form/div[3]/h3")).getText())
					.isEqualTo("Epic sadface: Sorry, this user has been locked out.");
		} else {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(driver.getCurrentUrl().contains("saucedemo.com/inventory.html"));
				softAssertions.assertThat(driver.findElement(By.className("app_logo")).equals(expected));
			});
		}
	}
	@AfterMethod
    public void tearDown() {
        // Close the browser after each test method
        driver.quit();
    }
}
