package org.ust.Testcases;

import java.time.Duration;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.ust.Base.BaseUI;
import com.ust.Base.BrowserConfig;
import com.ust.POM.SauceDemo_;


public class TestCases extends BaseUI {
	WebDriver driver;
	SauceDemo_ sauceDemoPage;

	@BeforeMethod
	public void setup() {
		driver = BrowserConfig.getBrowser();
		sauceDemoPage = new SauceDemo_(driver);
		driver.get("https://www.saucedemo.com/");
		// Log in with the specified credentials
		sauceDemoPage.login("standard_user", "secret_sauce");
	}

	@Test
	public void testAllItems() {
		// Instead of using the clickOnMenuButton() method, use actions directly
		WebElement menuButton = driver.findElement(sauceDemoPage.menu);
		Actions actions = new Actions(driver);
		actions.moveToElement(menuButton).click().build().perform();

		// Wait for the All Items button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement allItemsButton = wait
				.until(ExpectedConditions.elementToBeClickable(By.id("inventory_sidebar_link")));

		actions.moveToElement(allItemsButton).click().build().perform();

		// Verify that the user is still on the inventory page
		// (https://www.saucedemo.com/inventory.html)
		String expectedInventoryUrl = "https://www.saucedemo.com/inventory.html";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(sauceDemoPage.verifyCurrentUrl(expectedInventoryUrl)).isTrue();
		});
	}

	@Test
	public void testAbout() {
		// Instead of using the clickOnMenuButton() method, use actions directly
		WebElement menuButton = driver.findElement(sauceDemoPage.menu);
		Actions actions = new Actions(driver);
		actions.moveToElement(menuButton).click().build().perform();

		// Wait for the About button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement aboutButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("about_sidebar_link")));

		actions.moveToElement(aboutButton).click().build().perform();

		// Verify that the user is redirected to the external link
		// (https://saucelabs.com/)
		String expectedAboutUrl = "https://saucelabs.com/";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(sauceDemoPage.verifyCurrentUrl(expectedAboutUrl)).isTrue();
		});
	}

	@Test
	public void testLogout() {
		// Instead of using the clickOnMenuButton() method, use actions directly
		WebElement menuButton = driver.findElement(sauceDemoPage.menu);
		Actions actions = new Actions(driver);
		actions.moveToElement(menuButton).click().build().perform();

		// Wait for the Logout button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("logout_sidebar_link")));
		actions.moveToElement(logoutButton).click().build().perform();

		// Verify that the user is redirected to the home page
		// (https://www.saucedemo.com/)
		String expectedHomePageUrl = "https://www.saucedemo.com/";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(sauceDemoPage.verifyCurrentUrl(expectedHomePageUrl)).isTrue();
		});

	}

	@Test
	public void testTwitterButton() {
		// Scroll to the footer of the page
		sauceDemoPage.scrollToFooter();
		System.out.println("Starting the test: testTwitter()");
		
		// Click on the twitter
		System.out.println("Clicking on the twitter button...");
		// socialMedia.clickOnTwitter();

		// Wait for the Twitter button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement TwitterButton = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.twitterLocator));

		Actions actions = new Actions(driver);
		actions.moveToElement(TwitterButton).click().build().perform();

		// Wait for the page to load
		// WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.urlToBe("https://twitter.com/saucelabs"));

		// Verify that the user is redirected to the twitter page
		String expectedCartUrl = "https://twitter.com/saucelabs";
		String actualCartUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualCartUrl).isEqualTo(expectedCartUrl);
		});
	}

	@Test
	public void testFacebookButton() {
		// Scroll to the footer of the page
		sauceDemoPage.scrollToFooter();
		System.out.println("Starting the test: testFacebook()");

		// Click on the facebook
		System.out.println("Clicking on the Facebook button...");
		// socialMedia.clickOnFaceBook();
		// Wait for the FaceBook button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement FBButton = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.facebookLocator));

		Actions actions = new Actions(driver);
		actions.moveToElement(FBButton).click().build().perform();

		// Wait for the page to load
		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.urlToBe("https://www.facebook.com/saucelabs"));

		// Verify that the user is redirected to the facebook page
		String expectedCartUrl = "https://www.facebook.com/saucelabs";
		String actualCartUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualCartUrl).isEqualTo(expectedCartUrl);
		});
	}

	@Test
	public void testLinkedInButton() {
		// Scroll to the footer of the page
		sauceDemoPage.scrollToFooter();
		System.out.println("Starting the test: testLinkedin()");

		// Click on the linkedin
		System.out.println("Clicking on the Linkedin button...");
		// socialMedia.clickOnLinkedin();
		// Wait for the LinkedIn button to be clickable before performing the action
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement LinkedInButton = wait.until(ExpectedConditions.elementToBeClickable(sauceDemoPage.linkedInLocator));
		Actions actions = new Actions(driver);
		actions.moveToElement(LinkedInButton).click().build().perform();

		// Wait for the page to load
		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.urlToBe("https://www.linkedin.com/company/sauce-labs/"));

		// Verify that the user is redirected to the linkedin page
		String expectedCartUrl = "https://www.linkedin.com/company/sauce-labs/";
		String actualCartUrl = driver.getCurrentUrl();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualCartUrl).isEqualTo(expectedCartUrl);
		});
	}

	@AfterMethod
	public void tearDown() {
		// Close the browser after each test method
		driver.quit();
	}
}
