package com.ust.POM;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.ust.Base.BaseUI;

public class SauceDemo_ extends BaseUI {
	WebDriver driver;
	WebDriverWait wait;
	public By productSortContainer = getlocator("productSortContainer_className");
	public By sortNameAToZ = getlocator("sortNameAToZ_xpath");
	public By sortNameZToA = getlocator("sortNameZToA_xpath");
	public By sortNameLohi = getlocator("sortNameLohi_xpath");
	public By sortNameHilo = getlocator("sortNameHilo_xpath");
	By productNames = getlocator("inventoryItemName_className");
	By productPrices = getlocator("priceList_xpath");
	public By shoppingCart = getlocator("shoppingCartContainer_xpath");
	By allItemsBtnLocator = getlocator("allItems_id");
	public By aboutBtnLocator = getlocator("about_id");
	By logoutBtnLocator = getlocator("logout_id");
	public By menu = getlocator("menu_xpath");
	By logout = getlocator("logout_linkText");
	public By twitterLocator = getlocator("twitterIconLink_xpath");
	public By facebookLocator = getlocator("facebookIconLink_xpath");
	public By linkedInLocator = getlocator("linkedinIconLink_xpath");
	public By footer = getlocator("footerText_xpath");
	public By DropDown = getlocator("dropdown_xpath");
	By continueShoppingButton = getlocator("continueShoppingButton_xpath");
	By checkoutButton = getlocator("checkoutButton_xpath");
	public By menuCrossButton = getlocator("menucross_xpath");
	public By firstname = By.id("first-name");
	public By lastname = By.id("last-name");
	public By postalcode = By.id("postal-code");
	public By continueButton = By.id("continue");
	public By cancelButton = getlocator("cancel_xpath");
	public By finishButton = By.id("finish_xpath");
	By footerButton = By.className("footer_className");
	public By backtohome = getlocator("back_id");

	public SauceDemo_(WebDriver driver) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(15)); // Initialize WebDriverWait
	}

	public void login(String username, String password) {
		// Find the username, password, and login button elements by their HTML
		// attributes (e.g., 'id', 'name', 'class', etc.)
		By usernameLocator = By.name("user-name");
		By passwordLocator = By.name("password");
		By loginButtonLocator = By.name("login-button");

		// Enter the credentials into the input fields
		driver.findElement(usernameLocator).sendKeys(username);
		driver.findElement(passwordLocator).sendKeys(password);

		// Locate and click the login button
		driver.findElement(loginButtonLocator).click();
	}

	public void clickOnShoppingCart() {
		By shoppingCartContainerLocator = getlocator("shoppingCart");
		clickOn(shoppingCartContainerLocator);
	}

	public List<String> getProductNames() {
		List<String> productNames = new ArrayList<>();
		List<WebElement> productNameElements = driver.findElements(this.productNames);
		for (WebElement element : productNameElements) {
			productNames.add(element.getText());
		}
		return productNames;
	}

	public void selectSortOption(By locator) {
		WebElement sortContainer = driver.findElement(productSortContainer);
		sortContainer.click();
		driver.findElement(locator).click();
	}

	public void selectNameAToZSortOption() {
		selectSortOption(sortNameAToZ);
	}

	public void selectNameZToASortOption() {
		selectSortOption(sortNameZToA);
	}

	public void selectPriceHighToLowSortOption() {
		selectSortOption(sortNameHilo);
	}

	public List<String> getProductNamesSortedAToZ() {
		List<String> productNames = getProductNames();
		productNames.sort(String::compareToIgnoreCase);
		return productNames;
	}

	public List<String> getProductNamesSortedZToA() {
		List<String> productNames = getProductNames();
		productNames.sort(Collections.reverseOrder());
		return productNames;
	}

	public List<String> getProductPrices() {
		List<String> productPrices = new ArrayList<>();
		List<WebElement> productPriceElements = driver.findElements(this.productPrices);
		for (WebElement element : productPriceElements) {
			productPrices.add(element.getText());
		}
		return productPrices;
	}

	public List<String> getProductPricesSortedHighToLow() {
		List<String> productPrices = getProductPrices();
		productPrices.sort(Collections.reverseOrder(new PriceComparator()));
		return productPrices;
	}

	public static class PriceComparator implements Comparator<String> {
		@Override
		public int compare(String price1, String price2) {
			System.out.println("Price1: " + price1 + ", Numeric Price1: " + extractNumericPrice(price1));
			System.out.println("Price2: " + price2 + ", Numeric Price2: " + extractNumericPrice(price2));

			double numericPrice1 = extractNumericPrice(price1);
			double numericPrice2 = extractNumericPrice(price2);
			return Double.compare(numericPrice1, numericPrice2);
		}

		private double extractNumericPrice(String price) {
			// String numericValue = price.replace("$", "").replace(",", "").trim();
			String numericValue = price.replaceAll("[^\\d.]", "");
			return Double.parseDouble(numericValue);
		}
	}

	// Method to scroll to the footer of the page
	public void scrollToFooter() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(By.xpath("//*[@id=\"page_wrapper\"]/footer")));
	}

	public void clickOnMenuButton() {
		System.out.println("Waiting for the menu button to be visible...");
		wait.until(ExpectedConditions.visibilityOfElementLocated(menu));
		System.out.println("Menu button is now visible. Clicking on it...");
		clickOn(menu);
	}

	// Click on All Items
	public void clickOnAllItems() {
		clickOn(allItemsBtnLocator);
	}

	// Click on About
	public void clickOnAbout() {
		clickOn(aboutBtnLocator);
	}

	// Click on Logout
	public void clickOnLogout() {
		clickOn(logoutBtnLocator);
	}

	// Method to check if the current URL is equal to the expected URL
	public boolean verifyCurrentUrl(String expectedUrl) {
		String actualUrl = driver.getCurrentUrl();
		return actualUrl.equals(expectedUrl);
	}

	// Method to check if the shopping cart badge is displayed
	public boolean isShoppingCartBadgeDisplayed() {
		return isElementPresent(By.className("shopping_cart_badge"), Duration.ofSeconds(15));
	}

	// Method to click on the twitter
	public void clickOnTwitter() {
		clickOn(twitterLocator);
	}

	// Method to click on the facebook
	public void clickOnFaceBook() {
		clickOn(facebookLocator);
	}

	// Method to click on linkedin
	public void clickOnLinkedin() {
		clickOn(linkedInLocator);
	}

	public void openDropdown() {
		clickOn(DropDown);
	}

	public void click_A_to_Z() {
		clickOn(sortNameAToZ);
	}

	public void click_Z_to_A() {
		clickOn(sortNameZToA);
	}

	public void click_low_to_high() {
		clickOn(sortNameLohi);
	}

	public void click_high_to_low() {
		clickOn(sortNameHilo);
	}

	public void waitAndClick(By locator) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
		element.click();
	}

	public void clickContinueShoppingButton() {
		waitAndClick(continueShoppingButton);
	}

	public void clickCheckoutButton() {
		waitAndClick(checkoutButton);
	}

	public void firstName(String firstName) {
		driver.findElement(firstname).sendKeys(firstName);
	}

	// Fill in Last Name
	public void lastName(String lastName) {
		driver.findElement(lastname).sendKeys(lastName);
	}

	// Fill in Postal Code
	public void postalName(String postalCode) {
		driver.findElement(postalcode).sendKeys(postalCode);
	}

	public void clickContinue() {
		clickOn(continueButton);
	}

	public void clickCancel() {
		clickOn(cancelButton);
	}

	public void clickFinish() {
		clickOn(finishButton);
	}

	public void clickHome() {
		clickOn(backtohome);
	}
	
	public void clickOnMenuCross() {
		clickOn(menuCrossButton);
	}

	public void clickCheckout() {
		clickOn(checkoutButton);
	}

}