package com.ust.POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
	}

	By uname = getlocator("username_name");
	By password = getlocator("password_name");
	By submit = getlocator("submit_name");
	By menu = getlocator("menu_xpath");
	By logout = getlocator("logout_linkText");
	
	public void userName(String user) {
		sendtext(uname, user);
	}

	public void passWord(String pass) {
		isElementPresent(password, Duration.ofSeconds(15));
		sendtext(password, pass);
	}

	public void submit() {
		clickOn(submit);
	}
}

