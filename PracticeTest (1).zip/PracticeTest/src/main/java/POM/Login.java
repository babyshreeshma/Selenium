package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.Status;

import Base.BaseUI;

public class Login extends BaseUI {
	WebDriver driver;

	public Login(WebDriver driver) {
		this.driver = driver;
	}

	By uname = getlocator("username_name");
	By password = getlocator("password_name");
	By submit = getlocator("submitLogin_id");
	public By errorMessage = getlocator("errorlogin_id");
	By practice = getlocator("practice_xpath");
	By Login = getlocator("loginTest_xpath");
	By exception = getlocator("testException_xpath");
	public By editbtn = getlocator("edit_name");
	By saveBtn = getlocator("save_name");
	By saveBtn2 = getlocator("saverow2_xpath");
	By addBtn = getlocator("add_name");
	public By message = getlocator("message_id");
	By remove = getlocator("remove_name");
	public By text = getlocator("textBox_xpath");
	public By secondText = getlocator("secondTextBox_xpath");
	By courseDirect = getlocator("course_xpath");

	public void userName(String user) {
		sendtext(uname, user);
		String logMessage = "Entered username: " + user;
		logger.log(Status.INFO, logMessage);
	}

	public void passWord(String pass) {
		sendtext(password, pass);
		String logMessage = "Entered password";
		logger.log(Status.INFO, logMessage);
	}

	public void clickSubmitButton() {
		clickOn(submit);
		logger.log(Status.INFO, "Clicked on Submit button");
	}


	public void clickLoginpage() {
		clickOn(Login);
	}

	public void clickPractice() {
		clickOn(practice);

	}

	public void clickExceptionpage() {
		clickOn(exception);
	}

	public void clickEdit() {
		clickOn(editbtn);
	}

	public void clickSave() {
		clickOn(saveBtn);
	}
	public void clickSave2() {
		clickOn(saveBtn2);
	}

	public void clickAdd() {
		clickOn(addBtn);
	}

	public void clickRemove() {
		clickOn(remove);
	}
	
	public void clickMessage() {
		clickOn(message);
	}
	
	public void edit(String foodName) {
		driver.findElement(text).sendKeys(foodName);
		
	}
	
	public void editSecond(String secondFoodName) {
		//driver.findElement(secondText).click();
		driver.findElement(secondText).sendKeys(secondFoodName);
		
	}

	public void clear() {
		// TODO Auto-generated method stub
		driver.findElement(text).clear();
//		driver.findElement(text).sendKeys(Keys.CONTROL+"a");	
//		driver.findElement(text).sendKeys(Keys.BACK_SPACE);
	}

	public void clickDirectcourse() {
		// TODO Auto-generated method stub
		clickOn(courseDirect);
	}

}
