$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b110f64e-aa49-4c09-9c0e-5ce1a5837667","feature":"Product Review Tests","scenario":"User Logs In and Writes a Review","start":1695197211605,"group":1,"content":"","tags":"","end":1695197295695,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});