package stepDefinitions;

import java.time.Duration;

import org.junit.BeforeClass;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import base.BaseTest;
import base.DriverUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;
import pages.SelectedNewProduct;

public class ProductReviewSteps extends BaseTest {
	private HomePage home;
	private LoginPage login;
	private ProductsPage products;
	private SelectedNewProduct selectedProduct;

	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		login = new LoginPage(driver);
		products = new ProductsPage(driver);
		selectedProduct = new SelectedNewProduct(driver);
	}

	@Given("User is on the homepage")
	public void user_is_on_homepage() {
		setup();
		home = goToHomePage();
	}

	@When("User clicks the login button")
	public void user_clicks_login_button() {
		home.clickDirectHome();
	}

	@Then("User is directed to the login page")
	public void user_redirected_to_login_page() {
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account/login?return_url=%2Faccount";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Account");
	}

	@When("User logs in with valid credentials")
	public void user_logs_in_with_valid_credentials() {
		login = goToLoginPage();
		login.clickSignInLink("annapaul0712@gmail.com", "anna123");
	}

	@Then("User is successfully logged in")
	public void user_successfully_logged_in() {
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Login button");
	}

	@When("User clicks the Skin Care button")
	public void user_clicks_skin_care_button() {
		login = goToLoginPage();
		login.clickSkinCareBtn();
	}

	@Then("User is directed to the Skin Care products page")
	public void user_redirected_to_skin_care_page() {
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/skincare";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking SkinCare button");
	}

	@When("User clicks the Recommended button and clicks the High to Low button")
	public void user_clicks_the_recommended_button_and_clicks_the_high_to_low_button() {
		products = goToProductsPage();
		// Click the "Recommended" button on the products page.
		products.clickRecommendedButton();
		products.clickHighToLowButton();
	}

	@Then("Products are sorted by High to Low price order")
	public void products_are_sorted_by_high_to_low_price_order() {
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/skincare?sort=price-descending";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking High To Low button");
	}

	@When("User selects a product")
	public void user_selects_a_product() {
		products = goToProductsPage();
		products.clickSelectProduct();

	}

	@Then("User is directed to the selected product's page")
	public void user_is_directed_to_the_selected_products_page() {
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/products/bright-years-age-specialist-full-set-1";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking the product");

	}

	@When("User clicks the Write Review button")
	public void user_clicks_the_write_review_button() {
		selectedProduct = goToSelectedProductPage();
		selectedProduct.clickWriteReview();
	}

	@Then("User is directed to the review submission page")
	public void user_is_directed_to_the_review_submission_page() {
		// Verify that the "review title" button is displayed.
		Boolean Element = DriverUtils.waitTillElementToBeVisible(selectedProduct.reviewTitle, Duration.ofSeconds(30));
		// Assert that the option is displayed.
		Assert.assertTrue(Element, "Review Title Option is displayed");
	}

	@When("User fills in the review details")
	public void user_fills_in_the_review_details() {
		selectedProduct = goToSelectedProductPage();
		// Fill in other review details (name, email, review title, description)
		selectedProduct.clickSendText("Anna Paul", "annapaul@gmail.com", "Great Product", "This product is amazing!");
		// Submit the review
		selectedProduct.clickSubmitButton();
	}
	@And("User clicks the Submit button")
	public void user_clicks_the_submit_button() {
		selectedProduct = goToSelectedProductPage();
		// Submit the review
		selectedProduct.clickSubmitButton();
	}
	
	@Then("The review is successfully submitted")
	public void review_successfully_submitted() {
		// Verify that the "view review" button is displayed.
		WebElement Element = selectedProduct.viewReview;
		Assert.assertTrue(Element.isDisplayed(), "View Review Option is displayed");
	}
}
