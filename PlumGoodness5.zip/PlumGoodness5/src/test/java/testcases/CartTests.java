package testcases;

import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import base.BaseTest;
import base.DriverUtils;
import pages.CartPage;
import pages.ProductPage;
import pages.SearchPage;
import utilities.ExcelUtils;

import utilities.FileIO;
import utilities.SampleListener;

@Listeners(SampleListener.class)
public class CartTests extends BaseTest {

    private SearchPage srchpg;
    ProductPage prdctpg;
    CartPage crtpg;
    String[][] data;

    @BeforeClass
    public void MainTest() {
        srchpg = new SearchPage(driver);
        prdctpg = new ProductPage(driver);
        crtpg = new CartPage(driver);
        data = ExcelUtils.testdata();
    }

    /*********** Test case to search for a product. ************/

    @Test(priority = 1)
    public void searchTest() {
        srchpg = goToSearchPage();
        srchpg.clickSearchBar();
        String text = "vitamin C";
        srchpg.sendSearchData(text);
        srchpg.srch.sendKeys(Keys.ENTER);

        String expectedUrl = "https://plumgoodness.com/search?q=vitamin%20C";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl);
    }

    /************** Test case to handle checkbox. ***************/

    @Test(priority = 2)
    public void checkboxTest() {
        srchpg.clickCheckBox();
        srchpg.clickClearCheckBox();

        boolean btnclr = DriverUtils.waitTillElementToBeVisible(srchpg.clearCheckBox, Duration.ofSeconds(15));
        Assert.assertTrue(btnclr, "View cart is displayed");
    }

    /******************* Test case to handle Dropdown *******************/

    @Test(priority = 3)
    public void chooseDropdownTest() {
        srchpg.clickDropdownBtn();
        srchpg.clickDrpdnPriceHighToLow();

        boolean isHigh_LowDisplayed = DriverUtils.waitTillElementToBeVisible(srchpg.dropdown_price_hightolow, Duration.ofSeconds(15));
        Assert.assertTrue(isHigh_LowDisplayed, "Dropdown with high to low is displayed");
    }

    /*******************
     * Test case to choose a product from the search results.
     *****************/

    @Test(priority = 4)
    public void chooseProductTest() {
        srchpg.clickFirstProduct();
        String expectedUrl = "https://plumgoodness.com/products/vitamin-c-glow-boosting-ctsm-combo-foaming-face-wash-toner-serum-moisturizer-boosts-glow-fights-hyperpigmentation-dark-spots-all-skin-types-100-vegan";
        String actualUrl = DriverUtils.driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl, "URLs do not match");
    }

    /***************
     * Test case to change the product quantity by the text box
     ********************/

    @Test(priority = 5)
    public void changeProductQuantityTest() {
        WebElement quantityField = prdctpg.clickQuantity();
        DriverUtils.waitTillElementToBeVisible(quantityField, Duration.ofSeconds(30));
        quantityField.clear();

        String qty = "2";
        prdctpg.clickAndSendQunatity(qty);
        Assert.assertNotEquals(prdctpg.prodQuantity, 1, "Product quantity is not as expected");
    }

    /***************
     * Test cases to change the product quantity by the buttons
     ********************/

    @Test(priority = 6)
    public void changeProductQuantityByMinusTest() {
        prdctpg.clickDecreaseQuantity();
        Assert.assertNotEquals(prdctpg.prodQuantity, 2, "Product quantity is not as expected");
    }

    @Test(priority = 7)
    public void changeProductQuantityByPlusTest() {
        prdctpg.clickIncreaseQuantity();
        Assert.assertNotEquals(prdctpg.prodQuantity, 1, "Product quantity is not as expected");
    }

    /***************** Test case to validate a pincode. ******************/

    @Test(priority = 8)
    public void pincodeValidationTest() {
        JavascriptExecutor js = (JavascriptExecutor) DriverUtils.driver;
        js.executeScript("window.scrollBy(0,250)", "");

        String pinno = "123456";
        prdctpg.clickPin(pinno);
        prdctpg.clickCheckPin();
        String invalid = prdctpg.invalidMsg();
        String expectedMessage = "Shipping is not available.";
        Assert.assertTrue(invalid.equalsIgnoreCase(expectedMessage), "Invalid message does not match expected message");
    }

    /*****************
     * Test case to validate a pincode by Excel Sheet
     ******************/

    @Test(dataProvider = "testData", priority = 9)
    public void pincodeByExcelTest(String pincode) throws InterruptedException {
        prdctpg.pin.clear();
        prdctpg.clickPin(pincode);

        prdctpg.clickCheckPin();
        String invalid = prdctpg.invalidMsg();

        if (pincode.equals("12345")) {
            Assert.assertTrue(invalid.equalsIgnoreCase("Invalid pincode"),
                    "Invalid message does not match expected message");
        } else if (pincode.equals("123456")) {
            Assert.assertTrue(invalid.equalsIgnoreCase("Shipping is not available."),
                    "Invalid message does not match expected message");
        } else {
            Assert.assertTrue(invalid.equalsIgnoreCase("Shipping Available!"),
                    "Invalid message does not match expected message");
        }
    }

    /**********************
     * Test case to add a product to the cart.
     ********************/

    @Test(priority = 10)
    public void addToCartTest() {
        JavascriptExecutor js = (JavascriptExecutor) DriverUtils.driver;
        js.executeScript("arguments[0].click();", prdctpg.clickCart);
        prdctpg.clickViewCarts();
        DriverUtils.waitForElementToBeVisible(prdctpg.viewCartSidebar, Duration.ofSeconds(15));

        boolean titlebar = DriverUtils.waitTillElementToBeVisible(prdctpg.viewCartSidebar, Duration.ofSeconds(15));
        Assert.assertTrue(titlebar, "View cart is not displayed");
    }

    /************************
     * Test case to view and remove items from the cart.
     ************************/

    @Test(priority = 11)
    public void viewCartTest() {
        crtpg.clickViewCartsButton();
        crtpg.clickRemoveFromCartsButton();
        DriverUtils.waitForElementToBeVisible(crtpg.checkaftrrmvItem, Duration.ofSeconds(15));

        boolean check = DriverUtils.waitTillElementToBeVisible(crtpg.checkaftrrmvItem, Duration.ofSeconds(15));
        Assert.assertTrue(check, "Empty cart is not displayed");
    }

}
