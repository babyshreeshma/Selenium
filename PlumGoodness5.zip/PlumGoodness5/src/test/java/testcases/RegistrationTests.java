package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.HomePage;
import pages.MyCartPage;
import pages.NewProductPage;
import pages.ProductsPage;
import pages.RegistrationPage;
import pages.SelectedProductPage;
import pages.WishlistPage;

public class RegistrationTests extends BaseTest {
	private RegistrationPage register;
	private HomePage home;
	
	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		register = new RegistrationPage(driver);
	}


	@Test(priority = 0)
	public void user() {
		home = goToHomePage();
		home.clickDirectAccount();
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account/login?return_url=%2Faccount";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Account");
		// Test data
		String firstname = "Anagha";
		String lastname = "Reghu";
		String email = "anagha@gmail.com";
		String mobile = "8096754832";
		String dob = "09142001";
		String password = "anagha@2001";
		String confirmpassword = "anagha@2001";

		// Fill the register page
		register.customerFname(firstname);
		register.customerLname(lastname);
		register.cemail(email);
		register.cmobile(mobile);
		register.cbirthdate(dob);
		register.cpassword(password);
		register.confirmpassword(confirmpassword);

		String retrievedFirstName = register.firstname.getAttribute("value");
		String retrievedLastName = register.lastname.getAttribute("value");
		String retrievedEmail = register.email.getAttribute("value");
		String retrievedPhone = register.mobile.getAttribute("value");
		String retrievedPassword = register.password.getAttribute("value");
		String retrievedConfirmedPassword = register.confirmpassword.getAttribute("value");

		// Verify that retrieved values match the entered values
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat(retrievedFirstName).isEqualTo(firstname);
		softAssertions.assertThat(retrievedLastName).isEqualTo(lastname);
		softAssertions.assertThat(retrievedEmail).isEqualTo(email);
		softAssertions.assertThat(retrievedPhone).isEqualTo(mobile);
		softAssertions.assertThat(retrievedPassword).isEqualTo(password);
		softAssertions.assertThat(retrievedConfirmedPassword).isEqualTo(confirmpassword);
		softAssertions.assertAll();
		
		register.clicksignup();
		// Verify that the correct URL is reached after clicking.
		String current_Url = driver.getCurrentUrl();
		String expected_Url = "https://plumgoodness.com/account/register";
		Assert.assertEquals(current_Url, expected_Url, "Expected URL is same as Actual URL");
	}


	@Test(priority = 1)
	public void userInvalidSignIn() {
		register.clickChooseAccount();
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account/login?return_url=%2Faccount";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Account");

		// Fill the register page
		register.customerFname("Anagha");
		register.customerLname("Reghu");
		register.cemail("anagha@gmail.com");
		register.cmobile("809675");

		register.clicksignup();
		// Verify that the "Invalid Phone Number Error Message" is displayed.
		WebElement Element = register.InvalidPhoneNoMsg;
		Assert.assertTrue(Element.isDisplayed(), "Invalid Phone Number Error Message is displayed");
	}

}
