package testcases;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.HomePage;
import pages.LoginPage;
import pages.SelectedNewProduct;
import pages.ProductsPage;
@Listeners(utilities.SampleListener.class)
public class ProductReviewTests extends BaseTest {
	private HomePage home;
	private LoginPage login;
	private ProductsPage products;
	private SelectedNewProduct selectedProduct;

	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		login = new LoginPage(driver);
		products = new ProductsPage(driver);
		selectedProduct = new SelectedNewProduct(driver);
	}

	@Test(priority = 0)
	public void testclickMenuButton() {
		// Navigate to the home page and click the menu button.
		home = goToHomePage();
		home.clickDirectHome();
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account/login?return_url=%2Faccount";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Account");

	}

	@Test(priority = 1)
	public void UserLogin() {
		login.clickSignInLink("annapaul0712@gmail.com", "anna123");
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Login button");
	}

	@Test(priority = 2)
	public void testClickSkinCare() {
		login.clickSkinCareBtn();
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/skincare";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking SkinCare button");
	}

	@Test(priority = 3)
	public void testclickRecommendedButton() throws InterruptedException {
		// Click the "Recommended" button on the products page.
		products.clickRecommendedButton();
		products.clickHighToLowButton();
		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/skincare?sort=price-descending";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking High To Low button");
	}

	@Test(priority = 4)
	public void testclickReviewButton() throws InterruptedException {
		products.clickSelectProduct();

	}

	@Test(priority = 5)
	public void testclickSelectProduct() throws InterruptedException {
		selectedProduct.clickWriteReview();
		// Verify that the "review title" button is displayed.
		Boolean Element = DriverUtils.waitTillElementToBeVisible(selectedProduct.reviewTitle, Duration.ofSeconds(30));
		// Assert that the option is displayed.
		Assert.assertTrue(Element, "Review Title Option is displayed");

	}

	@Test(priority = 6)
	public void testReview() {

		// Fill in other review details (name, email, review title, description)
		selectedProduct.clickSendText("Anna Paul", "annapaul@gmail.com", "Great Product", "This product is amazing!");
		// Submit the review
		selectedProduct.clickSubmitButton();
		// Verify that the "view review" button is displayed.
		Boolean Element = DriverUtils.waitTillElementToBeVisible(selectedProduct.viewReview, Duration.ofSeconds(20));
		// Assert that the option is displayed.
		Assert.assertTrue(Element, "View Review Option is displayed");

	}

}
