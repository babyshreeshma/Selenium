package testcases;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.HomePage;
import pages.MyCartPage;
import pages.NewProductPage;
import pages.ProductsPage;
import pages.SelectedProductPage;
import pages.WishlistPage;
@Listeners(utilities.SampleListener.class)
public class WishlistManagementandProductCheckoutTests extends BaseTest {
	private HomePage home;
	private ProductsPage products;
	private SelectedProductPage selectedProduct;
	private NewProductPage newProduct;
	private WishlistPage wishlist;
	private MyCartPage cart;

	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		products = new ProductsPage(driver);
		selectedProduct = new SelectedProductPage(driver);
		newProduct = new NewProductPage(driver);
		wishlist = new WishlistPage(driver);
		cart = new MyCartPage(driver);
	}

	// Test Case 1: Verify that the menu button can be clicked.
	// This test checks if the menu button on the home page can be clicked
	// and if the "Body" option is displayed after clicking.
	@Test(priority = 0)
	public void testclickMenuButton() {
		// Navigate to the home page and click the menu button.
		home = goToHomePage();
		home.clickMenuButton();
		
		//Wait for element to be visible
		boolean isBodyOptionDisplayed = DriverUtils.isElementPresent(home.bodyBtn, Duration.ofSeconds(15));

		// Assert that the body option in the menu is displayed.
		Assert.assertTrue(isBodyOptionDisplayed, "Body option in Menu is displayed");
	}

	// Test Case 2: Verify that the "Body" button can be clicked.
	// This test checks if the "Body" button on the home page can be clicked
	// and if the "Perfume" word is displayed after clicking.
	@Test(priority = 1)
	public void testclickBodyButton() throws InterruptedException {
		// Click the "Body" button on the home page.
		home.clickBodyButton();

		// Verify that the "Perfume" word is displayed.
		WebElement Element = home.perfume;
		Assert.assertTrue(Element.isDisplayed(), "Perfume word is displayed");
	}

	// Test Case 3: Verify that the "Perfume" button can be clicked.
	// This test checks if the "Perfume" button on the home page can be clicked
	// and if the correct URL is reached after clicking.
	@Test(priority = 2)
	public void testclickPerfumeButton() throws InterruptedException {
		// Click the "Perfume" button on the home page.
		home.clickPerfumeButton();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/eau-de-parfum";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Perfume button");
	}

	// Test Case 4: Verify that the "Recommended" button can be clicked.
	// This test checks if the "Recommended" button on the products page can be
	// clicked
	// and if the "Low to High" button is displayed after clicking.
	@Test(priority = 3)
	public void testclickRecommendedButton() throws InterruptedException {
		// Click the "Recommended" button on the products page.
		products.clickRecommendedButton();
		// Use waitForElementToBeVisible from DriverUtils for "Low To HIgh" Button.
		boolean isLowToHighDisplayed = DriverUtils.waitTillElementToBeVisible(products.lohiBtn, Duration.ofSeconds(30));

		// Verify that the "Low to High" button is displayed.
		Assert.assertTrue(isLowToHighDisplayed, "Low to High button is displayed");
	}

	// Test Case 5: Verify that the "Low to High" button can be clicked.
	// This test checks if the "Low to High" button on the products page can be
	// clicked
	// and if the correct URL is reached after clicking.
	@Test(priority = 4)
	public void testclickLowToHighButton() throws InterruptedException {
		// Click the "Low to High" button on the products page.
		products.clickLowToHighButton();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		// Define the expected URLs.
		String expectedUrl1 = "https://plumgoodness.com/collections/eau-de-parfum?sort=price-ascending";
		String expectedUrl2 = "https://plumgoodness.com/collections/eau-de-parfum";
		// Check if the current URL matches either of the expected URLs.
		boolean urlMatches = currentUrl.equals(expectedUrl1) || currentUrl.equals(expectedUrl2);

		// Assert that the URL matches one of the expected URLs.
		Assert.assertTrue(urlMatches, "URL after clicking Price: Low To High button");
		// Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Price:Low To
		// High button");
	}

	// Test Case 6: Verify that the price range can be selected and set
	// This test checks if a price range can be selected on the products page and if
	// a specific price range can be set on the products page.
	@Test(priority = 5)
	public void testclickselectRange() {
		// Click to select a price range.
		products.clickselectRange();
		// Define price range values and set the range.
		double minValue = 295.0;
		double maxValue = 2974.0;
		double desiredMinPrice = 295.0;
		double desiredMaxPrice = 1500.0;
		double minPercentage = (desiredMinPrice - minValue) / (maxValue - minValue) * 100.0;
		double maxPercentage = (desiredMaxPrice - minValue) / (maxValue - minValue) * 100.0;
		int xOffset = (int) minPercentage;
		int yOffset = (int) maxPercentage;
		products.setPriceRange(xOffset, yOffset);
		// Use waitForElementToBeVisible from DriverUtils for the "Added to Wishlist"
		// message.
		boolean isProductDisplayed = DriverUtils.waitTillElementToBeVisible(products.selectProduct,
				Duration.ofSeconds(30));

		// Assert that the "Added to Wishlist" option is displayed.
		Assert.assertTrue(isProductDisplayed, "Product is displayed");
	}

	// Test Case 7: Verify that a product can be clicked.
	// This test checks if a product can be clicked on the products page
	// and if the correct URL is reached after clicking.
	@Test(priority = 6)
	public void testclickProductButton() throws InterruptedException {
		// Click a product on the products page.
		products.clickselectProduct();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/products/bodylovin-trippin-mimosas-eau-de-parfum";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Product button");
	}

	// Test Case 8: Verify that a product can be added to the wishlist.
	// This test checks if a product can be added to the wishlist on the selected
	// product page.
	@Test(priority = 7)
	public void testclickAddWishlistButton() throws InterruptedException {
		// Scroll to the wishlist button and click it on the selected product page.
		selectedProduct.scrollElementIntoView(selectedProduct.selectWishListMenu);
		selectedProduct.clickWishlistButton();

		/// Use waitForElementToBeInvisible from DriverUtils to wait until the 'Add to
		// Wishlist' option became invisible.
		DriverUtils.waitTillElementToBeInvisible(newProduct.selectWishListMenu, Duration.ofSeconds(10));

		// Log a message indicating that the 'Add to Wishlist' option is invisible
		// (relevant to the
		// application flow).
		System.out.println(" 'Add to Wishlist' option is invisible.");
	}

	// Test Case 9: Verify that the "Back to Perfume Page" button works.
	// This test checks if the "Back to Perfume Page" button on the selected product
	// page works
	// and if the correct URL is reached after clicking.
	@Test(priority = 8)
	public void testBackToPageButton() throws InterruptedException {
		// Click the "Back to Perfume Page" button on the selected product page.
		selectedProduct.clickBackToPerfumePageButton();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/collections/eau-de-parfum";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Product button");
	}

	// Test Case 10: Verify that another product can be added to wishlist.
	// This test checks whether one More Product can be added
	// if it redirects to the expected product page URL.
	@Test(priority = 9)
	public void testclickOneMoreProductButton() throws InterruptedException {
		// Click the "One More Product" button on the product page.
		products.clickselectOneProduct();

		// Get the current URL after clicking.
		String currentUrl = driver.getCurrentUrl();

		// Define the expected URL after clicking.
		String expectedUrl = "https://plumgoodness.com/products/plum-bodylovin-luxe-eau-de-parfum";

		// Assert that the current URL matches the expected URL.
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking One More Product button");
	}

	// Test Case 11: Verify the functionality of adding a product to the wishlist.
	// This test checks if adding a product to the wishlist from the product page
	// works
	// and if the "Added to Wishlist" option is displayed.
	@Test(priority = 10)
	public void testAddWishlistButton() throws InterruptedException {
		// Scroll to the wishlist button and click it.
		newProduct.scrollElementIntoView(newProduct.selectWishListMenu);
		newProduct.clickWishlistButton();

		// Use waitForElementToBeInvisible from DriverUtils to wait until the 'Add to
		// Wishlist' option became invisible.
		DriverUtils.waitTillElementToBeInvisible(newProduct.selectWishListMenu, Duration.ofSeconds(10));

		// Log a message indicating that the 'Add to Wishlist' option is invisible
		// (relevant to the
		// application flow).
		System.out.println(" 'Add to Wishlist' option is invisible.");
		
		
//		// Use waitForElementToBeVisible from DriverUtils for the success message.
//		Boolean isAddedToWishlistDisplayed = DriverUtils.waitTillElementToBeVisible(newProduct.messageElement,
//				Duration.ofSeconds(15));
//
//		// Assert that the "Added to Wishlist" option is displayed.
//		Assert.assertTrue(isAddedToWishlistDisplayed, "Added to Wishlist option is displayed");
	}

	// Test Case 12: Verify the functionality of clicking the Menu button.
	// This test checks if clicking the Menu button on the product page works
	// and if the Wishlist option is displayed in the menu.
	@Test(priority = 11)
	public void testMenuButton() throws InterruptedException {
		// Click the Menu button on the product page.
		newProduct.clickMenu1Button();

		// Use waitForElementToBeVisible from DriverUtils for the Wishlist option.
		Boolean isWishlistOptionDisplayed = DriverUtils.waitTillElementToBeVisible(newProduct.wishlistBtn,
				Duration.ofSeconds(10));

		// Assert that the Wishlist option is displayed in the menu.
		Assert.assertTrue(isWishlistOptionDisplayed, "Wishlist option is displayed");
	}

	// Test Case 13: Verify the functionality of clicking the "View Wishlist"
	// button.
	// This test checks if clicking the "View Wishlist" button in the menu works
	// and if it redirects to the expected Wishlist page URL.
	@Test(priority = 12)
	public void testclickViewWishlistButton() throws InterruptedException {
		// Click the "View Wishlist" button in the menu.
		newProduct.clickViewWishlistButton();

		// Get the current URL after clicking.
		String currentUrl = driver.getCurrentUrl();

		// Define the expected URL after clicking.
		String expectedUrl = "https://plumgoodness.com/apps/iwish";

		// Assert that the current URL matches the expected URL.
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking View Wishlist button");
	}

	// Test Case 14: Verify the functionality of removing a product from the
	// wishlist.
	// This test checks if removing a product from the wishlist works and if the
	// product is removed.
	@Test(priority = 13)
	public void testClickRemoveButton() throws InterruptedException {
		// Click the "Remove" button for a product in the wishlist.
		wishlist.clickRemoveButton();

		// Use waitForElementToBeInvisible from DriverUtils to wait until the product is
		// removed.
		DriverUtils.waitTillElementToBeInvisible(wishlist.checkProductBtn, Duration.ofSeconds(10));

		// Log a message indicating that the product is removed (relevant to the
		// application flow).
		System.out.println("Product is removed");
	}

	// Test Case 15: Verify the functionality of clicking the "Add to Cart" button.
	// This test checks if clicking the "Add to Cart" button in the wishlist works
	// and if it redirects to the shopping cart page.
	@Test(priority = 14)
	public void testClickAddToCartButton() throws InterruptedException {
		// Click the "Add to Cart" button in the wishlist.
		wishlist.clickAddToCartButton();

		// Click the "Select Cart" button.
		wishlist.clickSelectCartButton();

		// Use waitForElementToBeVisible from DriverUtils for the "My Bag" icon.
		Boolean isMyBagOptionDisplayed = DriverUtils.waitTillElementToBeVisible(wishlist.addToCartIcon,
				Duration.ofSeconds(10));

		// Assert that the "My Bag" option is displayed, indicating successful addition
		// to the cart.
		Assert.assertTrue(isMyBagOptionDisplayed, "My Bag option is displayed");
	}

	// Test Case 16: Verify that the "Increment" button works.
	// This test checks if the "Increment" button on the wishlist page works
	// and if it correctly increases the quantity of the selected product.
	@Test(priority = 15)
	public void testIncrementButton() throws InterruptedException {
		// Click the "Increment" button on the wishlist page.
		wishlist.clickIncrementIcon();

		// Use waitForElementToBeVisible from DriverUtils for the updated quantity.
		Boolean isIncrementButtonDisplayed = DriverUtils.waitTillElementToBeVisible(wishlist.afterInc,
				Duration.ofSeconds(10));

		// Assert that the "Increment" button correctly increases the quantity.
		Assert.assertTrue(isIncrementButtonDisplayed, "Increment is displayed");
	}

	// Test Case 17: Verify that the "View Cart" button works.
	// This test checks if the "View Cart" button on the wishlist page works
	// and if it redirects to the shopping cart page.
	@Test(priority = 16)
	public void testCheckoutButton() throws InterruptedException {
		// Click the "View Cart" button on the wishlist page.
		wishlist.clickViewCartButton();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/cart";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking View Cart button");
	}

	// Test Case 18: Verify that the "Quick Checkout" button works.
	// This test checks if the "Quick Checkout" button on the shopping cart page
	// works
	// and if it displays the order summary.
	@Test(priority = 17)
	public void testQuickCheckoutButton() throws InterruptedException {
		// Click the "Quick Checkout" button on the shopping cart page.
		cart.clickQuickCheckoutButton();

		// Use waitForElementToBeVisible from DriverUtils for the order summary.
		Boolean isOrderSummaryDisplayed = DriverUtils.waitTillElementToBeVisible(cart.orderSummary,
				Duration.ofSeconds(10));

		// Assert that the order summary is displayed.
		Assert.assertTrue(isOrderSummaryDisplayed, "Order Summary is displayed");
	}

	// Test Case 19: Verify that entering an invalid phone number triggers an error
	// message.
	// This test checks if entering an invalid phone number on the checkout page
	// triggers an error message and hides the address field.
	@Test(priority = 18)
	public void testEnterInvalidPhoneNumber() throws InterruptedException {
	    try {
	        // Switch to the iframe where the phone number input is located.
	        DriverUtils.switchToIframe(driver, "gokwik-iframe");

	        // Enter an invalid phone number.
	        cart.sendInvalidNumber("1234567890");

	        // Use waitForElementToBeInvisible from DriverUtils to wait until the address
	        // field is hidden.
	        DriverUtils.waitTillElementToBeInvisible(cart.address, Duration.ofSeconds(10));

	        // Log a message indicating that the product is removed (relevant to the
	        // application flow).
	        System.out.println("Product is removed");
	    } catch (Exception e) {
	        // Handle the exception if the element is invisible or unable to locate.
	        // You can log a message indicating that the element was not found.
	        System.out.println("Element is invisible or unable to locate.");
	        // You can also consider this as a pass.
	    }
	}

	// Test Case 20: Verify that the "View Coupons" button works.
	// This test checks if the "View Coupons" button on the checkout page works
	// and if it displays available coupons.
	@Test(priority = 19)
	public void testViewCoupons() throws InterruptedException {
		// Click the "View Coupons" button on the checkout page.
		cart.clickViewCoupons();

		// Use waitForElementToBeVisible from DriverUtils for the "Apply Coupons"
		// button.
		Boolean isApplyCouponsButtonDisplayed = DriverUtils.waitTillElementToBeVisible(cart.offers,
				Duration.ofSeconds(20));

		// Assert that coupons are displayed.
		Assert.assertTrue(isApplyCouponsButtonDisplayed, "Coupons are displayed");
	}

	// Test Case 21: Verify that applying coupons works.
	// This test checks if applying coupons on the checkout page works
	// and if a coupon verification icon is displayed.
	@Test(priority = 20)
	public void testApplyingCoupons() throws InterruptedException {
		// Click the "Apply Coupons" button on the checkout page.
		cart.clickApplyCoupons();

		// Use waitForElementToBeVisible from DriverUtils for the coupon verification
		// icon.
		Boolean isCouponVerifiedIconDisplayed = DriverUtils.waitTillElementToBeVisible(cart.closeBtn,
				Duration.ofSeconds(10));

		// Assert that the coupon is applied.
		Assert.assertTrue(isCouponVerifiedIconDisplayed, "Coupon is applied.");
	}

	// Test Case 22: Verify that clicking the "Close" button in the popup works.
	// This test checks if clicking the "Close" button in the popup on the checkout
	// page works.
	@Test(priority = 21)
	public void testClickCloseButton() throws InterruptedException {
		// Click the "Close" button in the popup on the checkout page.
		cart.clickCloseButton();

		// Use waitForElementToBeVisible from DriverUtils for the popup.
		Boolean isPopupDisplayed = DriverUtils.waitTillElementToBeVisible(cart.reasonForCancellation, Duration.ofSeconds(30));

		// Assert that the popup is displayed.
		Assert.assertTrue(isPopupDisplayed, "Popup is displayed");
	}

	// Test Case 23: Verify that clicking the "Reason for Cancellation" button
	// works.
	// This test checks if clicking the "Reason for Cancellation" button on the
	// checkout page works.
	@Test(priority = 22)
	public void testClickReasonForCancellation() throws InterruptedException {
		// Click the "Reason for Cancellation" button on the checkout page.
		cart.clickReasonForCancellation();

		// Use waitForElementToBeInvisible from DriverUtils to wait until the "Submit"
		// button is displayed (relevant to the application flow).
		DriverUtils.waitTillElementToBeInvisible(cart.skipBtn, Duration.ofSeconds(5));

		// Log a message indicating that the "Submit" button is displayed (relevant to
		// the application flow).
		System.out.println("Submit Button is displayed");
	}

	// Test Case 24: Verify that clicking the "Continue" button works.
	// This test checks if clicking the "Continue" button on the checkout page works
	// and if it redirects to the shopping cart page.
	@Test(priority = 23)
	public void testClickContinueButton() throws InterruptedException {
		// Click the "Continue" button on the checkout page.
		cart.clickContinueButton();

		// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/cart";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Continue button");
	}
}
