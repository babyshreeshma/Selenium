package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import base.DriverUtils;
import pages.CartPage;
import pages.LoginAndRegistrationPage;
import pages.ProductPage;
import pages.SearchPage;
import utilities.ExcelUtils;

public class LoginTests extends DriverUtils {

	WebDriver driver;
	LoginAndRegistrationPage register;

	@BeforeMethod
	public void setup() {
		driver = invokeBrowser();
		openBrowser("applicationURL");
		DriverUtils.driver = driver;
	}

	@Test
	@DataProvider(name = "testDatalogin")
	public Object[][] testDataLogin() {
		return ExcelUtils.testdatalogin();

	}

	@Test(priority = 0, dataProvider = "testDatalogin")
	public void loginTest(String username, String password) {
	    LoginAndRegistrationPage login = new LoginAndRegistrationPage(driver);

	    login.clickChooseAccount();
	    login.customerEmail(username);
	    login.customerPassword(password);
	    login.clicksignin();

	    String exp = login.LogErrormsg();
	    System.out.println(exp);

	    if (username.equals("anaghareghu149@gmail.com") && password.equals("anagha@2001")) {
			WebElement Element = register.message;
			Assert.assertTrue(Element.isDisplayed(), "Message is displayed");
	    } else if (username.equals("incorrectemail@gmail.com") && password.equals("anagha@2001")) {
	        Assert.assertEquals(exp, "Incorrect email or password.");
	    } else if (username.equals("anaghareghu149@gmail.com") && password.equals("incorrectPassword")) {
	        Assert.assertEquals(exp, "Incorrect email or password.");
	    } else if (username == null || password == null) {
	        Assert.assertEquals(exp, "Incorrect email or password.");
	    }
	}
	
	@AfterMethod
	public void tearDown() {
		// Close the browser after each test method
		driver.quit();
	}
}
