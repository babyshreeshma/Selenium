package testcases;

import java.time.Duration;
import org.assertj.core.api.SoftAssertions;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import base.BaseTest;
import base.DriverUtils;
import pages.HomePage;
import pages.LoginPage;
import pages.UpdateAccountPage;
@Listeners(utilities.SampleListener.class)
public class UserManagementTests extends BaseTest {
	private HomePage home;
	private LoginPage login;
	private UpdateAccountPage upacc;

	@BeforeClass
	public void setUpPages() {
		// Initialize page objects for each page.
		home = new HomePage(driver);
		login = new LoginPage(driver);
		upacc = new UpdateAccountPage(driver);

	}

	@Test(priority = 0)
	public void User() {
		home = goToHomePage();
		home.clickDirectHome();
// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account/login?return_url=%2Faccount";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Account");
	}

	@Test(priority = 1)
	public void UserLogin() {
		login.clickSignInlink("akshaibiju@gmail.com", "akshai123");
// Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/account";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after clicking Login button");
	}

	@Test(priority = 2)
	public void AddFirstAddress() {
		upacc.clicknewAddr();
		upacc.clicknewfname("Akshai");
		upacc.clicknewlname("Biju");
		upacc.clicknewcompany("UST Global");
		upacc.clicknewAddr1("Kulathoor UST main campus");
		upacc.clicknewAddr2("Trivandrum");
		upacc.clicknewCity("Kulathoor");
		upacc.clicknewCountry();
		upacc.clicknewProvince();
		upacc.clicknewPostCode("685412");
		upacc.clicknewPhone("6754129876");
		upacc.clicknewupdBtn();
// Test data
		String firstName = "Akshai";
// // Fill in the first name
// upacc.clicknewfname(firstName);
// Verify First Name
		String actualFirstName = upacc.checkactualFName();
		System.out.println("Actual First Name: " + actualFirstName);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat((actualFirstName).equals(firstName));
		softAssertions.assertAll();
	}

	@Test(priority = 3)
	public void DefaultAddressCheck() {
		upacc.clickEditAddr();
		upacc.clickedfname("Sreyas");
		upacc.clickedlname("S Sharma");
		upacc.clickedcompany("UST Global");
		upacc.clickedAddr1("UST main campus");
		upacc.clickedAddr2("TVM");
		upacc.clickedCity("Kulathoor");
		upacc.clickedCountry();
		upacc.clickedProvince();
		upacc.clickedPostCode("6855");
		upacc.clickedPhone("8754340000");
		upacc.clickeddefaultcheck();
		upacc.clickedcnclBtn();
/// Use waitForElementToBeInvisible from DriverUtils to wait until the 'Add to
// Wishlist' option became invisible.
		DriverUtils.waitTillElementToBeInvisible(upacc.EditVisible, Duration.ofSeconds(10));
// Log a message indicating that the 'Add to Wishlist' option is invisible
// (relevant to the
// application flow).
		System.out.println(" 'Edit Form Is Invisible");
	}

	@Test(priority = 4)
	public void DefaultAddressEdit() {
		upacc.clickEditAddr();
		upacc.clickedfname("Sreyas");
		upacc.clickedlname("Sharma");
		upacc.clickedcompany("UST Global");
		upacc.clickedAddr1("Kulathoor UST main campus");
		upacc.clickedAddr2("Trivandrum");
		upacc.clickedCity("Kulathoor");
		upacc.clickedCountry();
		upacc.clickedProvince();
		upacc.clickedPostCode("685533");
		upacc.clickedPhone("8754342312");
		upacc.clickedupdBtn();
// Test data
		String company = "UST Global";
// // Fill in the first name
// upacc.clicknewfname(company);
// Verify First Name
		String edactualFirstName = upacc.checkedactualFName();
		System.out.println("Actual First Name: " + edactualFirstName);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat((edactualFirstName).equals(company));
		softAssertions.assertAll();
	}

	@Test(priority = 5)
	public void AddNewAddressCheck() {
		upacc.clicknewAddr();
		upacc.clicknewfname("Nithil");
		upacc.clicknewlname("Abraham");
		upacc.clicknewcompany("UST Global");
		upacc.clicknewAddr1("Kochi Technopark");
		upacc.clicknewAddr2("Kottayam");
		upacc.clicknewCity("Kakkanad");
		upacc.clicknewCountry();
		upacc.clicknewProvince();
		upacc.clicknewPostCode("68554");
		upacc.clicknewPhone("7898452109");
		upacc.clicknewdefaultcheck();
		upacc.clicknewcnclBtn();
/// Use waitForElementToBeInvisible from DriverUtils to wait until the 'Add to
// Wishlist' option became invisible.
		DriverUtils.waitTillElementToBeInvisible(upacc.EditVisible, Duration.ofSeconds(10));
// Log a message indicating that the 'Add to Wishlist' option is invisible
// (relevant to the
// application flow).
		System.out.println(" 'Edit Form Is Invisible");
	}

	@Test(priority = 6)
	public void AddNewAddress() {
		upacc.clicknewAddr();
		upacc.clicknewfname("Nithil");
		upacc.clicknewlname("Abraham");
		upacc.clicknewcompany("UST Global");
		upacc.clicknewAddr1("Kochi Infopark");
		upacc.clicknewAddr2("Kochi");
		upacc.clicknewCity("Kakkanad");
		upacc.clicknewCountry();
		upacc.clicknewProvince();
		upacc.clicknewPostCode("685545");
		upacc.clicknewPhone("7898453212");
		upacc.clicknewupdBtn();
// Test data
		String name = "Nithil";
// // Fill in the first name
// upacc.clicknewfname(name);
// Verify First Name
		String upactualFirstName = upacc.checkactualFName();
		System.out.println("Actual First Name: " + upactualFirstName);
		SoftAssertions softAssertions = new SoftAssertions();
		softAssertions.assertThat((upactualFirstName).equals(name));
		softAssertions.assertAll();
	}

	@Test(priority = 7)
	public void RemoveAddress() {
		upacc.clickRemBtn();
		DriverUtils.waitTillElementToBeInvisible(upacc.EditVisible, Duration.ofSeconds(10));
// Log a message indicating that the 'Add to Wishlist' option is invisible
// (relevant to the
// application flow).
		System.out.println(" 'Form Removed Succesfully");
	}

	@Test(priority = 8)
	public void SignOutAcc() {
		upacc.clickLogBtn();
        // Verify that the correct URL is reached after clicking.
		String currentUrl = driver.getCurrentUrl();
		String expectedUrl = "https://plumgoodness.com/";
		Assert.assertEquals(currentUrl, expectedUrl, "URL after Log Out");
	}
}