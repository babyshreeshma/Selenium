package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

import pages.CartPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductPage;
import pages.ProductsPage;
import pages.SearchPage;
import pages.SelectedNewProduct;
import pages.UpdateAccountPage;
import utilities.FileIO;

public class BaseTest {
	public WebDriver driver;
	public static String browserChoice;
	public static Properties prop;

	public BaseTest() {
		prop = FileIO.initProperties();
		// Print the loaded properties to verify
		System.out.println("Loaded properties: " + prop);
	}

	@BeforeTest
	public void setup() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("edge")) {
			driver = BrowserConfiguration.getBrowser();
			DriverUtils.driver = driver;
		}
	}

	public HomePage goToHomePage() {
		driver.get(prop.getProperty("applicationURL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women"));
		Assert.assertEquals(driver.getTitle(), "Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women");

		return PageFactory.initElements(driver, HomePage.class);
	}

	public LoginPage goToLoginPage() {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account"));
		Assert.assertEquals(driver.getTitle(), "Account");

		return PageFactory.initElements(driver, LoginPage.class);
	}

	public UpdateAccountPage goToAccountPage() {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account"));
		Assert.assertEquals(driver.getTitle(), "Account");

		return PageFactory.initElements(driver, UpdateAccountPage.class);
	}
	public ProductsPage goToProductsPage() {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Buy Best Vegan Skin Care Products Online | Plum Goodness"));
		Assert.assertEquals(driver.getTitle(), "Buy Best Vegan Skin Care Products Online | Plum Goodness");
		return PageFactory.initElements(driver, ProductsPage.class);
	}
	public SelectedNewProduct goToSelectedProductPage() {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Bright Years Age Specialist Full Set"));
		Assert.assertEquals(driver.getTitle(), "Bright Years Age Specialist Full Set");
		return PageFactory.initElements(driver, SelectedNewProduct.class);
	}
	public SearchPage goToSearchPage() {
		driver.get(prop.getProperty("applicationURL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women"));
		Assert.assertEquals(driver.getTitle(), "Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women");
		return PageFactory.initElements(driver, SearchPage.class);
	}
	
	public ProductPage goToProductPage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Phy Charcoal Face Wash | Deep Cleansing | SLS-Free | For Oily Or Combi"));
		Assert.assertEquals(driver.getTitle(), "Phy Charcoal Face Wash | Deep Cleansing | SLS-Free | For Oily Or Combi");
		return PageFactory.initElements(driver, ProductPage.class);
	}
	
	public CartPage goToCartPage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Your Shopping Cart"));
		Assert.assertEquals(driver.getTitle(), "Your Shopping Cart");
		return PageFactory.initElements(driver, CartPage.class);
	}

	public <T> T initPage(Class<T> pageClass) {
		return PageFactory.initElements(driver, pageClass);
	}

//	@AfterTest
//	public void tearDown() {
//		if (driver != null) {
//			driver.quit();
//		}
//	}
}
