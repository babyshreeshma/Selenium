package pages;


import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class SelectedProductPage extends DriverUtils {
    WebDriver driver;

    public SelectedProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Define your @FindBy annotations for elements.

    //@FindBy(xpath = "//div[@class='iwishAddWrap']//a[@class='iWishAdd']")
    //@FindBy(xpath="//div[@class='cart_wish gb']//div[@class='iwishAddWrap']/a[@class='iWishAdd']")
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[1]/div[2]/div[2]/div[2]/form/div[3]/div[1]/div[1]/a")
    public WebElement selectWishListMenu;

    // Add a new @FindBy annotation for the message element
   // @FindBy(xpath = "//div[@class='iwishAddWrap']//a[@class='iwishAdded']")
    //@FindBy(xpath="/html/body/div[3]/main/div/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[2]/form/div[3]/div[1]/div[1]/a")
    //public WebElement messageElement;
    @FindBy(xpath="//a[@class='bread'][@href='https://plumgoodness.com/collections/eau-de-parfum']/span")
    public WebElement backToPageElement;
    @FindBy(xpath="//div[@class='container']//div[@id='product-list']//ul[@class='product-items']//li[@class='product-item']//a[contains(@class, 'product-title')]")
    public WebElement addOneMoreProduct;
    

    // Methods to interact with the elements using clickOn.
    public void clickWishlistButton() {
        scrollElementIntoView(selectWishListMenu);
        clickOn(selectWishListMenu);
        
    }
    public void clickBackToPerfumePageButton() {
    	scrollElementIntoView(backToPageElement);
        jsClick(backToPageElement);
        
    }
    public ProductsPage clickOneMoreProductButton() {
        scrollElementIntoView(addOneMoreProduct);
        clickOn(addOneMoreProduct);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.titleIs("Plum BodyLovin' Vanilla Vibes Body Mist | Warm Vanilla Fragrance | Aloe-Infused"));
		return PageFactory.initElements(driver, ProductsPage.class);
    }

    
}

