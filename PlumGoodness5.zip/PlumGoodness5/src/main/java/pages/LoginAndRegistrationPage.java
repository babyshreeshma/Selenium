package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class LoginAndRegistrationPage extends DriverUtils {
	WebDriver driver;

	public LoginAndRegistrationPage(WebDriver driver) {
		this.driver = driver;
		// Call initElements() method by using PageFactory reference and pass driver and
		// this as parameters.
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='account_div']/a")
	// @FindBy(xpath="//*[@id=\"Capa_1\"]")
	public WebElement Chooseaccount;

	public void clickChooseAccount() {
		moveOver(Chooseaccount);
		jsClick(Chooseaccount);
	}

	/*************** Id of plum login ******************/
	@FindBy(xpath = "//a[@href='/account/']//*[name()='svg']")
	WebElement login;

	@FindBy(xpath = "//input[@id='customer_email']")
	WebElement customeremail;

	@FindBy(xpath = "//input[@id='customer_password']")
	WebElement customerpassword;

	@FindBy(xpath="/html/body/div[3]/main/div/div/div/div[1]/div[1]/form/p[2]/input")
	WebElement signin;

	/***************
	 * Id of create Account and direct to create Account
	 ******************/

	@FindBy(xpath = "//input[@id='first_name']")
	public WebElement firstname;

	@FindBy(xpath = "//input[@id='last_name']")
	public WebElement lastname;

	@FindBy(xpath = "//input[@id='email']")
	public WebElement email;

	@FindBy(xpath = "//input[@id='mobile_no']")
	public WebElement mobile;

	@FindBy(xpath = "//input[@id='birthday']")
	public WebElement birthdate;

	@FindBy(xpath = "//input[@id='password']")
	public WebElement password;

	@FindBy(xpath = "//input[@id='cpassword']")
	public WebElement confirmpassword;

	@FindBy(id = "//div[@class='action_bottom']//input[@id='notifyeventsignup']")
	WebElement signup;

	@FindBy(xpath = "//form[@id='customer_login']//li[contains(text(),'Incorrect email or password.')]")
	WebElement logError;

	@FindBy(xpath = "//input[@id='mobile_no'][@title='Please enter valid phone number']")
	public WebElement InvalidPhoneNoMsg;

	@FindBy(xpath="//h3[@class='account-saved']")
	public WebElement message;

	/*************** Methods to login ******************/

	public void clicklogin() {
		clickOn(login);
	}

	public void customerEmail(String email) {
		sendtext(customeremail, email);
	}

	public void customerPassword(String password) {
		sendtext(customerpassword, password);
	}

	public void clicksignin() {
		scrollElementIntoView(signin);
		jsClick(signin);
	}

	public String LogErrormsg() {
		return getText(logError);
	}

	/*************** Methods Register Account ******************/

	public void customerFname(String firstName) {
		sendtext(firstname, firstName);
	}

	public void customerLname(String lastName) {
		sendtext(lastname, lastName);
	}

	public void cemail(String cEmail) {
		sendtext(email, cEmail);
	}

	public void cmobile(String cMobile) {
		sendtext(mobile, cMobile);
	}

	public void cbirthdate(String cBirthdate) {
		sendtext(birthdate, cBirthdate);
	}

	public void cpassword(String cPassword) {
		sendtext(password, cPassword);
	}

	public void confirmpassword(String ccPassword) {
		sendtext(confirmpassword, ccPassword);
	}

	public void clicksignup() {
		scrollElementIntoView(signup);
		jsClick(signup);
	}

	public String actualURL() {
		return driver.getCurrentUrl();
	}

}
