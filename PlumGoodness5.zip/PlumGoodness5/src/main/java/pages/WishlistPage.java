package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import base.DriverUtils;

public class WishlistPage extends DriverUtils {
    WebDriver driver;

    public WishlistPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "add")
    public WebElement addToCartElement;

    @FindBy(xpath = "//a[@class='iwishRemoveBtn' and @data-handle='bodylovin-trippin-mimosas-eau-de-parfum' and @data-variant='39531246288956' and @data-product='6671155593276']")
    public WebElement removeElement;

    @FindBy(xpath = "//a[contains(@class, 'product-title') and contains(@href, '/products/bodylovin-trippin-mimosas-eau-de-parfum')]")
    public WebElement checkProductBtn;
    
    @FindBy(xpath = "(//div[@class=\"cart-icon svg-mb\"])")
    public WebElement selectCartbtn;

    @FindBy(id = "dropdown-cart")
    public WebElement addToCartIcon;
    
    @FindBy(xpath= "//div[@class='inc button']")
    public WebElement incrementIcon;
    
    @FindBy(xpath="//input[@class='quantity' and @name='quantity' and @value='2']")
    public WebElement afterInc;
    
    @FindBy(xpath="//a[contains(@class, 'btn-view-cart') and normalize-space()='View cart']")
    public WebElement viewCartBtn;
    
    @FindBy(xpath="//div[contains(@class, 'summary-inner')]")
    public WebElement checkout;


    public void clickRemoveButton() {
        scrollElementIntoView(removeElement);
        clickOn(removeElement);
    }

    public void clickSelectCartButton() {
    	moveOver(selectCartbtn);
        clickOn(selectCartbtn);
    }
    
    public void clickAddToCartButton() {
        scrollElementIntoView(addToCartElement);
        moveOver(addToCartElement);
        jsClick(addToCartElement);
    }
    
    public void clickIncrementIcon() {
        clickOn(incrementIcon);
    }
    
    public MyCartPage clickViewCartButton() {
    	moveOver(viewCartBtn);
        jsClick(viewCartBtn);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.titleIs("Your Shopping Cart"));
        return PageFactory.initElements(driver, MyCartPage.class);
    }
}
