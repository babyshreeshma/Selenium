package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class SelectedNewProduct extends DriverUtils {
    WebDriver driver;

    public SelectedNewProduct(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "judgeme_product_reviews")
    public WebElement reviewBtn;

    @FindBy(linkText = "Price: High to Low")
    public WebElement hiloBtn;

    @FindBy(xpath = "//h3[@class='title_h3']/a[@class='product-title']/span[@class='lang1']")
    public WebElement selectProduct;
    
    @FindBy(xpath="//a[@class='jdgm-write-rev-link' and text()='Write a review']")
    public WebElement selectWriteReview;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/div[1]/input")
    public WebElement name;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/div[2]/input")
    public WebElement email;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/div[4]/input")
    public WebElement reviewTitle;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/div[5]/textarea")
    public WebElement reviewDescription;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/div[7]/div/label/input")
    public WebElement uploadPhoto;
    
    @FindBy(xpath="/html/body/div[3]/main/div/div[1]/div/div/div/div/div[6]/div/div/div/div[2]/div/div[1]/div[6]/form/input")
    public WebElement submitButton;
    
    @FindBy(xpath="//*[@id=\"judgeme_product_reviews\"]/div/div[2]/div[1]")
    public WebElement viewReview;

    public void clickReviewButton() {
        clickOn(reviewBtn);
    }

    public void clickHighToLowButton() {
        clickOn(hiloBtn);
    }

    public void clickSelectProduct() {
        clickOn(selectProduct);
    }
    public void clickWriteReview() {
        int scrollPixels = 2300; // Adjust the number of pixels as needed
        scrollVertically(scrollPixels);
        clickOn(selectWriteReview);
    }
    public void clickSendText(String pname, String pemail, String previewTitle, String previewDescription) {
    	int scrollPixels = -1000; // Adjust the number of pixels as needed
        scrollVertically(scrollPixels);
        sendtext(name,pname);
    	sendtext(email,pemail);
    	sendtext(reviewTitle,previewTitle);
    	sendtext(reviewDescription,previewDescription);
    	
    	}
    public void clickSubmitButton() {
        clickOn(submitButton);
    }


}
