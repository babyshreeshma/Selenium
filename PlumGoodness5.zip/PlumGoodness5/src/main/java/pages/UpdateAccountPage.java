package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import base.BaseTest;
import base.DriverUtils;

public class UpdateAccountPage extends DriverUtils {
	WebDriver driver;

	public UpdateAccountPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/*************** Id of Login ******************/
	@FindBy(xpath = "//div[@class='account_div']/a")
	WebElement Chooseaccount;
	@FindBy(id = "customer_email")
	WebElement userIDField;
	@FindBy(id = "customer_password")
	WebElement passwordField;
	@FindBy(id = "notifyeventsignup")
	WebElement signinButton;
	/*************** Address Form Id Button ******************/
	@FindBy(xpath = "(//div[@class=\"btn\"]//a)[1]")
	WebElement editAddr;
	@FindBy(xpath = "(//div[@class=\"add-new-address\"]//a)[1]")
	WebElement newAddr;
	@FindBy(xpath = "(//div[@class=\"btn\"]//a)[4]")
	WebElement RemBtn;
	@FindBy(xpath = "//div[@class=\"logout_button\"]//a")
	WebElement LogBtn;
	/************* id of edit address **************/
	@FindBy(name = "address[first_name]")
	WebElement edfname;
	@FindBy(xpath = "(//div[@class=\"address_info_cols-cd\"]//p)[1]")
	WebElement edactualFName;
	@FindBy(name = "address[last_name]")
	WebElement edlname;
	@FindBy(name = "address[company]")
	WebElement edcompany;
	@FindBy(name = "address[address1]")
	WebElement edAddr1;
	@FindBy(name = "address[address2]")
	WebElement edAddr2;
	@FindBy(name = "address[city]")
	WebElement edCity;
	@FindBy(xpath = "(//div[@class=\"cols_half_inpt\"]//option)[9]")
	WebElement edCountry;
	@FindBy(xpath = "(//select[@name=\"address[province]\"]//option)[32]")
	WebElement edProvince;
	@FindBy(name = "address[zip]")
	WebElement edPostCode;
	@FindBy(name = "address[phone]")
	WebElement edPhone;
	@FindBy(xpath = "//div[@class=\"popup_to_address active\"]//label[@class=\"inline checkbox\"]//span")
	WebElement eddefaultcheck;
	@FindBy(xpath = "(//div[@class=\"btns\"]//a)[1]")
	WebElement edcnclBtn;
	@FindBy(xpath = "(//div[@class=\"btns\"]//input)[1]")
	WebElement edupdBtn;
	/*************** Add New Address Form Id ******************/
	@FindBy(id = "address_first_name_new")
	public WebElement newfname;
	@FindBy(xpath = "//div[@class=\"edit-added-address\"]//h4")
	WebElement actualFName;
	@FindBy(xpath = "//div[@class=\"popup_to_address active\"]//h3")
	public WebElement EditVisible;
	@FindBy(id = "address_last_name_new")
	WebElement newlname;
	@FindBy(id = "address_company_new")
	WebElement newcompany;
	@FindBy(id = "address_address1_new")
	WebElement newAddr1;
	@FindBy(id = "address_address2_new")
	WebElement newAddr2;
	@FindBy(id = "address_city_new")
	WebElement newCity;
	@FindBy(xpath = "//div[@class=\"cols_half_inpt\"]//select[@id=\"address_country_new\"]//option[9]")
	WebElement newCountry;
	@FindBy(xpath = "//div[@class=\"cols_half_inpt\"]//select[@id=\"address_province_new\"]//option[18]")
	WebElement newProvince;
	@FindBy(id = "address_zip_new")
	WebElement newPostCode;
	@FindBy(id = "address_phone_new")
	WebElement newPhone;
	@FindBy(xpath = "//div[@id=\"add_address\"]//label[@class=\"inline checkbox\"]//span")
	WebElement newdefaultcheck;
	@FindBy(xpath = "//div[@class=\"btns\"]//a[@class=\"btn yellow_btn\"]")
	WebElement newcnclBtn;
	@FindBy(xpath = "//div[@class=\"btns\"]//input[@class=\"btn yellow_btn submit\"]")
	WebElement newupdBtn;

	/*************** Method of Login ******************/
	public void clickChooseAccount() {
		clickOn(Chooseaccount);
	}

	public void login(String userEmail, String password) {
		sendtext(userIDField, userEmail);
		sendtext(passwordField, password);
		clickOn(signinButton);
	}

	/*************** Edit Address Button Method ******************/
	public void clickEditAddr() {
		clickOn(editAddr);
	}

	public void clicknewAddr() {
		clickOn(newAddr);
	}

	public void clickRemBtn() {
		clickOn(RemBtn);
		switchToAlertAccept();
	}

	public void clickLogBtn() {
		clickOn(LogBtn);
	}

	/*************** Edit Address Method ******************/
	public void clickedfname(String fname) {
		clear(edfname);
		sendtext(edfname, fname);
	}

	public String checkactualFName() {
		String s = getText(actualFName);
		return s;
	}

	public String checkedactualFName() {
		String s = getText(edactualFName);
		return s;
	}

	public void clickedlname(String lname) {
		clear(edlname);
		sendtext(edlname, lname);
	}

	public void clickedcompany(String comp) {
		clear(edcompany);
		sendtext(edcompany, comp);
	}

	public void clickedAddr1(String addr1) {
		clear(edAddr1);
		sendtext(edAddr1, addr1);
	}

	public void clickedAddr2(String addr2) {
		clear(edAddr2);
		sendtext(edAddr2, addr2);
	}

	public void clickedCity(String city) {
		clear(edCity);
		sendtext(edCity, city);
	}

	public void clickedCountry() {
		clickOn(edCountry);
	}

	public void clickedProvince() {
		clickOn(edProvince);
	}

	public void clickedPostCode(String pcode) {
		clear(edPostCode);
		sendtext(edPostCode, pcode);
	}

	public void clickedPhone(String phone) {
		clear(edPhone);
		sendtext(edPhone, phone);
	}

	public void clickeddefaultcheck() {
		clickOn(eddefaultcheck);
	}

	public void clickedcnclBtn() {
		clickOn(edcnclBtn);
	}

	public void clickedupdBtn() {
		clickOn(edupdBtn);
	}

	/*************** New Address Method ******************/
	public void clicknewfname(String nfname) {
		clear(newfname);
		sendtext(newfname, nfname);
	}

	public void clicknewlname(String nlname) {
		clear(newlname);
		sendtext(newlname, nlname);
	}

	public void clicknewcompany(String ncomp) {
		clear(newcompany);
		sendtext(newcompany, ncomp);
	}

	public void clicknewAddr1(String naddr1) {
		clear(newAddr1);
		sendtext(newAddr1, naddr1);
	}

	public void clicknewAddr2(String naddr2) {
		clear(newAddr2);
		sendtext(newAddr2, naddr2);
	}

	public void clicknewCity(String ncity) {
		clear(newCity);
		sendtext(newCity, ncity);
	}

	public void clicknewCountry() {
		clickOn(newCountry);
	}

	public void clicknewProvince() {
		clickOn(newProvince);
	}

	public void clicknewPostCode(String npcode) {
		clear(newPostCode);
		sendtext(newPostCode, npcode);
	}

	public void clicknewPhone(String nphone) {
		clear(newPhone);
		sendtext(newPhone, nphone);
	}

	public void clicknewdefaultcheck() {
		clickOn(newdefaultcheck);
	}

	public void clicknewcnclBtn() {
		clickOn(newcnclBtn);
	}

	public void clicknewupdBtn() {
		clickOn(newupdBtn);
	}
}
