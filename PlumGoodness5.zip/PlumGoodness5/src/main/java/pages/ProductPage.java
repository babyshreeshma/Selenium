package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import base.DriverUtils;

public class ProductPage extends DriverUtils {
	WebDriver driver;

	public ProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**************** Change the Product Quantity ***************/

	@FindBy(name = "quantity")
	public WebElement prodQuantity;
	@FindBy(xpath = "//div[@id=\"product-variants\"]//div[2]//div//a[1]")
	public WebElement minus;
	@FindBy(xpath = "//div[@id=\"product-variants\"]//div[2]//div//a[2]")
	public WebElement plus;

	/**************** Check the Pincode ***************/

	@FindBy(id = "pincode_input")
	public WebElement pin;
	@FindBy(id = "check-delivery-submit")
	public WebElement checkPin;
	@FindBy(xpath = "//form[@id=\"add-to-cart-form\"]/div[5]/div/ul/li[2]")
	public WebElement errormsg;

	/**************** Cart operations ***************/

	@FindBy(name = "add")
	public WebElement clickCart;

	@FindBy(xpath = "//div[contains(@class,\"header-mb-right\")]//div[contains(@class,\"cart-icon\")]")
	public WebElement viewCart;
	@FindBy(xpath = "//div[@class=\"cart-title\"]")
	public WebElement viewCartSidebar;

	/**************** Change the Product Quantity ***************/

	public WebElement clickQuantity() {
		clickOn(prodQuantity);
		return prodQuantity;

	}

	public void clickAndSendQunatity(String text) {
		sendtext(prodQuantity, text);
	}

	public void clickIncreaseQuantity() {
		clickOn(plus);
	}

	public void clickDecreaseQuantity() {
		clickOn(minus);
	}

	/**************** Check the Pincode ***************/

	public void clickPin(String pinnumber) {
		clickOn(pin);
		sendtext(pin, pinnumber);
	}

	public void clickCheckPin() {
		clickOn(checkPin);
	}

	public String invalidMsg() {
		return getText(errormsg);
	}

	/**************** Cart operations ***************/

	public void clickAddToCarts() {
		clickOn(clickCart);

	}

	public CartPage clickViewCarts() {
		clickOn(viewCart);
		return PageFactory.initElements(driver, CartPage.class);

	}
}