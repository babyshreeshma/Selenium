package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.DriverUtils;

public class MyCartPage extends DriverUtils {
    WebDriver driver;

    public MyCartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//a[@type='button' and @id='gokwik-btn' and @onclick='onCheckoutClick(this)' and @data-smartech-checkout='true']")
    public WebElement quickCheckout;
    @FindBy(xpath="/html/body/div/div[1]")
    public WebElement orderSummary;
    @FindBy(xpath="//input[@type='tel' and @placeholder='Enter Number' and @class='phone-input svelte-1kgxc0r' and @id='phone-input' and @pattern='[0-9]{5}-[0-9]{5}' and @autocomplete='tel']")
    public WebElement phoneNo;
    @FindBy(xpath="//div[@class='address-title svelte-ejaoyg']")
    public WebElement address;
//    @FindBy(xpath="//div[@class='bg-error' and contains(text(),'Please enter valid Indian phone number')]")
//    public WebElement WarningMessage;
    //@FindBy(xpath="//span[@class='view-offer svelte-mpuryo']")
    //@FindBy(linkText="View Coupons")
   // @FindBy(xpath="//div[@class='false cart svelte-76p535']//div[@class='discount-coupon false svelte-mpuryo']//button[@class='svelte-mpuryo']/span[text()='3 coupons available']/following-sibling::span[text()='View Coupons']")
   // @FindBy(xpath="/html/body/div/div[2]/div/div/div/div/div/div[3]/div/div/div/button/span[2]/text()")
    @FindBy(xpath="/html/body/div/div[2]/div/div/div/div/div/div[3]/div/div/div/button/span[1]")
    public WebElement viewCoupons;
    @FindBy(xpath="//button[@class='apply-button svelte-tlx3xn']")
    public WebElement applyCoupons;
    @FindBy(xpath="//div[@class='svelte-hybwat']/div[@class='container svelte-hybwat']/div[@class='head svelte-hybwat']/h1[@class='svelte-hybwat' and text()='Offers & Benefits']")
    public WebElement offers;
    @FindBy(xpath="//img[@src='/assets/icons/close-icon.svg' and @alt='Close Button' and @class='svelte-lkpla5']")
    public WebElement closeBtn;
    //@FindBy(xpath="//label[@for='I found a better price or product elsewhere']")
    @FindBy(xpath="/html/body/div/div[3]/div/div[2]/ul/label[2]")
    public WebElement reasonForCancellation;
    @FindBy(xpath="/html/body/div/div[3]/div/div[2]/div/button[1]")
    public WebElement skipBtn;
    @FindBy(xpath="//button[@class='active exit-btn svelte-16jf1fj' and contains(text(),'Submit and exit')]")
    public WebElement continueBtn;


    public void clickQuickCheckoutButton() {
        clickOn(quickCheckout);
    }
    public void sendInvalidNumber(String phone) {
    	sendtext(phoneNo,phone);
    }
    public void clickClear() {
		clear(phoneNo);
	}
    public void clickViewCoupons() {
    	moveOver(viewCoupons);
        jsClick(viewCoupons);
    }
    public void clickApplyCoupons() {
    	moveOver(applyCoupons);
        clickOn(applyCoupons);
    }
    public void clickCloseButton() {
    	moveOver(closeBtn);
        jsClick(closeBtn);
    }
    public void clickReasonForCancellation() {
        clickOn(reasonForCancellation);
    }
    public void clickContinueButton() {
    	moveOver(continueBtn);
        clickOn(continueBtn);
    }

    
}
