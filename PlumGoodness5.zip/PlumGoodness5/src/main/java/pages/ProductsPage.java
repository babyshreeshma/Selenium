package pages;

import base.DriverUtils;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductsPage extends DriverUtils {
    WebDriver driver;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[@class=\"boost-pfs-filter-toolbar-item boost-pfs-filter-custom-sorting boost-pfs-filter-top-sorting\"]//label")
    public WebElement recommendedBtn;

    //@FindBy(xpath = "//a[contains(@data-boost-sort-value, 'Price: Low to High')]")
    @FindBy(xpath="/html/body/div[3]/main/div/div[2]/div[1]/div/div/div[1]/div/div[1]/div/ul/li[4]/a")
    public WebElement lohiBtn;

    @FindBy(xpath = "(//div[@class=\"boost-pfs-filter-option-title\"]//button)[5]")
    public WebElement selectRange;

    @FindBy(xpath = "(//div[@class=\"noUi-origin\"]//div)[5]")
    public WebElement SetPriceRange;

    @FindBy(xpath = "//span[text()=\"Plum BodyLovin' Trippin' Mimosas Eau De Parfum\"]")
    public WebElement selectProduct;

    @FindBy(xpath = "/html/body/div[3]/main/div/div[2]/div[1]/div/div/div[2]/div[1]/div[2]/div[3]/div/div/div[2]/h3/a/span")
    public WebElement selectOneProduct;

    public void clickRecommendedButton() {
        clickOn(recommendedBtn);
    }

    public void clickLowToHighButton() {
        clickOn(lohiBtn);
    }

    public void clickselectRange() {
        clickOn(selectRange);
    }

    public void setPriceRange(int xOffset, int yOffset) {
        Actions actions = new Actions(driver);
        WebElement priceRangeSlider = SetPriceRange;
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", priceRangeSlider);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(priceRangeSlider));
        actions.dragAndDropBy(priceRangeSlider, xOffset, yOffset).perform();
    }

    public SelectedProductPage clickselectProduct() {
        clickOn(selectProduct);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.titleIs("Plum BodyLovin' Trippin' Mimosas Eau De Parfum"));
        return PageFactory.initElements(driver, SelectedProductPage.class);
    }

    public NewProductPage clickselectOneProduct() {
        scrollElementIntoView(selectOneProduct);
        clickOn(selectOneProduct);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.titleIs("Plum BodyLovin’ All-in-1 Eau De Parfum Bundle (15 ml) | Ultra-luxe Per"));
        return PageFactory.initElements(driver, NewProductPage.class);
    }
    

    /******************************ProductReviewTestScenario********************************************/
    @FindBy(linkText = "Price: High to Low")
    public WebElement hiloBtn;

    @FindBy(xpath = "//span[@class='lang1' and text()='Bright Years Age Specialist Full Set']")
    public WebElement selectProduct1;

    public void clickHighToLowButton() {
        clickOn(hiloBtn);
    }

    public void clickSelectProduct() {
        clickOn(selectProduct1);
    }

}

