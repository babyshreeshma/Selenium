package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class NewProductPage extends DriverUtils {
    WebDriver driver;

    public NewProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Define your @FindBy annotations for elements on the homepage here.

    @FindBy(xpath = "/html/body/div[3]/main/div/div[1]/div/div/div/div/div[1]/div[2]/div[2]/div[2]/form/div[4]/div/div[1]/a")
    public WebElement selectWishListMenu;

   // @FindBy(xpath = "//div[@class='iwishAddWrap']//a[@class='iwishAdded']")
    @FindBy(xpath="//div[@class='iwishAddWrap']//a[@class='iWishAdd iwishAdded' and @href='#' and @data-product='7127278649404']")
    public WebElement messageElement;
  
    @FindBy(xpath="//div[@class=\"header-mb\"]//span)[1]")
    public WebElement menuBtn;
    
    //@FindBy(xpath="//span[@class='icon-line']")
    @FindBy(xpath="/html/body/div[2]/div/header/div[2]/div/div[1]/div[1]/div/span/span")
    public WebElement menuBtn1;
    
    @FindBy(xpath="//div[contains(@class, 'iwish-icon') and contains(@class, 'svg-mb') and contains(@class, 'mobile-wishlist')]/a[contains(@class, 'iWishView')]")
    public WebElement wishlistBtn;
  
    
    // Methods to interact with the elements using clickOn.
    public void clickWishlistButton() {
        scrollElementIntoView(selectWishListMenu);
        clickOn(selectWishListMenu);
        
    }
   
    public void clickMenuButton() {
    	clickOn(menuBtn);
    }
    public void clickMenu1Button() {
        moveOver(menuBtn1);
        clickOn(menuBtn1);
    }
    public WishlistPage clickViewWishlistButton() {
    	clickOn(wishlistBtn);
    	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
 		wait.until(ExpectedConditions.titleIs("Plum Goodness"));
 		return PageFactory.initElements(driver, WishlistPage.class);
    }
}


