package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class HomePage extends DriverUtils {
	WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/******************************
	 * WishList Management and Product Checkout Test Scenario
	 ********************************************/
	// Define your @FindBy annotations for elements on the homepage here.

	@FindBy(xpath = "(//div[@class=\"header-mb\"]//span)[1]")
	public WebElement menuBtn;

	@FindBy(linkText = "body")
	public WebElement bodyBtn;

	@FindBy(linkText = "perfume")
	public WebElement perfume;

	@FindBy(id = "ymDivBar")
	public WebElement ChatBotBtn;

	@FindBy(xpath = "//div[@class=\"flex-button-group\"]//button")
	public WebElement closeChatBtn;

	@FindBy(xpath = "//div[@class=\"text-continue\"]")
	public WebElement selectCtnShop;

	// Methods to interact with the elements using clickOn.
	public void clickMenuButton() {
		moveOver(menuBtn);
		clickOn(menuBtn);
	}

	public void clickselectCtnShop() {
		clickOn(selectCtnShop);
	}

	public void clickBodyButton() {
		clickOn(bodyBtn);
	}

	public void clickPerfumeButton() {
		clickOn(perfume);
	}

	public ProductsPage clickPefumeButton() {
		clickOn(perfume);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.titleIs("eau de parfum"));
		return PageFactory.initElements(driver, ProductsPage.class);
	}

	/*******
	 * User Management Test Scenario and Product Review Test Scenario
	 ***********************/
	@FindBy(xpath = "//div[@class='account_div']/a")
	public WebElement Chooseaccount;

	public LoginPage clickDirectHome() {
		clickOn(Chooseaccount);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account"));
		return PageFactory.initElements(driver, LoginPage.class);
	}

	public RegistrationPage clickDirectAccount() {
		clickOn(Chooseaccount);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Account"));
		return PageFactory.initElements(driver, RegistrationPage.class);
	}

}
