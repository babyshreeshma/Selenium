package testcases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import base.BaseTest;
import pages.CartPage;
import pages.ProductPage;
import pages.SearchPage;
import utilities.Excelutilits;


@Listeners(utilities.SampleListener.class)
public class CartTests extends BaseTest {
	WebDriver driver;
	SearchPage srchpg;
	ProductPage prdctpg;
	CartPage crtpg;
	String[][] data;

	
	/************
	 * Data provider method for test data.
	 * 
	 * @return 2D array of test data.
	 *************/

	
	@Test
	@DataProvider(name = "testData")
	public Object[][] testdata() {
		data = Excelutilits.testdata();
		return data;
	}

//	@Test(priority = 0)
//	public void MainTest() {
//		SearchPage srchpg = new SearchPage(driver);
//		srchpg = goToSearchPage();
//		ProductPage prdctpg = new ProductPage(driver);
//		prdctpg = goToProductPage();
//		CartPage crtpg = new CartPage(driver);
//		crtpg = goToCartPage();
//		
//	}

	/*********** Test case to search for a product. ************/
	
	@Test(priority = 1)
	public void searchTest() {
		SearchPage srchpg = new SearchPage(driver);
		srchpg = goToSearchPage();
		srchpg.clickSearchBar();
		String text = "charcoal";
		srchpg.sendSearchData(text);
		srchpg.srch.sendKeys(Keys.ENTER);

		String expectedUrl = "https://plumgoodness.com/search?q=charcoal";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl);
		
		//logger.log(Status.INFO, "Search Test is successfull");
	}
	

	/************** Test case to handle checkbox. ***************/

	@Test(priority = 2)
	public void checkboxTest() {
		SearchPage srchpg = new SearchPage(driver);
		srchpg.clickCheckBox();
		srchpg.clickClearCheckBox();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean btnclr = wait.until(ExpectedConditions.invisibilityOf(srchpg.clearCheckBox));
		softAssertions.assertThat(btnclr).as("View cart is displayed").isTrue();
		
	//	logger.log(Status.INFO, "Checkbox Test is successfull");
	}
	

	/******************* Test case to handle Dropdown *******************/

	@Test(priority = 3)
	public void chooseDropdownTest() {
		SearchPage srchpg = new SearchPage(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		srchpg.clickDropdownBtn();
		
		srchpg.clickDrpdnRelevance();
		boolean isRelevanceDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_relevance)).isDisplayed();
		Assert.assertTrue(isRelevanceDisplayed, "Dropdown with relevance is displayed");

		
		srchpg.clickDrpdnNewArivals();
		boolean isNewArrivalsDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_new_arrivals)).isDisplayed();
		Assert.assertTrue(isNewArrivalsDisplayed, "Dropdown with new arrivals is displayed");

		
		boolean isA_ZDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_A_To_Z)).isDisplayed();
		Assert.assertTrue(isA_ZDisplayed, "Dropdown with A to Z is displayed");
		
		srchpg.clickDrpdnPriceLowToHigh();
		boolean isLow_To_HighDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_price_lowtohigh)).isDisplayed();
		Assert.assertTrue(isLow_To_HighDisplayed, "Dropdown with low to high is displayed");
		
		
		srchpg.clickDrpdnPriceHighToLow();
		boolean isHigh_LowDisplayed = wait.until(ExpectedConditions.visibilityOf(srchpg.dropdown_price_hightolow)).isDisplayed();
		Assert.assertTrue(isHigh_LowDisplayed, "Dropdown with high to low is displayed");
		
		//logger.log(Status.INFO, "Dropdown Test is successfull");
	}

	/*******************
	 * Test case to choose a product from the search results.
	 *****************/

	
	@Test(priority = 4)
	public void chooseProductTest() {
		SearchPage srchpg = new SearchPage(driver);
		srchpg.clickFirstProduct();
		String expectedUrl = "https://plumgoodness.com/products/phy-charcoal-deep-cleansing-face-wash";
		String actualUrl = driver.getCurrentUrl();
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});
	//	logger.log(Status.INFO, "Choose a product from the search results is successfull");
	}

	/***************
	 * Test case to change the product quantity by the text box
	 ********************/

	
	@Test(priority = 5)
	public void changeProductQuantityTest() {
		ProductPage prdctpg = new ProductPage(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement quantityField = prdctpg.clickQuantity();
		wait.until(ExpectedConditions.elementToBeClickable(quantityField));
		quantityField.clear();

		String qty = "2";
		prdctpg.clickAndSendQunatity(qty);

		Assert.assertEquals(prdctpg.prodQuantity, 2, "Product quantity is not as expected");
		

	//	logger.log(Status.INFO, "Change the product quantity by the text box is successfull");
	}

	/***************
	 * Test cases to change the product quantity by the buttons
	 ********************/

	@Test(priority = 6)
	public void changeProductQuantityByMinusTest() {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.clickDecreaseQuantity();
		Assert.assertEquals(prdctpg.prodQuantity, 1, "Product quantity is not as expected");
		

		//logger.log(Status.INFO, "Change the product quantity by minus button is successfull");
	}


	@Test(priority = 7)
	public void changeProductQuantityByPlusTest() {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.clickIncreaseQuantity();
		Assert.assertEquals(prdctpg.prodQuantity, 2, "Product quantity is not as expected");
		
		//logger.log(Status.INFO, "Change the product quantity by plus button is successfull");
	}
	
	/***************** Test case to validate a pincode. ******************/

	@Test(priority = 8)
	public void pincodeValidationTest() {
		ProductPage prdctpg = new ProductPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		String pinno = "123456";
		prdctpg.clickPin(pinno);
		prdctpg.clickCheckPin();
		String invalid = prdctpg.invalidMsg();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping is not available."));
		});
		
		//logger.log(Status.INFO, "Pincode validation is successfull");

	}
	
	

	/*****************
	 * Test case to validate a pincode by Excel Sheet
	 ******************/

	@Test(dataProvider = "testData", priority = 9)
	public void pincodeByExcelTest(String pincode) throws InterruptedException {
		ProductPage prdctpg = new ProductPage(driver);
		prdctpg.clickPin(pincode);
		prdctpg.clickCheckPin();
		String invalid = prdctpg.invalidMsg();
		if (pincode.equals("12345")) {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Invalid pincode"));
			});

		} else if (pincode.equals("123456")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping is not available."));
			});
		} else {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(invalid.equalsIgnoreCase("Shipping Available!"));
			});
		}
		
		//logger.log(Status.INFO, "Validation a pincode by Excel Sheet is successfull");
	}

	

	/**********************
	 * Test case to add a product to the cart.
	 ********************/

	
	@Test(priority = 10)
	public void addToCartTest() {
		ProductPage prdctpg = new ProductPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", prdctpg.clickCart);
		prdctpg.clickViewCarts();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean titlebar = wait.until(ExpectedConditions.visibilityOf(prdctpg.viewCartSidebar)).isDisplayed();
		softAssertions.assertThat(titlebar).as("View cart is displayed").isTrue();
		
	//	logger.log(Status.INFO, "Add to cart operation is successfull");

	}


	/************************
	 * Test case to view and remove items from the cart.
	 ************************/
	
	@Test(priority = 11)
	public void viewCartTest() {
		CartPage crtpg = new CartPage(driver);
		crtpg.clickViewCartsButton();
		crtpg.clickRemoveFromCartsButton();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		SoftAssertions softAssertions = new SoftAssertions();
		boolean check = wait.until(ExpectedConditions.visibilityOf(crtpg.checkaftrrmvItem)).isDisplayed();
		softAssertions.assertThat(check).as("Empty cart is displayed").isTrue();

	//	logger.log(Status.INFO, "View cart and remove the product in cart operation is successfull");

	}

	/****************
	 * Tear-down method to close the WebDriver after all test methods.
	 ***************/

	@AfterTest
	public void tearDown() {
		// Close the browser after each test method
		driver.quit();
	}

}