package base;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;

import pages.CartPage;
import pages.ProductPage;
import pages.SearchPage;
import utilities.FileIO;

public class BaseTest {
	public WebDriver driver;
	public static String browserChoice;
	public static Properties prop;

	public BaseTest() {
		prop = FileIO.initProperties();
		// Print the loaded properties to verify
		System.out.println("Loaded properties: " + prop);
	}

	@BeforeTest
	public void setup() {
		browserChoice = prop.getProperty("browserName");
		if (browserChoice.equalsIgnoreCase("edge")) {
			driver = BrowserConfig.getBrowser();
			DriverUtils.driver=driver;
		}
	}

	public SearchPage goToSearchPage() {
		driver.get(prop.getProperty("applicationURL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women"));
		Assert.assertEquals(driver.getTitle(), "Plum Goodness | 100% Vegan & Toxin-Free Products | For Men & Women");
		return PageFactory.initElements(driver, SearchPage.class);
	}
	
	public ProductPage goToProductPage() {
		//driver.get(prop.getProperty("applicationURL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Phy Charcoal Face Wash | Deep Cleansing | SLS-Free | For Oily Or Combi"));
		Assert.assertEquals(driver.getTitle(), "Phy Charcoal Face Wash | Deep Cleansing | SLS-Free | For Oily Or Combi");
		return PageFactory.initElements(driver, ProductPage.class);
	}
	
	public CartPage goToCartPage() {
		//driver.get(prop.getProperty("applicationURL"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.titleIs("Your Shopping Cart"));
		Assert.assertEquals(driver.getTitle(), "Your Shopping Cart");
		return PageFactory.initElements(driver, CartPage.class);
	}
	
	
	public <T> T initPage(Class<T> pageClass) {
		return PageFactory.initElements(driver, pageClass);
	}

}