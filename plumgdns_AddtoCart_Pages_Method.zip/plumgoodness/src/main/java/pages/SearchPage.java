package pages;


import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.DriverUtils;

public class SearchPage extends DriverUtils {
	WebDriver driver;

	public SearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

    /****************Search Product***************/	
	
	@FindBy(id="searchfeild")
	public WebElement srch;
	
	
	/*****************Check Box***************/	
	
	@FindBy(xpath="(//div[@class=\"outer-checkbox\"]//span[@class=\"st-checkbox\"])[1]")
	public WebElement checkbox;
	
	@FindBy(xpath="(//div[contains(@class,\" st-filter-open\")]//span[@class=\"filter-clear\"])[1]")
	public WebElement clearCheckBox;
	
	
	 /****************DropDown***************/	
	

	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//span[@class=\"st-sort-box\"])[2]")
//	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"])[1]")
	public WebElement dropdownBtn;
	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li//span)[1]")
	public WebElement dropdown_relevance;
	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li//span)[2]")
	public WebElement dropdown_new_arrivals;
	
	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li//span)[3]")
	public WebElement dropdown_A_To_Z;
	
//	@FindBy(xpath="(//div[@class=\"st-sort-dropdown\"]//ul[@class=\"st-sorting\"]//li//span)[5]")
	@FindBy(xpath="/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div/div/span/ul/li[6]/span")
	public WebElement dropdown_price_lowtohigh;

	
	//@FindBy(xpath="(//div[@class="st-sort-dropdown"]//ul[@class="st-sorting"]//li//span)[6]")
	@FindBy(linkText="Price, High to Low")
	public WebElement dropdown_price_hightolow;
	
	
	/****************Choose the product***************/	
	
	
//	@FindBy(xpath="(//div[@class=\"st-product-wrap\"]//div[@class=\"st-product\"]//figure[@class=\"st-product-media\"])[2]")
	@FindBy(xpath="(//div[contains(@class,\"st-row st-cols-2 st-cols-sm-2 \")]//div[@class=\"st-product-wrap\"]//div[@class=\"st-product\"]//figure[@class=\"st-product-media\"])[2]")
//	@FindBy(xpath="/html/body/div[3]/div[1]/div/div/div[2]/div[1]/div[2]/div[3]/div[2]/div[1]/div/figure/a/img[1]")	
	public WebElement firstProduct;
	
	
	
	/****************Search Product***************/	

	public WebElement getSrch() {
	        return srch;
	    }


	public void clickSearchBar() {
		clickOn(srch);
		
	}
	
	public void sendSearchData(String text) {
		sendtext(srch,text);
		
	}
	
	
	/*****************Check Box***************/	
	
	public void clickCheckBox() {
		clickOn(checkbox);
	}
	
	public void clickClearCheckBox() {
		clickOn(clearCheckBox);
	}
	
	
	 /****************DropDown***************/	
	

	public void clickDropdownBtn() {
		clickOn(dropdownBtn);
	}
	
	public void clickDrpdnRelevance() {
		clickOn(dropdown_relevance);
	}
	
	public void clickDrpdnNewArivals() {
		clickOn(dropdown_new_arrivals);
	}
	public void clickDrpdnA_Z() {
		clickOn(dropdown_A_To_Z);
	}
	
	
	public void clickDrpdnPriceLowToHigh() {
		clickOn(dropdown_price_lowtohigh);
	}
	

	public void clickDrpdnPriceHighToLow() {
		clickOn(dropdown_price_hightolow);
	}
	
	
	/****************Choose the product***************/	
	
	public ProductPage clickFirstProduct() {
		clickOn(firstProduct);
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.urlToBe("https://plumgoodness.com/products/phy-charcoal-deep-cleansing-face-wash"));
		return PageFactory.initElements(driver, ProductPage.class);
	}
	
	
	
	
}