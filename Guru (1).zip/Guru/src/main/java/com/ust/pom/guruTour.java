package com.ust.pom;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.base.BaseUI;


public class guruTour extends BaseUI{

	WebDriver driver;
	public guruTour(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	 
	@FindBy(name="userName")
	WebElement userName;
	
	@FindBy(name="password")
	WebElement password;
	
	@FindBy(name="submit")
	WebElement loginSubmit;
	
	@FindBy(xpath="//a[text()='Flights' ]")
	WebElement Flightclick;
	
	@FindBy(xpath="//input[@value='roundtrip']")
	WebElement roundway;
	
	@FindBy(xpath="//select[@name=\"passCount\"] /option[3]")
	WebElement passengerCount;
	
	@FindBy(xpath="//select[@name=\"fromPort\"] /option[4]")
	WebElement departingfrom;
	
	@FindBy(xpath="//select[@name=\"fromMonth\"] /option[5]")
	WebElement onMonth;
	
	@FindBy(xpath="//select[@name=\"fromDay\"] /option[10]")
	WebElement onDay;
	
	@FindBy(xpath="//select[@name='toPort']/option[3]")
	WebElement arrive;
	
	@FindBy(xpath="//select[@name='toMonth']/option[3]")
	WebElement returnMonth;
	
	@FindBy(xpath="//select[@name='toDay']/option[10]")
	WebElement returnDay;
	
	@FindBy(xpath="//select[@name='airline']/option[3]")
	WebElement airline;
	
	@FindBy(xpath="//input[@name='findFlights']")
	WebElement Continuebutton;
	
	@FindBy(xpath="//img[@src='images/home.gif']")
	WebElement backtohome;
	
		
	public void userName(String username) {
		sendtext(userName,username );
	}
	
	public void password(String Password) {
		sendtext(password,Password );
	}
	
	public void loginSubmit() {
		clickOn(loginSubmit);
	}
	public void Flightclick() {
		clickOn(Flightclick);
	}
	public void roundway() {
		clickOn(roundway);
	}
	public void passengerCount() {
		clickOn(passengerCount);
	}
	public void departingfrom() {
		clickOn(departingfrom);
	}
	public void onMonth() {
		clickOn(onMonth);
	}
	public void onDay() {
		clickOn(onDay);
	}
	public void arrive() {
		clickOn(arrive);
	}
	public void returnMonth() {
		clickOn(returnMonth);
	}
	public void returnDay() {
		clickOn(returnDay);
	}
	public void airline() {
		clickOn(airline);
	}
	public void Continuebutton() {
		clickOn(Continuebutton);
	}
	public void backtohome() {
		clickOn(backtohome);
	}

	public String getTitle() {	
		return driver.getTitle();
	}
	
}