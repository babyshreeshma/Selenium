package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.base.BaseUI;
import com.ust.pom.guruTour;
import com.ust.utilities.excelUtils;


public class testCase extends BaseUI {
	WebDriver driver;
	 guruTour commerce;
	 String[][] data;
	//This method is checking the functionality of the invoking the browsers
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	@DataProvider(name = "testData")
	public Object[][] testdata(){
		data= excelUtils.testdata();
		return data;
	}
	@Test(priority=1,dataProvider = "testData")
	public void loginClick(String name,String password1) {
		guruTour guru=new guruTour(driver);
		guru.userName(name);
		guru.password(password1);
		guru.loginSubmit();
		
		String a=driver.getCurrentUrl();
		 SoftAssertions.assertSoftly(softAssertions -> {
		 softAssertions.assertThat(a.contains("https://demo.guru99.com/test/newtours/"));
		 });
	}
	@Test(priority=2)
	public void flightclick() {
		guruTour guru=new guruTour(driver);
		guru.Flightclick();
		guru.roundway();
//		SoftAssertions.assertSoftly(softAssertions -> {
//        	softAssertions.assertThat(driver.findElement(By.xpath("//input[@value='roundtrip']")).isSelected());
//        	});
		guru.passengerCount();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"passCount\"] /option[3]")).isSelected());
        	});
		guru.departingfrom();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name=\"fromPort\"] /option[4]")).isSelected());
        	});
		guru.onMonth();
		guru.onDay();
		guru.arrive();
		guru.returnMonth();
		guru.returnDay();
		SoftAssertions.assertSoftly(softAssertions -> {
        	softAssertions.assertThat(driver.findElement(By.xpath("//select[@name='toDay']/option[10]")).isSelected());
        	});
		guru.airline();
		guru.Continuebutton();
		guru.backtohome();
	}

}
