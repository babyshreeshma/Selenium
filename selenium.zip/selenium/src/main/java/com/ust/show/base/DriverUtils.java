package com.ust.show.base;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.fail;

/**
 * The type Driver utils.
 */
public class DriverUtils {

    private WebDriver driver;
    /**
     * The Browser type.
     */
    /**
     * The constant SERV_PROP_FILE.
     */
    

    /**
     * Instantiates a new Driver utils.
     *
     * @param driver the driver
     */
 

    /**
     * Is element present boolean.
     *
     * @param by the by
     * @return the boolean
     */
   

    /**
     * Is alert present boolean.
     *
     * @return the boolean
     */
  

    /**
     * Close alert and get its text string.
     *
     * @param acceptNextAlert the accept next alert
     * @return the string
     */
    

    /**
     * Gets base url.
     *
     * @return the base url
     */


    /**
     * Clear and type.
     *
     * @param field the field
     * @param text  the text
     */


    /**
     * Gets date time stamp.
     *
     * @return the date time stamp
     */
   

    /**
     * Is element present boolean.
     *
     * @param driver the driver
     * @param by     the by
     * @return the boolean
     */
   

    /**
     * Select option.
     *
     * @param driver        the driver
     * @param selectOption  the select option
     * @param selectLocator the select locator
     */
 

    /**
     * Select option.
     *  @param selectedElement the selected element
     * @param selectOption    the select option
     */
   

    /**
     * Is text present boolean.
     *
     * @param driver the driver
     * @param Text   the text
     * @return the boolean
     */
  

    /**
     * Wait for text.
     *
     * @param text       the text
     * @param by         the by
     * @param timeoutMsg the timeout msg
     * @throws Exception the exception
     */
    

    /**
     * Delay.
     *
     * @param seconds the seconds
     */
  

    /**
     * Click at.
     *
     * @param driver   the driver
     * @param byMethod the by method
     */
   

    /**
     * Click at.
     *
     * @param driver  the driver
     * @param by      the by
     * @param xOffset the x offset
     * @param yOffset the y offset
     */
   

    /**
     * Click at.
     *
     * @param driver  the driver
     * @param element the element
     */
  
    /**
     * Click at.
     *
     * @param driver  the driver
     * @param element the element
     * @param xOffset the x offset
     * @param yOffset the y offset
     */
    p

    /**
     * Js click.
     *
     * @param element the variants record
     * @param driver  the driver
     * @throws InterruptedException the interrupted exception
     */
   

    /**
     * Js click by id.
     *
     * @param locatorId the locator id
     * @param driver    the driver
     * @throws InterruptedException the interrupted exception
     */
   

    /**
     * Reduce implicit wait.
     *
     * @param driver                the driver
     * @param timeToReduceInSeconds the time to reduce in seconds
     */
   

    /**
     * Gets driver.
     *
     * @return the driver
     */
   
    /**
     * Sets driver.
     *
     * @param driver the driver
     * @return the driver
     */
  

    /**
     * Gets browser type.
     *
     * @return the browser type
     */
 

    /**
     * Sets browser type.
     *
     * @param browserType the browser type
     * @return the browser type
     */
 

    /**
     * Gets props.
     *
     * @return the props
     */
 

    /**
     * Sets props.
     *
     * @param props the props
     * @return the props
     */
   

    /**
     * Right click.
     *
     * @param element the element
     */


    /**
     * Right click and select an option. If you want to click on the first option of
     * the right click send 1 as a value to OptionToSelect If you want to click on
     * the third option of the right click send 3 as a value of the OptionToSelect
     * Note: If an item is disabled in the right click, don't count it.
     *
     * @param driver         the driver
     * @param element        the element
     * @param OptionToSelect the option to select
     */
 

    /**
     * Right click and select option. If you want to click on the first option of
     * the right click send 1 as a value to OptionToSelect If you want to click on
     * the third option of the right click send 3 as a value of the OptionToSelect
     * Note: If an item is disabled in the right click, don't count it.
     *
     * @param element        the element
     * @param OptionToSelect the option to select
     */
   


    /**
     * Switch to new window close old window.
     */
 

    /**
     * Clicks a link which opens in a new tab. Switches to the new tab.
     *
     * @param by the By for the link
     * @return window handle of original tab
     */
  
    /**
     * Close and return to source tab.
     *
     * @param handle the handle
     */
  

    /**
     * Switch to new window return win handle before.
     *
     * @return the string
     */
   

    /**
     * Switch to window based on title.
     *
     * @param windowTitleWhereToBeSwitched the window title where to be switched
     * @return true, if successful
     */
   
   
 


  

    /**
     * Mouse hover.
     *
     * @param element the element
     */
   

}