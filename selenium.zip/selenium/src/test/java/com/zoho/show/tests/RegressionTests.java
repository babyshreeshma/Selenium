package com.zoho.show.tests;

import com.ust.show.base.BaseTest;
import com.ust.show.base.DriverUtils;
import com.ust.show.pages.PresentationPage;
import com.ust.show.pages.ShowDashboardPage;
import com.ust.show.pages.SignInPage;
import com.ust.show.pages.ShowHomePage;

import org.junit.Assert;
import org.testng.annotations.Test;

public class RegressionTests extends BaseTest {

    @Test
    public void testDSignInSignOut() {
        ShowHomePage homePage = gotoShowHomePage();
        SignInPage signInPage = homePage.clickLoginLink();
        Assert.assertEquals("Title check", getTitle(), SignInPage.ZOHO_ACCOUNTS_TITLE);
        ShowDashboardPage dashboardPage = signInPage
                .typeEmailAddress(testConfigProperties.zohoUserName())
                .clickNextButton()
                .typePassword(testConfigProperties.zohoUserPassword())
                .clickNextButtonReturnDashboardPage();
        // For demo purposes this delay is added
        DriverUtils.delay(1000);
        dashboardPage
                .clickProfileImage()
                .clickSignOutLink();
        // For demo purposes this delay is added
        DriverUtils.delay(3000);
    }

    @Test
    public void testAListingView() {
        ShowHomePage homePage = gotoShowHomePage();
        SignInPage signInPage = homePage.clickLoginLink();
        //DriverUtils.delay(3000);
        ShowDashboardPage dashboardPage =  signInPage.login(testConfigProperties.zohoUserName()
                ,testConfigProperties.zohoUserPassword());
    //    Assert.assertEquals("Title check", getTitle(), SignInPage.ZOHO_ACCOUNTS_TITLE);
        DriverUtils.delay(3000);
        dashboardPage
                .clickSortByIcon()
                .clickDateModified()
                .clickListViewButton();

        DriverUtils.delay(6000);
    }

    @Test
    public void testBSlideRightClickLockUnlock() {
        ShowHomePage homePage = gotoShowHomePage();
        SignInPage signInPage = homePage.clickLoginLink();
        //DriverUtils.delay(3000);
        ShowDashboardPage dashboardPage =  signInPage.login(testConfigProperties.zohoUserName()
                ,testConfigProperties.zohoUserPassword());
     //   Assert.assertEquals("Title check", getTitle(), SignInPage.ZOHO_ACCOUNTS_TITLE);
        DriverUtils.delay(3000);
        PresentationPage presentationPage = dashboardPage.clickFirstSlideIconSwitchToNewTab();
        presentationPage
                .clickOnFirstGallerySlide()
                .rightClickOnFirstSlideAndClickLock()
                .mouseHoverOnLockIcon();
        DriverUtils.delay(6000);
    }

    @Test
    public void testCClickPlayOptionButton() {
        ShowHomePage homePage = gotoShowHomePage();
        SignInPage signInPage = homePage.clickLoginLink();
        //DriverUtils.delay(3000);
        ShowDashboardPage dashboardPage =  signInPage.login(testConfigProperties.zohoUserName()
                ,testConfigProperties.zohoUserPassword());
      //  DriverUtils.delay(3000);
       // Assert.assertEquals("Title check", getTitle(), SignInPage.ZOHO_ACCOUNTS_TITLE);
        DriverUtils.delay(3000);
        PresentationPage presentationPage = dashboardPage.clickFirstSlideIconSwitchToNewTab();
        presentationPage
                .clickOnFirstGallerySlide()
                .clickPlayOption();
               // .PlayOptionButtonClick();
        DriverUtils.delay(6000);
    }

    @Test
    public void testDSlideRightClickAndAddComment() {
        ShowHomePage homePage = gotoShowHomePage();
        SignInPage signInPage = homePage.clickLoginLink();
        //DriverUtils.delay(3000);
        ShowDashboardPage dashboardPage =  signInPage.login(testConfigProperties.zohoUserName()
                ,testConfigProperties.zohoUserPassword());
       // Assert.assertEquals("Title check", getTitle(), SignInPage.ZOHO_ACCOUNTS_TITLE);
        DriverUtils.delay(3000);
        PresentationPage presentationPage = dashboardPage.clickFirstSlideIconSwitchToNewTab();
        presentationPage
                .clickOnFirstGallerySlide()
                .rightClickOnAndAddComment();
        DriverUtils.delay(6000);
    }
}
