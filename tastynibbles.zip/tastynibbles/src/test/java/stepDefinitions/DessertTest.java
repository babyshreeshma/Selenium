package stepDefinitions;

import java.time.Duration;

import org.junit.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.Base.BaseUI;
import com.ust.POM.MainFile;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DessertTest extends BaseUI {
    MainFile mainfile;

    @Given("user is on home page")
    public void user_is_on_home_page() {
        driver = invokeBrowser();
        openBrowser("applicationURL");
        mainfile = new MainFile(driver);
    }
    @When("user clicks on Dessert button")
    public void user_clicks_on_dessert_button() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(mainfile.dessert));
        MainFile.clickOn(mainfile.dessert);
    }

    @Then("Dessert page should be displayed")
    public void dessert_page_should_be_displayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://www.tastynibbles.in/collections/dessert"));
        
        String expectedUrl = "https://www.tastynibbles.in/collections/dessert";
        String actualUrl = driver.getCurrentUrl();
        
        // Use JUnit assertion to compare expected and actual URLs
        Assert.assertEquals("Current URL should match expected URL", expectedUrl, actualUrl);

        driver.quit();  // Clean up at the end of the test
    }
}
