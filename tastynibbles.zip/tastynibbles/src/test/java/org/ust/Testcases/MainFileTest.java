package org.ust.Testcases;

import java.time.Duration;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import com.ust.Base.BaseUI;
import com.ust.POM.MainFile;
@Listeners(com.ust.Utilities.SampleListener.class)
public class MainFileTest extends BaseUI{
	WebDriver driver;
	MainFile mainfile;
	
	@BeforeMethod
	public void setup() {
		driver=invokeBrowser();
		openBrowser("applicationURL");
		mainfile=new MainFile(driver);
		
	}
	
	
	//checking news is clickable
	@Test
	public void clickNewsTest() {
		mainfile.clickNews();
		String expectedUrl="https://www.tastynibbles.in/blogs/news/tagged/news";
		String actualUrl=driver.getCurrentUrl();
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
		WebElement newsAndBlogsText = wait.until(ExpectedConditions.visibilityOfElementLocated(mainfile.newsandblogs));
		//WebElement newsandblogstext = wait.until(ExpectedConditions.visibilityOf( mainfile.newsandblogs));
		//wait.until(ExpectedConditions.urlMatches("https://www.tastynibbles.in/blogs/news/tagged/news"));
		SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(actualUrl).isEqualTo(expectedUrl);
		});
		logger.log(Status.INFO, "News button is clickable");
		
	}
	
	//checking ready to eat - nonveg is working or not
	@Test
	public void clickReadytoeatnonvegTest() {
		mainfile.clickReadytoeat();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		//WebElement nonvegclickable=wait.until(ExpectedConditions.elementToBeClickable(mainfile.readytoeatnonveg));
		SoftAssertions softAssertions=new SoftAssertions();
		boolean isDropdownDisplayed = wait
				.until(ExpectedConditions.presenceOfElementLocated(mainfile.readytoeatnonveg)).isDisplayed();
		softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with non veg option is displayed").isTrue();	
		logger.log(Status.INFO, "Dropdown with non veg option is displayed");
	}
	
	//checking ready to eat is working or not
		@Test
		public void clickReadytoeatvegTest() {
			mainfile.clickReadytoeat();
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
			SoftAssertions softAssertions=new SoftAssertions();
			boolean isDropdownDisplayed = wait
					.until(ExpectedConditions.presenceOfElementLocated(mainfile.readytoeatveg)).isDisplayed();
			softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with veg option is displayed").isTrue();	
			logger.log(Status.INFO, "Dropdown with veg option is displayed");
		}
		
		//checking ready to eat is working or not
				@Test
				public void clickReadytoeatfishcurryTest() {
					mainfile.clickReadytoeat();
					WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
					SoftAssertions softAssertions=new SoftAssertions();
					boolean isDropdownDisplayed = wait
							.until(ExpectedConditions.presenceOfElementLocated(mainfile.readytoeatfishcurry)).isDisplayed();
					softAssertions.assertThat(isDropdownDisplayed).as("Dropdown with fish curry option is displayed").isTrue();	
					logger.log(Status.INFO, "Dropdown with fish curry option is displayed");
				}
		
	//Testing searching fuction is working or not
	@Test
	public void searchTest() {
		String text="Fish";
		mainfile.clickSearch(text);
		mainfile.clickSearchButton();
		String actualUrl=driver.getCurrentUrl();
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement sftrsrchtxt=wait.until(ExpectedConditions.visibilityOfElementLocated(mainfile.aftrsrch));
		String ExpectedUrl="https://www.tastynibbles.in/search?type=product%2Carticle&options[prefix]=last&q=Fish*";
		SoftAssertions.assertSoftly(softAssertions->{
			softAssertions.assertThat(actualUrl).isEqualTo(ExpectedUrl);
		});
		logger.log(Status.INFO, "Going to correct URL");
	}
	
	
	//Testing the shopping cart is clickable 
	@Test
	public void cartTest() {
	    mainfile.clickCart();
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    // Check whether the close button is displayed
	    boolean isCloseButtonDisplayed = wait
	            .until(ExpectedConditions.presenceOfElementLocated(mainfile.cartClose)).isDisplayed();
	    SoftAssertions softAssertions = new SoftAssertions();
	    softAssertions.assertThat(isCloseButtonDisplayed).as("Close button is displayed").isTrue();
	    softAssertions.assertAll();
	}
	
	//Testing the account is clickable 
		@Test
		public void accountTest() {
		    mainfile.clickCart();
		    String actualUrl=driver.getCurrentUrl();
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
			wait.until(ExpectedConditions.urlToBe("https://www.tastynibbles.in/account/login?return_url=%2Faccount"));
			String ExpectedUrl="https://www.tastynibbles.in/account/login?return_url=%2Faccount";
			SoftAssertions.assertSoftly(softAssertions->{
				softAssertions.assertThat(actualUrl).isEqualTo(ExpectedUrl);
			});
			logger.log(Status.INFO, "Going to correct URL");
		    
		}

	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	

}
