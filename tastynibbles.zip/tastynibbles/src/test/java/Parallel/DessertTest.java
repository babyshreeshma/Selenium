package Parallel;

import org.junit.Assert;

import com.ust.Base.BaseUI;
import com.ust.POM.MainFile;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DessertTest extends BaseUI{
	MainFile mainfile;
	@Given("user is on home page")
	public void user_is_on_home_page() {
		driver=invokeBrowser();
		openBrowser("applicationURL");
	    
	}

	@When("user clicks on Dessert button")
	public void user_clicks_on_dessert_button() {
		MainFile.clickOn(mainfile.dessert);
	    
	}

	@Then("Dessert page should be displayed")
	public void dessert_page_should_be_displayed() {	
	    Assert.assertTrue(mainfile.isDessertPageIsOpen());
	}

}
