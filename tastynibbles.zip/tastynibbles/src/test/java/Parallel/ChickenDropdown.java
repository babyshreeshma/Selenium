package Parallel;

import org.junit.Assert;

import com.ust.Base.BaseUI;
import com.ust.POM.MainFile;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ChickenDropdown extends BaseUI{
	MainFile mainfile;
	@Given("user is on home page")
	public void user_is_on_home_page() {
		driver=invokeBrowser();
		openBrowser("applicationURL");    
	}

@When("user clicks on Ready To Eat button")
public void user_clicks_on_ready_to_eat_button() {
	MainFile.clickOn(mainfile.readytoeat);
   
}

@When("user clicks on Chicken button")
public void user_clicks_on_chicken_button() {
	MainFile.clickOn(mainfile.chicken);
    
}

@Then("user gets the Chicken page")
public void user_gets_the_chicken_page() {
	Assert.assertTrue(mainfile.isChickenPageIsOpen());
}

}
