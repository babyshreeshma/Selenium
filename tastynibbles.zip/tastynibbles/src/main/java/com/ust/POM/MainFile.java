package com.ust.POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Base.BaseUI;

public class MainFile extends BaseUI{
	WebDriver driver;
	
	public MainFile(WebDriver driver) {
        this.driver = driver;
    }
	
	public By news=getlocator("news_xpath");
	public By newsandblogs=getlocator("neseblogs_xpath");
	public By readytoeat=getlocator("readytoeat_xpath");
	public By readytoeatnonveg=getlocator("readytoeatnonveg_xpath");
	public By readytoeatveg=getlocator("readytoeatveg_xpath");
	public By readytoeatfishcurry=getlocator("fishCurry_xpath");
	public By srchbtn=getlocator("srchbtn_xpath");
	public By srchbar=getlocator("searchbar_xpath");
	public By aftrsrch=getlocator("aftrsrch_xpath");
	public By cart=getlocator("cart_xpath");
	public By cartClose=getlocator("cartclosebtn_xpath");
	public By account=getlocator("account_xpath");
	public By dessert=getlocator("dessert_xpath");
	public By chicken=getlocator("chicken_xpath");
	public By aftrdessertlick=getlocator("aftrdessertclick_xpath");
	public By aftrchickenclick=getlocator("aftrchicken_xpath");

	
	public void clickNews() {
		clickOn(news);
	}
	public void clickReadytoeat() {
		clickOn(readytoeat);
	}
	public void clickReadytoeatNonveg() {
		clickOn(readytoeatnonveg);
	}
	public void clickReadytoeatveg() {
		clickOn(readytoeatveg);
	}
	public void clickReadytoeatfishcurry() {
		clickOn(readytoeatfishcurry);
	}
	public void clickSearch(String text) {
		sendtext(srchbar,text);
	}
	public void clickSearchButton() {
		clickOn(srchbtn);
	}
	public void clickCart() {
		clickOn(cart);
	}
	public void clickAccount() {
		clickOn(account);
	}
	public boolean isDessertPageIsOpen() {
		return driver.findElement(aftrdessertlick).isDisplayed();
	}
	public boolean isChickenPageIsOpen() {
		return driver.findElement(aftrchickenclick).isDisplayed();	
	}
	
}
