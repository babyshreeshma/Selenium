$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"15caec18-f736-41d0-81e9-c32c8ce9c541","feature":"Dessert Page feature","scenario":"Dessert Page link","start":1691495772058,"group":1,"content":"","tags":"","end":1691495782411,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});